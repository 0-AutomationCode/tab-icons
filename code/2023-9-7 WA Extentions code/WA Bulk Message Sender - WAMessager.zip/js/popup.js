var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.createTemplateTagFirstArg = function (d) {
  return (d.raw = d);
};
$jscomp.createTemplateTagFirstArgWithRaw = function (d, k) {
  d.raw = k;
  return d;
};
$jscomp.arrayIteratorImpl = function (d) {
  var k = 0;
  return function () {
    return k < d.length ? { done: !1, value: d[k++] } : { done: !0 };
  };
};
$jscomp.arrayIterator = function (d) {
  return { next: $jscomp.arrayIteratorImpl(d) };
};
$jscomp.makeIterator = function (d) {
  var k = "undefined" != typeof Symbol && Symbol.iterator && d[Symbol.iterator];
  if (k) return k.call(d);
  if ("number" == typeof d.length) return $jscomp.arrayIterator(d);
  throw Error(String(d) + " is not an iterable or ArrayLike");
};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.SIMPLE_FROUND_POLYFILL = !1;
$jscomp.ISOLATE_POLYFILLS = !1;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
$jscomp.defineProperty =
  $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
    ? Object.defineProperty
    : function (d, k, m) {
        if (d == Array.prototype || d == Object.prototype) return d;
        d[k] = m.value;
        return d;
      };
$jscomp.getGlobal = function (d) {
  d = [
    "object" == typeof globalThis && globalThis,
    d,
    "object" == typeof window && window,
    "object" == typeof self && self,
    "object" == typeof global && global,
  ];
  for (var k = 0; k < d.length; ++k) {
    var m = d[k];
    if (m && m.Math == Math) return m;
  }
  throw Error("Cannot find global object");
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.IS_SYMBOL_NATIVE =
  "function" === typeof Symbol && "symbol" === typeof Symbol("x");
$jscomp.TRUST_ES6_POLYFILLS =
  !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
$jscomp.polyfills = {};
$jscomp.propertyToPolyfillSymbol = {};
$jscomp.POLYFILL_PREFIX = "$jscp$";
var $jscomp$lookupPolyfilledValue = function (d, k, m) {
  if (!m || null != d) {
    m = $jscomp.propertyToPolyfillSymbol[k];
    if (null == m) return d[k];
    m = d[m];
    return void 0 !== m ? m : d[k];
  }
};
$jscomp.polyfill = function (d, k, m, t) {
  k &&
    ($jscomp.ISOLATE_POLYFILLS
      ? $jscomp.polyfillIsolated(d, k, m, t)
      : $jscomp.polyfillUnisolated(d, k, m, t));
};
$jscomp.polyfillUnisolated = function (d, k, m, t) {
  m = $jscomp.global;
  d = d.split(".");
  for (t = 0; t < d.length - 1; t++) {
    var w = d[t];
    if (!(w in m)) return;
    m = m[w];
  }
  d = d[d.length - 1];
  t = m[d];
  k = k(t);
  k != t &&
    null != k &&
    $jscomp.defineProperty(m, d, { configurable: !0, writable: !0, value: k });
};
$jscomp.polyfillIsolated = function (d, k, m, t) {
  var w = d.split(".");
  d = 1 === w.length;
  t = w[0];
  t = !d && t in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
  for (var L = 0; L < w.length - 1; L++) {
    var O = w[L];
    if (!(O in t)) return;
    t = t[O];
  }
  w = w[w.length - 1];
  m = $jscomp.IS_SYMBOL_NATIVE && "es6" === m ? t[w] : null;
  k = k(m);
  null != k &&
    (d
      ? $jscomp.defineProperty($jscomp.polyfills, w, {
          configurable: !0,
          writable: !0,
          value: k,
        })
      : k !== m &&
        (void 0 === $jscomp.propertyToPolyfillSymbol[w] &&
          ((m = (1e9 * Math.random()) >>> 0),
          ($jscomp.propertyToPolyfillSymbol[w] = $jscomp.IS_SYMBOL_NATIVE
            ? $jscomp.global.Symbol(w)
            : $jscomp.POLYFILL_PREFIX + m + "$" + w)),
        $jscomp.defineProperty(t, $jscomp.propertyToPolyfillSymbol[w], {
          configurable: !0,
          writable: !0,
          value: k,
        })));
};
$jscomp.underscoreProtoCanBeSet = function () {
  var d = { a: !0 },
    k = {};
  try {
    return (k.__proto__ = d), k.a;
  } catch (m) {}
  return !1;
};
$jscomp.setPrototypeOf =
  $jscomp.TRUST_ES6_POLYFILLS && "function" == typeof Object.setPrototypeOf
    ? Object.setPrototypeOf
    : $jscomp.underscoreProtoCanBeSet()
    ? function (d, k) {
        d.__proto__ = k;
        if (d.__proto__ !== k) throw new TypeError(d + " is not extensible");
        return d;
      }
    : null;
$jscomp.generator = {};
$jscomp.generator.ensureIteratorResultIsObject_ = function (d) {
  if (!(d instanceof Object))
    throw new TypeError("Iterator result " + d + " is not an object");
};
$jscomp.generator.Context = function () {
  this.isRunning_ = !1;
  this.yieldAllIterator_ = null;
  this.yieldResult = void 0;
  this.nextAddress = 1;
  this.finallyAddress_ = this.catchAddress_ = 0;
  this.finallyContexts_ = this.abruptCompletion_ = null;
};
$jscomp.generator.Context.prototype.start_ = function () {
  if (this.isRunning_) throw new TypeError("Generator is already running");
  this.isRunning_ = !0;
};
$jscomp.generator.Context.prototype.stop_ = function () {
  this.isRunning_ = !1;
};
$jscomp.generator.Context.prototype.jumpToErrorHandler_ = function () {
  this.nextAddress = this.catchAddress_ || this.finallyAddress_;
};
$jscomp.generator.Context.prototype.next_ = function (d) {
  this.yieldResult = d;
};
$jscomp.generator.Context.prototype.throw_ = function (d) {
  this.abruptCompletion_ = { exception: d, isException: !0 };
  this.jumpToErrorHandler_();
};
$jscomp.generator.Context.prototype["return"] = function (d) {
  this.abruptCompletion_ = { return: d };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks = function (d) {
  this.abruptCompletion_ = { jumpTo: d };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.yield = function (d, k) {
  this.nextAddress = k;
  return { value: d };
};
$jscomp.generator.Context.prototype.yieldAll = function (d, k) {
  var m = $jscomp.makeIterator(d),
    t = m.next();
  $jscomp.generator.ensureIteratorResultIsObject_(t);
  if (t.done) (this.yieldResult = t.value), (this.nextAddress = k);
  else return (this.yieldAllIterator_ = m), this.yield(t.value, k);
};
$jscomp.generator.Context.prototype.jumpTo = function (d) {
  this.nextAddress = d;
};
$jscomp.generator.Context.prototype.jumpToEnd = function () {
  this.nextAddress = 0;
};
$jscomp.generator.Context.prototype.setCatchFinallyBlocks = function (d, k) {
  this.catchAddress_ = d;
  void 0 != k && (this.finallyAddress_ = k);
};
$jscomp.generator.Context.prototype.setFinallyBlock = function (d) {
  this.catchAddress_ = 0;
  this.finallyAddress_ = d || 0;
};
$jscomp.generator.Context.prototype.leaveTryBlock = function (d, k) {
  this.nextAddress = d;
  this.catchAddress_ = k || 0;
};
$jscomp.generator.Context.prototype.enterCatchBlock = function (d) {
  this.catchAddress_ = d || 0;
  d = this.abruptCompletion_.exception;
  this.abruptCompletion_ = null;
  return d;
};
$jscomp.generator.Context.prototype.enterFinallyBlock = function (d, k, m) {
  m
    ? (this.finallyContexts_[m] = this.abruptCompletion_)
    : (this.finallyContexts_ = [this.abruptCompletion_]);
  this.catchAddress_ = d || 0;
  this.finallyAddress_ = k || 0;
};
$jscomp.generator.Context.prototype.leaveFinallyBlock = function (d, k) {
  var m = this.finallyContexts_.splice(k || 0)[0];
  if ((m = this.abruptCompletion_ = this.abruptCompletion_ || m)) {
    if (m.isException) return this.jumpToErrorHandler_();
    void 0 != m.jumpTo && this.finallyAddress_ < m.jumpTo
      ? ((this.nextAddress = m.jumpTo), (this.abruptCompletion_ = null))
      : (this.nextAddress = this.finallyAddress_);
  } else this.nextAddress = d;
};
$jscomp.generator.Context.prototype.forIn = function (d) {
  return new $jscomp.generator.Context.PropertyIterator(d);
};
$jscomp.generator.Context.PropertyIterator = function (d) {
  this.object_ = d;
  this.properties_ = [];
  for (var k in d) this.properties_.push(k);
  this.properties_.reverse();
};
$jscomp.generator.Context.PropertyIterator.prototype.getNext = function () {
  for (; 0 < this.properties_.length; ) {
    var d = this.properties_.pop();
    if (d in this.object_) return d;
  }
  return null;
};
$jscomp.generator.Engine_ = function (d) {
  this.context_ = new $jscomp.generator.Context();
  this.program_ = d;
};
$jscomp.generator.Engine_.prototype.next_ = function (d) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_.next,
      d,
      this.context_.next_
    );
  this.context_.next_(d);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.return_ = function (d) {
  this.context_.start_();
  var k = this.context_.yieldAllIterator_;
  if (k)
    return this.yieldAllStep_(
      "return" in k
        ? k["return"]
        : function (m) {
            return { value: m, done: !0 };
          },
      d,
      this.context_["return"]
    );
  this.context_["return"](d);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.throw_ = function (d) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_["throw"],
      d,
      this.context_.next_
    );
  this.context_.throw_(d);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.yieldAllStep_ = function (d, k, m) {
  try {
    var t = d.call(this.context_.yieldAllIterator_, k);
    $jscomp.generator.ensureIteratorResultIsObject_(t);
    if (!t.done) return this.context_.stop_(), t;
    var w = t.value;
  } catch (L) {
    return (
      (this.context_.yieldAllIterator_ = null),
      this.context_.throw_(L),
      this.nextStep_()
    );
  }
  this.context_.yieldAllIterator_ = null;
  m.call(this.context_, w);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.nextStep_ = function () {
  for (; this.context_.nextAddress; )
    try {
      var d = this.program_(this.context_);
      if (d) return this.context_.stop_(), { value: d.value, done: !1 };
    } catch (k) {
      (this.context_.yieldResult = void 0), this.context_.throw_(k);
    }
  this.context_.stop_();
  if (this.context_.abruptCompletion_) {
    d = this.context_.abruptCompletion_;
    this.context_.abruptCompletion_ = null;
    if (d.isException) throw d.exception;
    return { value: d["return"], done: !0 };
  }
  return { value: void 0, done: !0 };
};
$jscomp.generator.Generator_ = function (d) {
  this.next = function (k) {
    return d.next_(k);
  };
  this["throw"] = function (k) {
    return d.throw_(k);
  };
  this["return"] = function (k) {
    return d.return_(k);
  };
  this[Symbol.iterator] = function () {
    return this;
  };
};
$jscomp.generator.createGenerator = function (d, k) {
  var m = new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(k));
  $jscomp.setPrototypeOf &&
    d.prototype &&
    $jscomp.setPrototypeOf(m, d.prototype);
  return m;
};
$jscomp.asyncExecutePromiseGenerator = function (d) {
  function k(t) {
    return d.next(t);
  }
  function m(t) {
    return d["throw"](t);
  }
  return new Promise(function (t, w) {
    function L(O) {
      O.done ? t(O.value) : Promise.resolve(O.value).then(k, m).then(L, w);
    }
    L(d.next());
  });
};
$jscomp.asyncExecutePromiseGeneratorFunction = function (d) {
  return $jscomp.asyncExecutePromiseGenerator(d());
};
$jscomp.asyncExecutePromiseGeneratorProgram = function (d) {
  return $jscomp.asyncExecutePromiseGenerator(
    new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(d))
  );
};
document.addEventListener("DOMContentLoaded", function () {
  function d() {
    var l;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
      if (1 == b.nextAddress)
        return b.yield(chrome.storage.local.get("onBoarding"), 2);
      l = b.yieldResult;
      void 0 != l && l.onBoarding
        ? (ra(), $("#defaultOpen").click())
        : (void 0 == S && (S = "919356745862"),
          $("#onboardingNumber").val(S),
          $("#loadingScreen").hide(),
          $("#onboarding").show(),
          $("body").chardinJs("start"));
      b.jumpToEnd();
    });
  }
  function k(l, b, e) {
    var f, g, h, p;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (n) {
      if (1 == n.nextAddress)
        return (
          (f = new Headers()),
          f.append("Content-Type", "application/json"),
          n.yield(C("phoneNumber"), 2)
        );
      g = n.yieldResult;
      h = JSON.stringify({
        mainPhoneNumber: g.phoneNumber,
        collaboratorName: e,
        collaboratorPhoneNumber: b,
        type: l,
      });
      p = { method: "POST", headers: f, body: h, redirect: "follow" };
      fetch(Z + "/api/user/addCollaborator", p).then(function (q) {
        if (200 == q.status) return !0;
      });
      n.jumpToEnd();
    });
  }
  function m() {
    chrome.tabs.query({ active: !0, currentWindow: !0 }, function (l) {
      0 !== l.length &&
        l.forEach(function (b) {
          chrome.scripting.executeScript({
            target: { tabId: b.id },
            files: ["js/load.js"],
          });
        });
    });
  }
  function t(l, b, e) {
    iziToast.error({
      title: chrome.i18n.getMessage("iziToastExcelSizeError"),
      message: l,
      displayMode: 0,
      position: b,
      buttons: [
        [
          "<button>Okay</button>",
          function (f, g) {
            e();
            f.hide({ transitionOut: "fadeOut" }, g, "button");
          },
        ],
        [
          "<button>Upgrade Plan</button>",
          function (f, g) {
            return $jscomp.asyncExecutePromiseGeneratorProgram(function (h) {
              e();
              f.hide({ transitionOut: "fadeOut" }, g, "button");
              window.open("https://wamessager.com/pricing", "_blank");
              h.jumpToEnd();
            });
          },
          !0,
        ],
      ],
      onClosing: function (f, g, h) {},
      onClosed: function (f, g, h) {},
    });
  }
  function w(l) {
    l = l
      .replaceAll("<div>", "")
      .replaceAll("&nbsp;", " ")
      .replaceAll("</div>", "\n")
      .replaceAll("<br>", "");
    l = O("<strong>", l, "*");
    l = L("</strong>", l, "*");
    l = O("<del>", l, "~");
    l = L("</del>", l, "~");
    l = O("<em>", l, "_");
    return (l = L("</em>", l, "_"));
  }
  function L(l, b, e) {
    var f = b.match(new RegExp("\\s*" + l, "g"));
    f &&
      f.forEach(function (g) {
        var h = g.replace(l, "");
        h = e + h;
        b = b.replace(g, h);
      });
    return b;
  }
  function O(l, b, e) {
    var f = b.match(new RegExp(l + "\\s*", "g"));
    f &&
      f.forEach(function (g) {
        var h = g.replace(l, "");
        h += e;
        b = b.replace(g, h);
      });
    return b;
  }
  function za(l) {
    var b, e, f;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (g) {
      if (1 == g.nextAddress) {
        if (!l) return g["return"](!1);
        b = !0;
        16e6 < l.size &&
          ((e = l.size / 1048576),
          alert(
            chrome.i18n.getMessage("fileSizeAlert", [l.name, Math.ceil(e)])
          ),
          $("#formFileSm").val(""),
          (b = !1));
        return g.yield(C("attachment_data"), 2);
      }
      f = g.yieldResult;
      console.log(f);
      f = f.attachment_data || [];
      f.forEach(function (h) {
        h.fileName == l.name &&
          ((b = !1),
          alert(chrome.i18n.getMessage("fileDuplicateAlert", l.name)),
          $("#formFileSm").val(""));
      });
      return g["return"](b);
    });
  }
  function Aa(l) {
    return new Promise(function (b, e) {
      var f = new FileReader();
      f.readAsDataURL(l);
      f.onload = function () {
        return b(f.result);
      };
      f.onerror = function (g) {
        return e(g);
      };
    });
  }
  function na() {
    var l;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
      if (1 == b.nextAddress) return b.yield(C("attachment_data"), 2);
      if ((l = b.yieldResult) && l.attachment_data) l = l.attachment_data;
      else return b["return"]();
      6 < l.length
        ? ($("#add_attachment_button").attr("disabled", "disabled"),
          $("#add_attachment_button").addClass(" cursor-not-allowed"))
        : ($("#add_attachment_button").removeAttr("disabled"),
          $("#add_attachment_button").removeClass(" cursor-not-allowed"));
      document.getElementById("attachmentBody").setHTML("");
      l.forEach(function (e) {
        newAttachment = $("#sample-attachment-data").clone();
        newAttachment.prop("id", e.fileName);
        20 < e.fileName.length
          ? newAttachment
              .find(".fileName")
              .text(e.fileName.slice(0, 17) + "...")
          : newAttachment.find(".fileName").text(e.fileName);
        newAttachment.find(".fileType").text(e.fileType);
        16 < e.fileCaption.length
          ? newAttachment
              .find(".fileCaption")
              .text(e.fileCaption.slice(0, 13) + "...")
          : newAttachment.find(".fileCaption").text(e.fileCaption);
        newAttachment.removeClass("hidden");
        newAttachment.find(".fileEdit").click(function () {
          $("#attachmentModalTitle").text(
            chrome.i18n.getMessage("attachmentModalTitle_edit")
          );
          $("#formFileSm").hide();
          $("#file_input_help").hide();
          $("#attachment_modal_file_name").text(e.fileName);
          $("#attachment_modal_file_type").text(e.fileType);
          document.getElementById("attachment_modal_file_caption").value =
            e.fileCaption;
          V.show();
          T = e.fileName;
          "image" == e.fileType.split("/")[0] ||
          "video" == e.fileType.split("/")[0]
            ? $("#attachment_caption_area").show()
            : ((document.getElementById("attachment_modal_file_caption").value =
                ""),
              $("#attachment_caption_area").hide());
        });
        newAttachment.find(".fileDelete").click(function () {
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
            if (1 == f.nextAddress)
              return (
                console.log("delete for: ", e.fileName, " called"),
                (l = l.filter(function (g) {
                  return g.fileName != e.fileName;
                })),
                f.yield(x({ attachment_data: l }), 2)
              );
            na();
            f.jumpToEnd();
          });
        });
        $("#attachmentBody").append(newAttachment);
      });
      b.jumpToEnd();
    });
  }
  function aa(l, b) {
    var e;
    var f = document.getElementsByClassName("tabcontent");
    for (e = 0; e < f.length; e++) f[e].style.display = "none";
    f = document.getElementsByClassName("tablinks");
    for (e = 0; e < f.length; e++)
      f[e].className = f[e].className.replace(" active", "");
    document.getElementById(b).style.display = "block";
    l.currentTarget.className += " active";
  }
  function Ba(l) {
    var b = l.collaborators,
      e = l.planhistory[l.planhistory.length - 1].usageQuantityAllowed[0],
      f = b.length;
    b.map(function (g, h) {
      if (g.phoneNumber) {
        var p = $(".teamMember").eq(0).clone();
        p.prop("id", g.phoneNumber).removeClass("hidden");
        p.find(".memberName").text(g.name);
        p.find(".memberNumber").text(g.phoneNumber);
        p.find(".removeMember").on("click", function () {
          var n;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (q) {
            $("#" + g.phoneNumber).remove();
            n = b.indexOf(b[h]);
            -1 < n &&
              (b.splice(n, 1), (l.collaborators = b), x({ mainUser: l }));
            --f;
            $("#memberCount").html(
              chrome.i18n.getMessage("memberCount", [f, e])
            );
            0 == f && $("#noteamMember").show();
            k("REMOVE", g.phoneNumber, "");
            $("#addMember").removeAttr("disabled");
            q.jumpToEnd();
          });
        });
        $("#memberTable").append(p);
      }
    });
  }
  function ra() {
    function l(n, q, v, I) {
      chrome.tabs.query({ active: !0, currentWindow: !0 }).then(function (y) {
        chrome.tabs.sendMessage(y[0].id, {
          context: {
            download_group: "true",
            exportType: n,
            groupIds: q,
            isAllGroupSelected: v,
            listOption: I,
            groupList: h,
            chatList: p,
          },
        });
      });
    }
    function b() {
      chrome.tabs.query({ active: !0, currentWindow: !0 }).then(function (n) {
        chrome.tabs.sendMessage(
          n[0].id,
          { context: { get_contacts: "true" } },
          function (q) {
            h = q.groupList;
            p = q.chatList;
            groupSelector.setChoices(
              h.map(function (v) {
                return { value: v.groupId, label: v.groupName };
              }),
              "value",
              "label",
              "false"
            );
          }
        );
      });
    }
    var e, f, g, h, p;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (n) {
      if (1 == n.nextAddress) return n.yield(C("phoneNumber"), 2);
      e = n.yieldResult;
      f = {
        url: Z + "/api/user/getUser?phoneNumber=" + e.phoneNumber,
        method: "GET",
        timeout: 0,
      };
      g = chrome.runtime.getManifest();
      $("#myNumber").text("+" + e.phoneNumber);
      $("#myVersion").show();
      $("#myVersion").text("V~" + g.version);
      $.ajax(f)
        .done(function (q) {
          var v, I, y, F, z, A, r;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (u) {
            switch (u.nextAddress) {
              case 1:
                if (!q.success) {
                  $("#loadingScreenLoader").hide();
                  $("#loadingScreenErrorMessage").css("display", "flex");
                  u.jumpTo(0);
                  break;
                }
                $("#loadingScreen").hide();
                $("#onboarding,#unsynced").hide();
                $("#synced").show();
                G = q.user;
                is_premium = q.isPremium;
                v = G.planhistory[G.planhistory.length - 1];
                I = G.collaborators;
                q.parentPhoneNumber &&
                  ($("#adminNumber").show(),
                  $("#adminNumber").html(
                    chrome.i18n.getMessage("adminNumber", [q.parentPhoneNumber])
                  ));
                if (is_premium) {
                  y = new Date(q.planEndDate) - new Date();
                  y /= 864e5;
                  y = Math.ceil(y);
                  F = "<b> PREMIUM</b>";
                  F =
                    3 < y
                      ? F + ("<br> Days Remaining: " + y)
                      : F +
                        ('<br><span style="color:red"><b> Days Remaining: ' +
                          y +
                          "</b></span>");
                  $("#messageCountDiv").css("font-size", "20px");
                  $("#premiumUser").show();
                  $("#planInfo").html(F);
                  $("#messageCount").html(
                    "<strong>" + G.messagesSent + "</strong>"
                  );
                  $("#dailyLimitDiv").hide();
                  $("#extMessageCount").text(
                    chrome.i18n.getMessage("extMessageCount")
                  );
                  u.jumpTo(3);
                  break;
                }
                $("#extMessageCount").text(
                  chrome.i18n.getMessage("extMessageCountDailyCount")
                );
                $("#dailyMsgReset").text(
                  chrome.i18n.getMessage("dailyMsgReset")
                );
                return u.yield(C("DAILY_MSG_LEFT"), 4);
              case 4:
                return void 0 == u.yieldResult.DAILY_MSG_LEFT
                  ? u.yield(x({ DAILY_MSG_LEFT: K }), 6)
                  : u.yield(C("DAILY_MSG_LEFT"), 7);
              case 7:
                K = u.yieldResult.DAILY_MSG_LEFT;
                u.jumpTo(6);
                break;
              case 6:
                if (50 != K) {
                  u.jumpTo(9);
                  break;
                }
                return u.yield(x({ DAILY_MSG_LATEST_TIMESTAMP: P }), 9);
              case 9:
                return u.yield(C("DAILY_MSG_LATEST_TIMESTAMP"), 11);
              case 11:
                return void 0 == u.yieldResult.DAILY_MSG_LATEST_TIMESTAMP
                  ? u.yield(x({ DAILY_MSG_LATEST_TIMESTAMP: P }), 13)
                  : u.yield(C("DAILY_MSG_LATEST_TIMESTAMP"), 14);
              case 14:
                P = u.yieldResult.DAILY_MSG_LATEST_TIMESTAMP;
                u.jumpTo(13);
                break;
              case 13:
                z = (Date.now() - P) / 36e5;
                z = 24 - z;
                if (!(0 >= z)) {
                  50 == K
                    ? $("#dailyMsgResetTime").text("24 Hrs")
                    : 1 < z
                    ? $("#dailyMsgResetTime").text(
                        Math.floor(z) +
                          " hr " +
                          Math.floor((60 * z) % 60) +
                          " min"
                      )
                    : $("#dailyMsgResetTime").text(Math.ceil(60 * z) + " min");
                  u.jumpTo(16);
                  break;
                }
                P = Date.now();
                K = 50;
                return u.yield(x({ DAILY_MSG_LEFT: K }), 17);
              case 17:
                return u.yield(x({ DAILY_MSG_LATEST_TIMESTAMP: P }), 18);
              case 18:
                $("#dailyMsgResetTime").text("24 Hrs");
              case 16:
                0 == K &&
                  ($("#send").attr("disabled", !0),
                  $("#send").css("background-color", "grey")),
                  $("#messageCount").html("<strong>" + K + "</strong>"),
                  sa();
              case 3:
                return u.yield(x({ mainUser: G }), 19);
              case 19:
                (A = v.usageQuantityAllowed[0]),
                  (r = I.length),
                  0 != r
                    ? $("#noteamMember").hide()
                    : $("#noteamMember").show(),
                  $("#memberCount").html(
                    chrome.i18n.getMessage("memberCount", [r, A])
                  ),
                  is_premium
                    ? 0 == A
                      ? ($("#noteamMember").text(
                          "Upgrade plan to add team members"
                        ),
                        $("#addMember").attr("disabled", !0))
                      : r >= A && $("#addMember").attr("disabled", !0)
                    : ($("#noteamMember").text(
                        "Buy Premium to add team members"
                      ),
                      $("#addMember").attr("disabled", !0)),
                  Ba(G),
                  u.jumpToEnd();
            }
          });
        })
        ["catch"](function () {
          $("#loadingScreenLoader").hide();
          $("#loadingScreenErrorMessage").css("display", "flex");
        });
      groupSelector = new Choices("#choices-multiple-remove-button", {
        removeItemButton: !0,
        placeholder: !0,
        placeholderValue: chrome.i18n.getMessage("exportGroupPlaceholder"),
      });
      $("#number").attr("placeholder", oa);
      $("#number").tokenfield({ inputType: "tel", createTokensOnBlur: !0 });
      groupSelector.passedElement.element.addEventListener(
        "addItem",
        function (q) {
          $("#selectAllGroups").prop("checked", !1);
          Q = !1;
          $("#export-group").attr("disabled", !1);
        },
        !1
      );
      groupSelector.passedElement.element.addEventListener(
        "removeItem",
        function (q) {
          R = groupSelector.getValue().map(function (v) {
            return v.value;
          });
          0 == R.length && $("#export-group").attr("disabled", !0);
        },
        !1
      );
      h = [];
      p = [];
      ba = $('input[name="chatListOptions"]:checked').val();
      $("#selectAllGroups").change(function () {
        this.checked
          ? (groupSelector.removeActiveItems(),
            (Q = !0),
            $("#export-group").attr("disabled", !1))
          : ((Q = !1), $("#export-group").attr("disabled", !0));
      });
      $("#export-group").click(function () {
        R = groupSelector.getValue().map(function (q) {
          return q.value;
        });
        (0 < R.length || Q) && l("group", R, Q, ba);
      });
      $("#export-list").click(function () {
        l("list", R, Q, ba);
      });
      $('input[name="chatListOptions"]').change(function () {
        ba = $('input[name="chatListOptions"]:checked').val();
      });
      $("#download_members").click(function () {
        b();
      });
      n.jumpToEnd();
    });
  }
  function Ca(l, b, e) {
    var f, g, h;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (p) {
      f = new Headers();
      f.append("Content-Type", "application/json");
      g = JSON.stringify({ email: l, phoneNumber: b });
      h = { method: "POST", headers: f, body: g, redirect: "follow" };
      fetch(Z + "/api/user/createUser", h)
        .then(function (n) {
          return n.json();
        })
        .then(function (n) {
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (q) {
            if (1 == q.nextAddress)
              return q.yield(chrome.storage.local.set({ phoneNumber: b }), 2);
            if (3 != q.nextAddress)
              return (S = n.supportNumber), q.yield(d(), 3);
            $("#defaultOpen").text(chrome.i18n.getMessage("tabHome"));
            $("#Collaborators").text(chrome.i18n.getMessage("tabTeam"));
            $("#Premium").text(chrome.i18n.getMessage("tabPremium"));
            $("#Tutorials").text(chrome.i18n.getMessage("tabTutorials"));
            $("#execlSheetBtnText").text(
              chrome.i18n.getMessage("uploadExcelBtn")
            );
            $("#downloadExcelTemplateText").text(
              chrome.i18n.getMessage("downloadTemplateBtn")
            );
            $("#filter_numbersText").text(chrome.i18n.getMessage("filterBtn"));
            $("#download_membersText").text(
              chrome.i18n.getMessage("downloadGroupBtn")
            );
            $("#options_divText").text(
              chrome.i18n.getMessage("options_divText")
            );
            oa = chrome.i18n.getMessage("numberPlaceholder");
            ta = chrome.i18n.getMessage("numberPlaceholderDisabled");
            $("#sorted-number-filterText").text(
              chrome.i18n.getMessage("sortedNumberFilterText")
            );
            $("#DownloadGroupHeadingText").text(
              chrome.i18n.getMessage("downloadGroupHeadingText")
            );
            $("#exportGroupText").text(
              chrome.i18n.getMessage("exportGroupText")
            );
            $("#export-group").text(chrome.i18n.getMessage("exportGroup"));
            $("#selectAllGroupsText").text(
              chrome.i18n.getMessage("selectAllGroupsText")
            );
            $("#export-from-listText").text(
              chrome.i18n.getMessage("exportFromListText")
            );
            $("#export-list").text(chrome.i18n.getMessage("exportList"));
            $("#allChatsText").text(chrome.i18n.getMessage("allChatsText"));
            $("#unsavedChatsText").text(
              chrome.i18n.getMessage("unsavedChatsText")
            );
            $("#downloadGroupCloseBtnText").text(
              chrome.i18n.getMessage("downloadGroupCloseBtnText")
            );
            $("#clear").text(chrome.i18n.getMessage("clear"));
            $("#messageSettingsText").text(
              chrome.i18n.getMessage("messageSettingsText")
            );
            $("#send_attachmentsText").text(
              chrome.i18n.getMessage("send_attachmentsText")
            );
            $("#unsubscribe_optionText").text(
              chrome.i18n.getMessage("unsubscribe_optionText")
            );
            $("#addTimeStamp_optionText").html(
              chrome.i18n.getMessage("addTimeStamp_optionText")
            );
            $("#custom_divText").text(chrome.i18n.getMessage("custom_divText"));
            $("#timer-checkboxText").text(
              chrome.i18n.getMessage("timerCheckboxText")
            );
            $("#message-lineText").text(chrome.i18n.getMessage("msgLineText"));
            $("#message-overflow-text").text(
              chrome.i18n.getMessage("msgOverflowText")
            );
            $("#error-text").text(chrome.i18n.getMessage("errortext"));
            $("#addTemplateText").text(
              chrome.i18n.getMessage("addTemplateText")
            );
            $("#planInfoText").text(chrome.i18n.getMessage("planInfoText"));
            $("#supportFooter").text(chrome.i18n.getMessage("supportFooter"));
            $("#SupportTutorial").text(chrome.i18n.getMessage("supportFooter"));
            $("#pauseBtnText").text(chrome.i18n.getMessage("pauseBtnText"));
            $("#continueBtnText").text(
              chrome.i18n.getMessage("continueBtnText")
            );
            $("#stopBtnText").text(chrome.i18n.getMessage("stopBtnText"));
            $("#sendBtnText").text(chrome.i18n.getMessage("sendBtnText"));
            $("#reportBtnText").text(chrome.i18n.getMessage("reportBtnText"));
            $("#addMemberHeadingText").text(
              chrome.i18n.getMessage("addMemberHeadingText")
            );
            $("#addMemberBtnText").text(
              chrome.i18n.getMessage("addMemberBtnText")
            );
            $("#teamMemberNameText").text(
              chrome.i18n.getMessage("teamMemberNameText")
            );
            $("#teamMemberPhoneNumberText").text(
              chrome.i18n.getMessage("teamMemberPhoneNumberText")
            );
            $("#RemoveMemberText").text(
              chrome.i18n.getMessage("RemoveMemberText")
            );
            $("#getPremiumHeading").text(
              chrome.i18n.getMessage("getPremiumHeading")
            );
            $("#getPremium1").text(chrome.i18n.getMessage("getPremium1"));
            $("#getPremium2").text(chrome.i18n.getMessage("getPremium2"));
            $("#getPremium3").text(chrome.i18n.getMessage("getPremium3"));
            $("#getPremium4").text(chrome.i18n.getMessage("getPremium4"));
            $("#getPremium5").text(chrome.i18n.getMessage("getPremium5"));
            $("#getPremium6").text(chrome.i18n.getMessage("getPremium6"));
            $("#getPremium7").text(chrome.i18n.getMessage("getPremium7"));
            $("#getPremium8").text(chrome.i18n.getMessage("getPremium8"));
            $("#buypremium1").text(chrome.i18n.getMessage("tabPremium"));
            $(".premmium_feature").text(
              chrome.i18n.getMessage("premmium_feature")
            );
            $(".template_premmium_feature").text(
              chrome.i18n.getMessage("template_premmium_feature")
            );
            $("#firstMessageText").text(
              chrome.i18n.getMessage("firstMessageText")
            );
            $("#firstMessageReadyText").text(
              chrome.i18n.getMessage("firstMessageReadyText")
            );
            $("#onboardingMessage").html(
              chrome.i18n.getMessage("onboardingMessage")
            );
            $("#onboardingSendText").text(
              chrome.i18n.getMessage("onboardingSendText")
            );
            $(".chardinjs-tooltiptext").text(
              chrome.i18n.getMessage("onboardingSendIntro")
            );
            $("#syncMsgText").text(chrome.i18n.getMessage("syncMsgText"));
            $("#syncMessageNote").text(
              chrome.i18n.getMessage("syncMessageNote")
            );
            $("#uncheck_attachment").text(
              chrome.i18n.getMessage("uncheck_attachment")
            );
            $("#imageAttmntText").text(
              chrome.i18n.getMessage("imageAttmntText")
            );
            $("#docAttmntText").text(chrome.i18n.getMessage("docAttmntText"));
            $("#contactAttmntText").text(
              chrome.i18n.getMessage("contactAttmntText")
            );
            $("#timeGapText").text(chrome.i18n.getMessage("timeGapText"));
            $("#timeGapSeconds").text(chrome.i18n.getMessage("timeGapSeconds"));
            $("#timeGapRandomText").text(
              chrome.i18n.getMessage("timeGapRandomText")
            );
            $("#msgSentDisplayText").text(
              chrome.i18n.getMessage("msgSentDisplayText")
            );
            $("#addTeamMemberNote").text(
              chrome.i18n.getMessage("addTeamMemberNote")
            );
            $("#addMemberModalName").text(
              chrome.i18n.getMessage("teamMemberNameText")
            );
            $("#addMemberModalNumber").text(
              chrome.i18n.getMessage("teamMemberPhoneNumberText")
            );
            $("#addMemberAddBtnText").text(
              chrome.i18n.getMessage("addMemberAddBtnText")
            );
            $("#removeTeamMemberButton").text(
              chrome.i18n.getMessage("removeTeamMemberButton")
            );
            $("#memberName").attr(
              "placeholder",
              chrome.i18n.getMessage("addTeamMemberPlaceholder")
            );
            $("#memberPhone").attr(
              "placeholder",
              chrome.i18n.getMessage("addTeamMemberPhonePlaceholder")
            );
            $("#EnhancementSettings").text(
              chrome.i18n.getMessage("EnhancementSettings")
            );
            $("#blurToggleAllText").text(
              chrome.i18n.getMessage("blurToggleAllText")
            );
            $("#blurToggleAllText")
              .parent()
              .attr("title", chrome.i18n.getMessage("blurToggleAllTextTitle"));
            $("#blurAllMessageToggleText").text(
              chrome.i18n.getMessage("blurAllMessageToggleText")
            );
            $("#blurAllMessageToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurAllMessageToggleTextTitle")
              );
            $("#blurLastMesssageToggleText").text(
              chrome.i18n.getMessage("blurLastMesssageToggleText")
            );
            $("#blurLastMesssageToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurLastMesssageToggleTextTitle")
              );
            $("#blurMediaPreviewToggleText").text(
              chrome.i18n.getMessage("blurMediaPreviewToggleText")
            );
            $("#blurMediaPreviewToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurMediaPreviewToggleTextTitle")
              );
            $("#blurMediaGallaryToggleText").text(
              chrome.i18n.getMessage("blurMediaGallaryToggleText")
            );
            $("#blurMediaGallaryToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurMediaGallaryToggleTextTitle")
              );
            $("#blurTextInputToggleText").text(
              chrome.i18n.getMessage("blurTextInputToggleText")
            );
            $("#blurTextInputToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurTextInputToggleTextTitle")
              );
            $("#blurProfilePictureToggleText").text(
              chrome.i18n.getMessage("blurProfilePictureToggleText")
            );
            $("#blurProfilePictureToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurProfilePictureToggleTextTitle")
              );
            $("#blurGroupUserNameToggleText").text(
              chrome.i18n.getMessage("blurGroupUserNameToggleText")
            );
            $("#blurGroupUserNameToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("blurGroupUserNameToggleTextTitle")
              );
            $("#noTransitionDelayToggleText").text(
              chrome.i18n.getMessage("noTransitionDelayToggleText")
            );
            $("#noTransitionDelayToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("noTransitionDelayToggleTextTitle")
              );
            $("#unblurAllToggleText").text(
              chrome.i18n.getMessage("unblurAllToggleText")
            );
            $("#unblurAllToggleText")
              .parent()
              .attr(
                "title",
                chrome.i18n.getMessage("unblurAllToggleTextTitle")
              );
            $("#reviewFooter").text(chrome.i18n.getMessage("reviewFooter"));
            $("#Enhancement").text(chrome.i18n.getMessage("Enhancement"));
            $("#attachmentAddButton").text(
              chrome.i18n.getMessage("attachmentAddButton")
            );
            $("#attachmentFileName").text(
              chrome.i18n.getMessage("attachmentFileName")
            );
            $("#attachmentFileType").text(
              chrome.i18n.getMessage("attachmentFileType")
            );
            $("#attachmentFileCaption").text(
              chrome.i18n.getMessage("attachmentFileCaption")
            );
            $("#attachmentFileAction").text(
              chrome.i18n.getMessage("attachmentFileAction")
            );
            $(".fileEdit").text(chrome.i18n.getMessage("attachmentEditAction"));
            $(".fileDelete").text(
              chrome.i18n.getMessage("attachmentDeleteAction")
            );
            $("#attachmentNote").text(chrome.i18n.getMessage("attachmentNote"));
            $("#file_input_help").text(
              chrome.i18n.getMessage("file_input_help")
            );
            $("#attachment_modal_file_name_text").text(
              chrome.i18n.getMessage("attachment_modal_file_name_text")
            );
            $("#attachment_modal_file_type_text").text(
              chrome.i18n.getMessage("attachment_modal_file_type_text")
            );
            $("#attachment_caption").text(
              chrome.i18n.getMessage("attachment_caption")
            );
            $("#attachment_modal_file_caption").attr(
              "placeholder",
              chrome.i18n.getMessage(
                "attachment_modal_file_caption_placeholder"
              )
            );
            $("#attachment_modal_submit").text(
              chrome.i18n.getMessage("attachment_modal_submit")
            );
            q.jumpToEnd();
          });
        })
        ["catch"](function (n) {
          console.log(n);
          $("#loadingScreenLoader").hide();
          $("#loadingScreenErrorMessage").css("display", "flex");
        });
      p.jumpToEnd();
    });
  }
  function Da() {
    chrome.tabs.query({ active: !0, currentWindow: !0 }).then(function (l) {
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
        c = l[0].id;
        return b.yield(
          chrome.tabs.sendMessage(c, { greeting: "hello" }, function (e) {
            return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
              if (void 0 === e || null == e.number)
                return (
                  $("#reload").show(),
                  $("#reloadTab").click(function (g) {
                    chrome.tabs.reload(c);
                    window.close();
                  }),
                  $("#loadingScreen").hide(),
                  f.jumpTo(0)
                );
              ua = e.number;
              va = e.date;
              return f.yield(
                chrome.identity.getProfileUserInfo(function (g) {
                  return $jscomp.asyncExecutePromiseGeneratorProgram(function (
                    h
                  ) {
                    if (1 == h.nextAddress) {
                      if (!g)
                        return (
                          $("#reload").show(),
                          $("#reloadTab").click(function (p) {
                            chrome.tabs.reload(g);
                            window.close();
                          }),
                          $("#loadingScreen").hide(),
                          h.jumpTo(0)
                        );
                      if (!g.id)
                        return (
                          $("#loadingScreen").hide(),
                          $("#unsynced").show(),
                          $("#synced").hide(),
                          h.jumpTo(3)
                        );
                      wa = g.email;
                      return h.yield(Ca(wa, ua, va), 4);
                    }
                    h.jumpToEnd();
                  });
                }),
                0
              );
            });
          }),
          0
        );
      });
    });
  }
  var ua,
    wa,
    va,
    Z,
    R,
    Q,
    ba,
    oa,
    ta,
    S,
    G,
    pa,
    J,
    xa,
    W,
    U,
    X,
    Y,
    ya,
    H,
    K,
    P,
    D,
    ca,
    V,
    T,
    M,
    da,
    ea,
    fa,
    ha,
    ia,
    ja,
    ka,
    la,
    ma,
    sa,
    x,
    C;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (l) {
    if (1 == l.nextAddress)
      return (
        (Z = "https://wamessager-backend.onrender.com"),
        (R = []),
        (Q = !0),
        (o = document.getElementById("first")),
        (s = document.getElementById("second")),
        (a = document.getElementById("premium_box")),
        (c = document.getElementById("free_messsag_count")),
        (top_free_message_count = document.getElementById(
          "top_free_message_count"
        )),
        (is_premium = !1),
        (total_messages = 0),
        (mediaType = null),
        (timeDelay = 1),
        (batchDelay = batchSize = "0"),
        (to_coloumn = from_coloumn = 0),
        (timer_gap_random = !1),
        (J = {}),
        (xa = document.getElementById("send")),
        (W = []),
        (Y = X = U = !1),
        (H = "STOP"),
        (K = 50),
        (P = Date.now()),
        (ca = !1),
        l.yield(
          chrome.tabs.query(
            { url: "https://web.whatsapp.com/*", currentWindow: !0 },
            function (b) {
              0 < b.length
                ? ((ya = b[0].id),
                  chrome.tabs.update(ya, { active: !0, highlighted: !0 }))
                : chrome.tabs.create({ url: "https://web.whatsapp.com/" });
              Da();
            }
          ),
          2
        )
      );
    D = SUNEDITOR.create(document.getElementById("message"), {
      buttonList: [["bold", "italic", "strike"]],
      pasteTagsWhitelist: "b|strong|del|em|div|i|strike",
      attributesBlacklist: { all: "*" },
      frameAttrbutes: { spellcheck: !1 },
      height: "150px",
      showPathLabel: !1,
      placeholder: chrome.i18n.getMessage("messagePlaceholder"),
      defaultTag: "div",
    });
    D.setDefaultStyle(
      "font-family:sans-serif; font-size: 15px; line-height:1.2em"
    );
    D.onChange = function (b, e) {
      text = D.getContents();
      ca ||
        ($("#template-dropdown").selectpicker("val", "default"),
        $("#deleteTemplate").css("display", "none"));
      ca = !1;
      chrome.storage.local.set({ text: text });
    };
    $("#defaultOpen").click(function (b) {
      aa(b, "SendMessages");
    });
    $("#Premium").click(function (b) {
      aa(b, "GetPremium");
    });
    $("#buypremium,#premium2,#top_premium,#buypremium1").click(function () {
      window.open("https://wamessager.com/pricing");
    });
    $("#Collaborators").click(function (b) {
      aa(b, "collaboratorsTab");
    });
    $("#Enhancement").click(function (b) {
      aa(b, "EnhancementTab");
    });
    $("#execlSheetBtn").on("change", function (b) {
      if ((pa = b.target.files[0]))
        if (5 < Math.round(pa.size / 1048576))
          iziToast.error({
            title: chrome.i18n.getMessage("iziToastExcelSizeError"),
            message: chrome.i18n.getMessage("iziToastExcelSizeErrorMsg"),
            displayMode: 0,
            position: "topRight",
          });
        else {
          $("#number-tokenfield").attr("placeholder", ta);
          $("#number").tokenfield("disable");
          $("#personalizedVariable").text("Select Variable");
          var e = new FileReader();
          e.onload = function (f) {
            f = new Uint8Array(f.target.result);
            f = XLSX.read(f, { type: "array" });
            J = XLSX.utils.sheet_to_json(f.Sheets[f.SheetNames[0]], {
              header: "A",
            });
            null == J[0] || void 0 == J[0]
              ? $("#deleteExecl").click()
              : chrome.storage.local.set({ contacts: J }, function () {
                  $("#contacts-found").text(
                    chrome.i18n.getMessage("contactFoundText", [J.length - 1])
                  );
                  $("#contacts-found").css("display", "flex");
                  $("#send").attr("disabled", !1);
                  for (
                    var g = $jscomp.makeIterator(Object.entries(J[0])),
                      h = g.next();
                    !h.done;
                    h = g.next()
                  ) {
                    var p = $jscomp.makeIterator(h.value);
                    h = p.next().value;
                    p = p.next().value;
                    var n = document.getElementById("options"),
                      q = document.getElementById("token"),
                      v = document.createElement("option");
                    v.name = "..";
                    v.value = h;
                    v.innerText = p;
                    o2 = v.cloneNode(!0);
                    n.appendChild(v);
                    q.appendChild(o2);
                    n.style.display = "";
                    $("#options_div").css("display", "block");
                    $("#deleteExecl").css("display", "block");
                    $("#filter_numbers").css("display", "flex");
                    $("#downloadExcelTemplate").css("display", "none");
                    document.getElementById(
                      "execlSheetBtn"
                    ).parentElement.style.display = "none";
                  }
                  g = $jscomp.makeIterator(Object.entries(J[1]));
                  for (h = g.next(); !h.done; h = g.next())
                    if (
                      ((h = $jscomp.makeIterator(h.value)),
                      (p = h.next().value),
                      4 <
                        h
                          .next()
                          .value.toString()
                          .replace(/\D/g, "")
                          .replace(/^0+/, "").length)
                    ) {
                      $("#options").val(p);
                      chrome.storage.local.set({
                        numberColumn: $("#options").val(),
                      });
                      break;
                    }
                });
          };
          e.readAsArrayBuffer(pa);
          b.target.value = "";
        }
    });
    $("#options").change(function () {
      chrome.storage.local.set({ numberColumn: $("#options").val() });
    });
    $("#deleteExecl").click(function () {
      chrome.storage.local.remove(["contacts"], function () {
        for (var b = document.getElementById("options").lastElementChild; b; )
          document.getElementById("options").removeChild(b),
            (b = document.getElementById("options").lastElementChild);
        J = {};
        $("#contacts-found").text(
          chrome.i18n.getMessage("contactFoundText", [0])
        );
        $("#send").attr("disabled", !0);
        b = document.getElementById("token").lastElementChild;
        for (
          firstChile = document
            .getElementById("token")
            .firstElementChild.cloneNode(!0);
          b;

        )
          document.getElementById("token").removeChild(b),
            (b = document.getElementById("token").lastElementChild);
        document.getElementById("token").appendChild(firstChile);
        $("#options_div").css("display", "none");
        $("#deleteExecl").css("display", "none");
        $("#filter_numbers").css("display", "none");
        document.getElementById("execlSheetBtn").parentElement.style.display =
          "flex";
        $("#downloadExcelTemplate").css("display", "flex");
        $("#is_custom_message").is(":checked") &&
          $("#is_custom_message").click();
        $("#personalizedVariable").text(
          chrome.i18n.getMessage("uploadExcelBtn")
        );
        $("#number-tokenfield").attr("placeholder", oa);
        $("#number").tokenfield("enable");
        $("#sheet_number").attr("disabled", !1);
        $("#verifyGoogleSheet").attr("disabled", !1);
        $("#verifyGoogleSheet").addClass(
          "bg-green-700 hover:bg-green-900 cursor-pointer text-white font-bold py-2 px-4 rounded h-100 mr-5 inline-flex items-center"
        );
        chrome.storage.local.remove("numberColumn");
      });
    });
    $("#downloadExcelTemplate").on("click", function () {
      context = { downloadExcelTemplate: !0 };
      chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
        chrome.tabs.sendMessage(b[0].id, { context: context }, function () {});
      });
    });
    $("#filter_numbers").on("click", function () {
      chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
        b = b[0];
        contacts = [];
        column = $("#options").find(":selected").val();
        H = "SEND";
        chrome.storage.local.set({ currentState: H }, function () {
          $("#send").css("display", "none");
          $("#stop").css("display", "");
          $("#pause").css("display", "");
          $("#continue").css("display", "none");
          $("#export_results").css("display", "none");
        });
        for (var e = 1; e < J.length; e++) {
          var f = J[e][column];
          void 0 == f || null == f ? contacts.push("") : contacts.push(f);
        }
        chrome.tabs.sendMessage(b.id, {
          context: { filter_numbers: "true" },
          arr: contacts,
        });
      });
    });
    $("#number").on("change", function () {
      var b = document.querySelector("input#number").value;
      if (0 < b.length) {
        $("#sheet_number").attr("disabled", !0);
        $("#input").attr("disabled", !0);
        $("#input")
          .parent()
          .closest("label")
          .removeClass("bg-green-700 hover:bg-green-900");
        $("#input").parent().closest("label").addClass("bg-gray-700");
        $("#input")
          .parent()
          .closest("label")
          .attr("title", "Delete numbers from below to upload excel sheet");
        $("#downloadExcelTemplate").attr("disabled", !0);
        $("#deleteExcelTemplate").attr("disabled", !0);
        var e = b.replace(/[^\d,]/g, "");
        e = e.split(",");
        e = e.filter(function (f) {
          return f;
        });
        $("#contacts-found").text(
          chrome.i18n.getMessage("contactFoundText", [e.length])
        );
        $("#contacts-found").css("display", "flex");
        $("#send").attr("disabled", !1);
      } else $("#sheet_number").attr("disabled", !1), $("#input").attr("disabled", !1), $("#input").parent().closest("label").attr("title", ""), $("#input").parent().closest("label").addClass("bg-green-700 hover:bg-green-900 cursor-pointer text-white font-bold py-2 px-4 rounded h-100 mr-5 inline-flex items-center"), $("#downloadExcelTemplate").removeAttr("disabled"), $("#contacts-found").text(chrome.i18n.getMessage("contactFoundText", [0])), $("#send").attr("disabled", !0);
      chrome.storage.local.set({ numbersList: b }, function () {});
    });
    $("#clear").click(function () {
      "" != document.querySelector("input#number").value &&
        ((document.querySelector("input#number").value = ""),
        $("input#number").tokenfield("setTokens", []),
        $("#sheet_number").attr("disabled", !1),
        $("#input").attr("disabled", !1),
        $("#input").parent().closest("label").attr("title", ""),
        $("#input")
          .parent()
          .closest("label")
          .addClass(
            "bg-green-700 hover:bg-green-900 cursor-pointer text-white font-bold py-2 px-4 rounded h-100 mr-5 inline-flex items-center"
          ),
        $("#downloadExcelTemplate").removeAttr("disabled"),
        $("#contacts-found").text(
          chrome.i18n.getMessage("contactFoundText", [0])
        ),
        $("#send").attr("disabled", !0),
        chrome.storage.local.set({ numbersList: "" }, function () {}));
    });
    $("#send_attachments").change(function () {
      (U = $("#send_attachments").is(":checked"))
        ? ((document.getElementById("steps_for_attachments").style.display =
            "flex"),
          $("#add_attachment_button").removeClass("hidden"))
        : ((document.getElementById("steps_for_attachments").style.display =
            "none"),
          $("#add_attachment_button").addClass("hidden"));
    });
    V = new Modal(document.getElementById("small-modal"));
    $("#add_attachment_button").click(function (b) {
      $("#attachmentModalTitle").text(
        chrome.i18n.getMessage("attachmentModalTitle_add")
      );
      V.show();
      $("#formFileSm").show();
      $("#file_input_help").show();
    });
    $("#attachment_close_button").click(function () {
      T = null;
      $("#attachment_caption_area").hide();
      $("#formFileSm").val("");
      $("#attachment_modal_file_name").text("");
      $("#attachment_modal_file_type").text("");
      document.getElementById("attachment_modal_file_caption").value = "";
      V.hide();
    });
    $("#formFileSm").change(function () {
      var b = this,
        e;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
        if (1 == f.nextAddress)
          return (
            console.log("file uploaded", $(b)),
            (e = $(b).get(0).files[0]),
            f.yield(za(e), 2)
          );
        f.yieldResult
          ? ($("#attachment_modal_file_name").text(e.name),
            $("#attachment_modal_file_type").text(e.type),
            "image" == e.type.split("/")[0] || "video" == e.type.split("/")[0]
              ? $("#attachment_caption_area").show()
              : ((document.getElementById(
                  "attachment_modal_file_caption"
                ).value = ""),
                $("#attachment_caption_area").hide()))
          : ($("#attachment_modal_file_name").text(""),
            $("#attachment_modal_file_type").text(""));
        f.jumpToEnd();
      });
    });
    $("#attachment_modal_submit").click(function () {
      var b, e, f, g;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (h) {
        switch (h.nextAddress) {
          case 1:
            return h.yield(C("attachment_data"), 2);
          case 2:
            b = h.yieldResult;
            console.log(b);
            b = b.attachment_data || [];
            if (T) {
              h.jumpTo(3);
              break;
            }
            e = document.getElementById("formFileSm").files[0];
            console.log(e);
            return e
              ? h.yield(
                  new Promise(function (p) {
                    Aa(e).then(function (n) {
                      var q = {};
                      q.fileName = e.name;
                      q.fileType = e.type;
                      q.fileData = JSON.stringify(n);
                      q.fileCaption = document.getElementById(
                        "attachment_modal_file_caption"
                      ).value;
                      p(q);
                    });
                  }),
                  5
                )
              : (alert(chrome.i18n.getMessage("fileEmptyAlert")),
                h["return"]());
          case 5:
            return (
              (f = h.yieldResult),
              console.log("ADD NEW ATTMT", f),
              b.push(f),
              h.yield(x({ attachment_data: b }), 4)
            );
          case 3:
            console.log("Edit ATTMT: ", T), (g = 0);
          case 7:
            if (!(g < b.length)) {
              h.jumpTo(4);
              break;
            }
            if (b[g].fileName !== T) {
              h.jumpTo(8);
              break;
            }
            console.log(
              "found",
              b[g],
              document.getElementById("attachment_modal_file_caption").value
            );
            b[g].fileCaption = document.getElementById(
              "attachment_modal_file_caption"
            ).value;
            return h.yield(x({ attachment_data: b }), 11);
          case 11:
            h.jumpTo(4);
            break;
          case 8:
            g++;
            h.jumpTo(7);
            break;
          case 4:
            (T = null),
              $("#attachment_caption_area").hide(),
              $("#formFileSm").val(""),
              $("#attachment_modal_file_name").text(""),
              $("#attachment_modal_file_type").text(""),
              (document.getElementById("attachment_modal_file_caption").value =
                ""),
              na(),
              V.hide(),
              h.jumpToEnd();
        }
      });
    });
    $("#unsubscribe_option").click(function () {
      $("#unsubscribe_option").is(":checked") &&
        D.appendContents(
          "You can unsubscribe to future messages by replying UNSUBSCRIBE here."
        );
    });
    $("#unsubscribe_option").change(function () {
      X = !!$(this).is(":checked");
    });
    $("#is_custom_message").change(function () {
      $(this).is(":checked")
        ? ((Y = !0), (document.getElementById("token").style.display = ""))
        : ((Y = !1), (document.getElementById("token").style.display = "none"));
    });
    $("#token").change(function () {
      console.log($("#token").find(":selected"));
      void 0 === $("#token").find(":selected").attr("disabled") &&
        D.appendContents("{{" + $("#token").find(":selected").text() + "}}");
      text = D.getContents();
      $('#token option[value="default"]').prop("selected", !0);
      chrome.storage.local.set({ text: text }, function () {});
    });
    $("#addTemplate").click(function () {
      "" !== D.getText() &&
        chrome.storage.local.get(["templatesObj"], function (b) {
          ((b = b.templatesObj) && b instanceof Array) || (b = []);
          b.push([D.getContents(), D.getText()]);
          var e = document.createElement("option");
          e.innerText = D.getText().trim();
          e.classList.add("template-text");
          e.value = D.getContents();
          document.querySelector("#template-dropdown").appendChild(e);
          $("#template-dropdown").selectpicker("refresh");
          chrome.storage.local.set({ templatesObj: b }, function () {});
          iziToast.success({
            title: chrome.i18n.getMessage("templateModifyTitle"),
            message: chrome.i18n.getMessage("templateAddedMessage"),
            displayMode: 0,
            position: "topRight",
          });
        });
    });
    $("#template-dropdown").on("change", function () {
      console.log($("#template-dropdown").find(":selected").val());
      ca = !0;
      $("#template-dropdown").find(":selected").attr("disabled") ||
        (D.setContents($("#template-dropdown").find(":selected").val()),
        $("#deleteTemplate").css("display", ""));
      chrome.storage.local.set({ text: D.getContents() });
    });
    $("#supportFooter, #SupportTutorial").on("click", function () {
      chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
        chrome.tabs.sendMessage(b[0].id, {
          context: { contactSupport: !0, supportNumber: S },
        });
      });
    });
    $("#deleteTemplate").on("click", function () {
      var b = $("#template-dropdown").find(":selected");
      console.log("delete template", b.val());
      b.attr("disabled") ||
        (b.remove(),
        $("#template-dropdown").selectpicker("refresh"),
        $("#template-dropdown").selectpicker("val", "default"),
        $("#deleteTemplate").css("display", "none"),
        chrome.storage.local.get(["templatesObj"], function (e) {
          e = e.templatesObj;
          console.log(e);
          if (e) {
            var f = [];
            e.forEach(function (h) {
              return f.push(h[0]);
            });
            var g = f.indexOf(b.val());
            -1 !== g &&
              (e.splice(g, 1),
              chrome.storage.local.set({ templatesObj: e }, function () {}),
              iziToast.success({
                title: chrome.i18n.getMessage("templateModifyTitle"),
                message: chrome.i18n.getMessage("templateRemoveMessage"),
                displayMode: 0,
                position: "topRight",
              }));
          }
        }));
    });
    xa.addEventListener("click", function () {
      var b, e, f, g, h, p, n, q, v, I, y, F, z, A;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (r) {
        switch (r.nextAddress) {
          case 1:
            return (
              (b = !0),
              (f = e = !1),
              (g = 50),
              (h = 100),
              r.yield(C("ALLOWED_UPPER_LIMIT"), 2)
            );
          case 2:
            return void 0 == r.yieldResult.ALLOWED_UPPER_LIMIT
              ? r.yield(x({ ALLOWED_UPPER_LIMIT: !1 }), 4)
              : r.yield(C("ALLOWED_UPPER_LIMIT"), 5);
          case 5:
            f = r.yieldResult.ALLOWED_UPPER_LIMIT;
            r.jumpTo(4);
            break;
          case 4:
            return r.yield(C("ALLOWED_LOWER_LIMIT"), 7);
          case 7:
            return void 0 == r.yieldResult.ALLOWED_LOWER_LIMIT
              ? r.yield(x({ ALLOWED_LOWER_LIMIT: !1 }), 9)
              : r.yield(C("ALLOWED_LOWER_LIMIT"), 10);
          case 10:
            e = r.yieldResult.ALLOWED_LOWER_LIMIT;
            r.jumpTo(9);
            break;
          case 9:
            return r.yield(C("mainUser"), 12);
          case 12:
            return (
              (p = r.yieldResult.mainUser.messagesSent),
              r.yield(C("attachment_data"), 13)
            );
          case 13:
            n = r.yieldResult;
            n.attachment_data
              ? (n = n.attachment_data)
              : ((n = []), x({ attachment_data: n }));
            if ("" === D.getText().trim() && (1 > n.length || !U)) {
              iziToast.error({
                title: "Error",
                message: "Text Message can not be empty or add Some Attachment",
                displayMode: 0,
                position: "topRight",
              });
              r.jumpTo(0);
              break;
            }
            v = w(D.getContents().toString());
            I = document.getElementById("addTimeStamp_option").checked;
            if (J.length) {
              y = $("#options").find(":selected").val();
              W = [];
              for (F = 1; F < J.length; F++)
                (z = J[F][y]),
                  null == z || void 0 == z ? W.push("") : W.push(z);
              q = {
                command: "start messaging background",
                is_image: U && 0 < n.length,
                arr: W,
                message: v,
                premium: is_premium,
                timeDelay: timeDelay,
                is_time_stamp: I,
                fs: X,
                googleSheet: !1,
                is_custom_message: Y,
                execl_coloumn: J,
                totalMessages: total_messages,
              };
            } else (A = $("#number").val().split(",")), (q = { command: "start messaging background", is_image: U && 0 < n.length, arr: A, totalMessages: total_messages, timeDelay: timeDelay, is_time_stamp: I, googleSheet: !1, message: v, premium: is_premium, is_unsubscribe: X });
            if (!is_premium && q.arr.length > K)
              return (
                (b = !1),
                r.yield(
                  new Promise(function (u) {
                    return $jscomp.asyncExecutePromiseGeneratorProgram(
                      function (N) {
                        0 < K
                          ? t(
                              chrome.i18n.getMessage("iziToastErrMsgLeftMsg", [
                                K,
                              ]),
                              "center",
                              u
                            )
                          : t(
                              chrome.i18n.getMessage(
                                "iziToastErrMsgFinishedMsg"
                              ),
                              "center",
                              u
                            );
                        N.jumpToEnd();
                      }
                    );
                  }),
                  16
                )
              );
            if ((p >= g) & (p <= h) & !e)
              return r.yield(
                new Promise(function (u) {
                  return $jscomp.asyncExecutePromiseGeneratorProgram(function (
                    N
                  ) {
                    iziToast.question({
                      timeout: 2e4,
                      close: !1,
                      overlay: !0,
                      displayMode: "once",
                      id: "question",
                      zindex: 999,
                      title: chrome.i18n.getMessage("iziToastMsgLimitWarning"),
                      message: chrome.i18n.getMessage(
                        "iziToastMsgLimitWarningMsg",
                        ["50"]
                      ),
                      position: "center",
                      buttons: [
                        [
                          "<button><is_attachment>Yes, Send Now</is_attachment></button>",
                          function (B, E) {
                            u();
                            b = !0;
                            B.hide({ transitionOut: "fadeOut" }, E, "button");
                            x({ ALLOWED_LOWER_LIMIT: !0 });
                          },
                          !0,
                        ],
                        [
                          "<button>No, Don't Send</button>",
                          function (B, E) {
                            u();
                            b = !1;
                            B.hide({ transitionOut: "fadeOut" }, E, "button");
                          },
                        ],
                      ],
                      onClosing: function (B, E, qa) {},
                      onClosed: function (B, E, qa) {},
                    });
                    N.jumpToEnd();
                  });
                }),
                16
              );
            if (!((p >= h) & !f)) {
              r.jumpTo(16);
              break;
            }
            return r.yield(
              new Promise(function (u) {
                return $jscomp.asyncExecutePromiseGeneratorProgram(function (
                  N
                ) {
                  iziToast.question({
                    timeout: 2e4,
                    close: !1,
                    overlay: !0,
                    displayMode: "once",
                    id: "question",
                    zindex: 999,
                    title: chrome.i18n.getMessage("iziToastMsgLimitWarning"),
                    message: chrome.i18n.getMessage(
                      "iziToastMsgLimitWarningMsg",
                      ["100"]
                    ),
                    position: "center",
                    buttons: [
                      [
                        "<button><is_attachment>Yes, Send Now</is_attachment></button>",
                        function (B, E) {
                          b = !0;
                          x({ ALLOWED_UPPER_LIMIT: !0 });
                          u();
                          B.hide({ transitionOut: "fadeOut" }, E, "button");
                        },
                        !0,
                      ],
                      [
                        "<button>No, Don't Send</button>",
                        function (B, E) {
                          b = !1;
                          u();
                          B.hide({ transitionOut: "fadeOut" }, E, "button");
                        },
                      ],
                    ],
                    onClosing: function (B, E, qa) {},
                    onClosed: function (B, E, qa) {},
                  });
                  N.jumpToEnd();
                });
              }),
              16
            );
          case 16:
            b &&
              ((H = "SEND"),
              chrome.storage.local.set({ currentState: H }, function () {
                $("#send").css("display", "none");
                $("#stop").css("display", "");
                $("#pause").css("display", "");
                $("#continue").css("display", "none");
                $("#export_results").css("display", "none");
              }),
              chrome.runtime.sendMessage({ context: q })),
              r.jumpToEnd();
        }
      });
    });
    $("#stop").on("click", function () {
      H = "STOP";
      chrome.storage.local.set({ currentState: H }, function () {
        $("#send").css("display", "");
        $("#continue").css("display", "none");
        $("#stop").css("display", "none");
        $("#pause").css("display", "none");
        $("#export_results").css("display", "");
      });
      context = { process_state: "STOP" };
      chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
        chrome.tabs.sendMessage(b[0].id, { context: context }, function () {});
      });
    });
    $("#export_results").click(function () {
      context = { export_results: "true" };
      chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
        chrome.tabs.sendMessage(b[0].id, { context: context }, function () {});
      });
    });
    chrome.runtime.onMessage.addListener(function (b) {
      var e, f, g, h, p;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (n) {
        if (1 == n.nextAddress) {
          if ("content" !== b.from || !b.count)
            return (
              "messageCount" === b.subject &&
                ((G.messagesSent += b.messagesSent), (K -= b.messagesSent)),
              n.jumpTo(0)
            );
          if (b.count !== b.total)
            return (
              "PAUSE" != H &&
                ((H = "SEND"),
                chrome.storage.local.set({ currentState: H }, function () {
                  $("#send").css("display", "none");
                  $("#continue").css("display", "none");
                  $("#stop").css("display", "");
                  $("#pause").css("display", "");
                  $("#export_results").css("display", "none");
                })),
              "progress-bar-filter" == b.subject
                ? ((document.getElementById("sorted-number-filter").innerHTML =
                    b.count + "/" + b.total),
                  (e = (115 * b.count) / b.total),
                  (document.getElementById(
                    "progress-indicator-filter"
                  ).style.width = e.toString() + "px"),
                  (document.getElementById(
                    "progress-container-filter"
                  ).style.display = "block"))
                : "progress-bar-sent" == b.subject &&
                  (is_premium
                    ? (document.getElementById("messageCount").innerHTML =
                        "<strong>" + (G.messagesSent + b.sent) + "</strong>")
                    : (document.getElementById("messageCount").innerHTML =
                        "<strong>" + (K - b.sent) + "</strong>"),
                  (document.getElementById("sorted-number-sent").innerHTML =
                    b.count + "/" + b.total),
                  (f = (115 * b.count) / b.total),
                  (document.getElementById(
                    "progress-indicator-sent"
                  ).style.width = f.toString() + "px"),
                  (document.getElementById(
                    "progress-container-sent"
                  ).style.display = "block")),
              n.jumpTo(0)
            );
          "PAUSE" != H &&
            ((H = "STOP"),
            chrome.storage.local.set({ currentState: H }, function () {
              $("#send").css("display", "");
              $("#continue").css("display", "none");
              $("#stop").css("display", "none");
              $("#pause").css("display", "none");
              $("#export_results").css("display", "");
            }));
          document.getElementById("progress-container-filter").style.display =
            "none";
          document.getElementById("progress-container-sent").style.display =
            "none";
          "progress-bar-sent" == b.subject &&
            (is_premium
              ? (document.getElementById("messageCount").innerHTML =
                  "<strong>" + (G.messagesSent + b.sent) + "</strong>")
              : (document.getElementById("messageCount").innerHTML =
                  "<strong>" + (K - b.sent) + "</strong>"));
          return n.yield(C("reviewAskLastDate"), 4);
        }
        if (5 != n.nextAddress)
          return (
            (g = n.yieldResult.reviewAskLastDate), n.yield(C("reviewUs"), 5)
          );
        h = n.yieldResult.reviewUs;
        void 0 == h ||
          h ||
          (void 0 != g
            ? ((g = new Date(g)),
              (p = new Date() - g),
              (p /= 864e5),
              1 < p && $("#reviewFooter").click())
            : 10 < G.messagesSent + b.sent && $("#reviewFooter").click());
        n.jumpToEnd();
      });
    });
    $("#timer-checkbox").change(function () {
      $("#timer-checkbox").is(":checked")
        ? ($("#timer-gap-inputs").css("display", "block"),
          (document.querySelector("#randomize").style.display = "block"))
        : ($("#timer_gap_random").prop("checked", !1),
          $("#timer-gap-inputs").css("display", "none"),
          document.querySelector("#time-delay").removeAttribute("disabled"),
          $("#time-delay").attr("placeholder", 3),
          $("#time-delay").val(""),
          (timeDelay = 1),
          chrome.storage.local.set({ timer_gap_random: !1 }));
    });
    $("#time-delay").on("input", function (b) {
      timeDelay = b.target.value || 20;
    });
    $("#randomize input").change(function () {
      $("#randomize input").is(":checked")
        ? ((timeDelay = "random"),
          document
            .querySelector("#time-delay")
            .setAttribute("disabled", "true"))
        : (document.querySelector("#time-delay").removeAttribute("disabled"),
          (timeDelay = document.querySelector("#time-delay").value || 1));
    });
    $("#pause").on("click", function () {
      H = "PAUSE";
      chrome.storage.local.set({ currentState: H }, function () {
        context = { process_state: "PAUSE" };
        chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
          chrome.tabs.sendMessage(
            b[0].id,
            { context: context },
            function () {}
          );
        });
        $("#send").css("display", "none");
        $("#continue").css("display", "");
        $("#stop").css("display", "");
        $("#pause").css("display", "none");
        $("#export_results").css("display", "none");
      });
    });
    $("#continue").on("click", function () {
      H = "SEND";
      chrome.storage.local.set({ currentState: H }, function () {
        context = { process_state: "CONTINUE" };
        chrome.tabs.query({ active: !0, currentWindow: !0 }, function (b) {
          chrome.tabs.sendMessage(
            b[0].id,
            { context: context },
            function () {}
          );
        });
        $("#send").css("display", "none");
        $("#continue").css("display", "none");
        $("#stop").css("display", "");
        $("#pause").css("display", "");
        $("#export_results").css("display", "none");
      });
    });
    $(
      "#form-checks input, #unsub_div input, #addTimeStamp input,#custom_div input, #timer-checkbox-div, #timer_gap_random, #time-delay, #send_attachments, #uncheck_attachment"
    ).change(function () {
      var b = document.querySelector("#send_attachments").checked;
      unsubscribe = document.querySelector("#unsubscribe_option").checked;
      addTimeStamp = document.querySelector("#addTimeStamp_option").checked;
      customMessage = document.querySelector("#is_custom_message").checked;
      text = D.getContents();
      timer_gap = document.querySelector("#timer-checkbox").checked;
      timer_gap_random = document.querySelector("#timer_gap_random").checked;
      timeDelay = timer_gap
        ? timer_gap_random
          ? "random"
          : document.querySelector("#time-delay").value || 1
        : 1;
      $("#sheet_number").val();
      chrome.storage.local.set({
        attachment: b,
        unsubscribe: unsubscribe,
        addTimeStamp: addTimeStamp,
        customMessage: customMessage,
        text: text,
        timer_gap: timer_gap,
        timeDelay: timeDelay,
        timer_gap_random: timer_gap_random,
      });
    });
    M = document.getElementById("blurToggleAll");
    da = document.getElementById("blurAllMessageToggle");
    ea = document.getElementById("blurLastMesssageToggle");
    fa = document.getElementById("blurMediaPreviewToggle");
    ha = document.getElementById("blurMediaGallaryToggle");
    ia = document.getElementById("blurTextInputToggle");
    ja = document.getElementById("blurProfilePictureToggle");
    ka = document.getElementById("blurGroupUserNameToggle");
    la = document.getElementById("noTransitionDelayToggle");
    ma = document.getElementById("unblurAllToggle");
    M.addEventListener("change", function () {
      chrome.storage.local.set({
        blurToggleAll: this.checked,
        blurAllMessageToggle: this.checked,
        blurLastMesssageToggle: this.checked,
        blurMediaPreviewToggle: this.checked,
        blurMediaGallaryToggle: this.checked,
        blurTextInputToggle: this.checked,
        blurProfilePictureToggle: this.checked,
        blurGroupUserNameToggle: this.checked,
        noTransitionDelayToggle: this.checked,
        unblurAllToggle: this.checked,
      });
      da.checked =
        ea.checked =
        fa.checked =
        ha.checked =
        ia.checked =
        ja.checked =
        ka.checked =
        la.checked =
        ma.checked =
          this.checked;
      m();
    });
    da.addEventListener("change", function () {
      chrome.storage.local.set({ blurAllMessageToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    ea.addEventListener("change", function () {
      chrome.storage.local.set({ blurLastMesssageToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    fa.addEventListener("change", function () {
      chrome.storage.local.set({ blurMediaPreviewToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    ha.addEventListener("change", function () {
      chrome.storage.local.set({ blurMediaGallaryToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    ia.addEventListener("change", function () {
      chrome.storage.local.set({ blurTextInputToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    ja.addEventListener("change", function () {
      chrome.storage.local.set({ blurProfilePictureToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    ka.addEventListener("change", function () {
      chrome.storage.local.set({ blurGroupUserNameToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    la.addEventListener("change", function () {
      chrome.storage.local.set({ noTransitionDelayToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    ma.addEventListener("change", function () {
      chrome.storage.local.set({ unblurAllToggle: this.checked });
      this.checked ||
        (chrome.storage.local.set({ blurToggleAll: this.checked }),
        (M.checked = this.checked));
      m();
    });
    document.getElementById("enableLikeToggle");
    document.getElementById("enableMessageReactionToggle");
    document.getElementById("chatWithNumberToggle");
    document.getElementById("showChatFolderToggle");
    document.getElementById("showQuickReplyToggle");
    window.onload = function () {
      chrome.storage.local.get(
        "numbersList text send_status attachment attachment_data image doc contact unsubscribe addTimeStamp customMessage templatesObj to_coloumn from_coloumn contacts timer_gap timer_gap_random timeDelay sheet_number currentState blurToggleAll blurAllMessageToggle blurLastMesssageToggle blurMediaPreviewToggle blurMediaGallaryToggle blurTextInputToggle blurProfilePictureToggle blurGroupUserNameToggle noTransitionDelayToggle unblurAllToggle".split(
          " "
        ),
        function (b) {
          var e, f, g, h, p, n, q, v, I, y, F, z, A, r, u;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (N) {
            if (b.currentState)
              switch (
                ((e = $("#send")),
                (f = $("#pause")),
                (g = $("#continue")),
                (h = $("#stop")),
                (p = $("#export_results")),
                b.currentState)
              ) {
                case "PAUSE":
                  g.css("display", ""),
                    h.css("display", ""),
                    f.css("display", "none"),
                    e.css("display", "none"),
                    p.css("display", "none");
              }
            document.getElementById("number").value = b.numbersList || "";
            b.numbersList &&
              ($("#sheet_number").attr("disabled", !0),
              $("#input").attr("disabled", !0),
              $("#input")
                .parent()
                .closest("label")
                .removeClass("bg-green-700 hover:bg-green-900"),
              $("#input").parent().closest("label").addClass("bg-gray-700"),
              $("#input")
                .parent()
                .closest("label")
                .attr(
                  "title",
                  chrome.i18n.getMessage("uploadExcelDisabledLabel")
                ),
              $("#downloadExcelTemplate").attr("disabled", !0),
              $("#verifyGoogleSheet").attr("disabled", !0),
              $("#verifyGoogleSheet").css("background-color", "grey"),
              (n = b.numbersList.replace(/[^\d,]/g, "")),
              (n = n.split(",")),
              (n = n.filter(function (B) {
                return B;
              })),
              $("#contacts-found").text(
                chrome.i18n.getMessage("contactFoundText", [n.length])
              ),
              $("#contacts-found").css("display", "flex"),
              $("#send").attr("disabled", !1));
            $("#personalizedVariable").text(
              chrome.i18n.getMessage("uploadExcelBtn")
            );
            null == (q = D) || q.setContents(b.text || "");
            b.attachment &&
              (document
                .querySelector("#send_attachments")
                .setAttribute("checked", ""),
              $("#send_attachments_label").addClass("switch-button-checked"));
            b.unsubscribe &&
              document
                .querySelector("#unsubscribe_option")
                .setAttribute("checked", b.unsubscribe);
            b.addTimeStamp
              ? document
                  .querySelector("#addTimeStamp_option")
                  .setAttribute("checked", b.addTimeStamp)
              : (void 0 == b.addTimeStamp || null == b.addTimeStamp) &&
                document
                  .querySelector("#addTimeStamp_option")
                  .setAttribute("checked", !0);
            b.customMessage &&
              document
                .querySelector("#is_custom_message")
                .setAttribute("checked", b.customMessage);
            b.attachment &&
              ((U = !0),
              (document.querySelector("#steps_for_attachments").style.display =
                "flex"),
              $("#add_attachment_button").removeClass("hidden"));
            b.attachment_data && na();
            b.timer_gap &&
              (document
                .querySelector("#timer-checkbox")
                .setAttribute("checked", b.timer_gap),
              (document.querySelector("#timer-gap-inputs").style.display =
                "block"),
              (document.querySelector("#randomize").style.display = "block"),
              b.timer_gap_random
                ? (document
                    .querySelector("#timer_gap_random")
                    .setAttribute("checked", b.timer_gap_random),
                  document
                    .querySelector("#time-delay")
                    .setAttribute("disabled", "true"),
                  (timeDelay = "random"))
                : b.timeDelay
                ? (document
                    .querySelector("#time-delay")
                    .removeAttribute("disabled"),
                  document
                    .querySelector("#time-delay")
                    .setAttribute("value", b.timeDelay),
                  (timeDelay = b.timeDelay))
                : (timeDelay = 1));
            b.templatesObj &&
              b.templatesObj &&
              b.templatesObj[0] &&
              2 != b.templatesObj[0].length &&
              ((b.templatesObj = []),
              chrome.storage.local.set({ templatesObj: [] }));
            b.templatesObj.forEach(function (B) {
              var E = document.createElement("option");
              E.innerText = B[1].trim();
              E.classList.add("template-text");
              E.value = B[0];
              document.querySelector("#template-dropdown").appendChild(E);
              $("#template-dropdown").selectpicker("refresh");
            });
            b.customMessage &&
              ((Y = !0),
              (document.getElementById("token").style.display =
                "inline-block"));
            if (b.contacts && 0 < b.contacts.length) {
              $("#number").tokenfield({
                inputType: "tel",
                createTokensOnBlur: !0,
              });
              $("#number-tokenfield").attr(
                "placeholder",
                chrome.i18n.getMessage("numberPlaceholderDisabled")
              );
              $("#number").tokenfield("disable");
              $("#sheet_number").attr("disabled", !0);
              $("#verifyGoogleSheet").attr("disabled", !0);
              $("#verifyGoogleSheet").removeClass("bg-green-700");
              $("#verifyGoogleSheet").addClass("bg-gray-700");
              $("#personalizedVariable").text("Select Variable");
              $("#contacts-found").text(
                chrome.i18n.getMessage("contactFoundText", [
                  b.contacts.length - 1,
                ])
              );
              $("#contacts-found").css("display", "flex");
              $("#send").attr("disabled", !1);
              document.getElementById(
                "execlSheetBtn"
              ).parentElement.style.display = "none";
              $("#downloadExcelTemplate").css("display", "none");
              J = b.contacts;
              v = $jscomp.makeIterator(Object.entries(b.contacts[0]));
              for (I = v.next(); !I.done; I = v.next())
                (y = I.value),
                  (F = $jscomp.makeIterator(y)),
                  (z = F.next().value),
                  (A = F.next().value),
                  (r = document.createElement("option")),
                  r.setAttribute("value", z),
                  (r.innerText = A),
                  document.getElementById("options").appendChild(r),
                  (u = r.cloneNode(!0)),
                  document.querySelector("#token").appendChild(u);
              chrome.storage.local.get("numberColumn", function (B) {
                $("#options").val(B.numberColumn);
              });
              $("#options_div").css("display", "block");
              $("#deleteExecl").css("display", "block");
              $("#filter_numbers").css("display", "flex");
            } else "" == document.getElementById("number").value && $("#contacts-found").text(chrome.i18n.getMessage("contactFoundText", [0]));
            (b.contacts && 0 != b.contacts.length) ||
              b.numbersList ||
              $("#send").attr("disabled", !0);
            M.checked = b.blurToggleAll;
            da.checked = b.blurAllMessageToggle;
            ea.checked = b.blurLastMesssageToggle;
            fa.checked = b.blurMediaPreviewToggle;
            ha.checked = b.blurMediaGallaryToggle;
            ia.checked = b.blurTextInputToggle;
            ja.checked = b.blurProfilePictureToggle;
            ka.checked = b.blurGroupUserNameToggle;
            la.checked = b.noTransitionDelayToggle;
            ma.checked = b.unblurAllToggle;
            N.jumpToEnd();
          });
        }
      );
    };
    $("#addMember").on("click", function (b) {
      $("#addingMember").is(":visible")
        ? $("#addingMember").hide()
        : $("#addingMember").show();
    });
    $("#addNewMember").on("click", function (b) {
      var e, f, g, h, p, n, q, v, I, y, F, z;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (A) {
        if (1 == A.nextAddress) return A.yield(C("mainUser"), 2);
        if (3 != A.nextAddress)
          return (
            (e = A.yieldResult),
            (f = e.mainUser),
            (g = f.planhistory),
            (h = g[g.length - 1].usageQuantityAllowed[0]),
            (p = f.collaborators),
            p.length >= h
              ? (iziToast.error({
                  title: chrome.i18n.getMessage("iziToastExcelSizeError"),
                  message: chrome.i18n.getMessage(
                    "iziToastErrMsgQuotaExceedMsg"
                  ),
                  displayMode: 0,
                  position: "topRight",
                }),
                A["return"]())
              : (n = p.some(function (r) {
                  return r.phoneNumber === $("#memberPhone").val();
                }))
              ? (iziToast.warning({
                  title: chrome.i18n.getMessage(
                    "iziToastMemberAlreadyPresentWarning"
                  ),
                  message: chrome.i18n.getMessage(
                    "iziToastMemberAlreadyPresentWarningMsg"
                  ),
                  displayMode: 0,
                  position: "topRight",
                }),
                A["return"]())
              : $("#memberName").val() && $("#memberPhone").val()
              ? A.yield(
                  k("ADD", $("#memberPhone").val(), $("#memberName").val()),
                  3
                )
              : (iziToast.warning({
                  title: chrome.i18n.getMessage("iziToastAddNamePhoneWarning"),
                  message: chrome.i18n.getMessage(
                    "iziToastAddNamePhoneWarningMsg"
                  ),
                  displayMode: 0,
                  position: "topRight",
                }),
                A["return"]())
          );
        q = $(".teamMember").eq(0);
        v = q.clone();
        v.prop("id", $("#memberPhone").val()).removeClass("hidden");
        I = v.find(".memberName");
        I.text($("#memberName").val());
        y = v.find(".memberNumber");
        y.text($("#memberPhone").val());
        F = v.find(".removeMember");
        F.on("click", function () {
          var r, u, N;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (B) {
            $("#" + y.text()).remove();
            p = G.collaborators;
            r = p.map(function (E) {
              return E.phoneNumber;
            });
            u = r.indexOf(y.text());
            -1 < u &&
              (p.splice(u, 1), (G.collaborators = p), x({ mainUser: G }));
            N = p.length;
            $("#memberCount").html(
              chrome.i18n.getMessage("memberCount", [N, h])
            );
            k("REMOVE", y.text(), "");
            0 == N && $("#noteamMember").show();
            $("#addMember").removeAttr("disabled");
            B.jumpToEnd();
          });
        });
        z = {};
        z.name = $("#memberName").val();
        z.phoneNumber = $("#memberPhone").val();
        p.push(z);
        G.collaborators = p;
        x({ mainUser: f, user: G });
        $("#memberCount").html(
          chrome.i18n.getMessage("memberCount", [p.length, h])
        );
        p.length == h && $("#addMember").attr("disabled", "true");
        $("#memberTable").append(v);
        iziToast.success({
          title: chrome.i18n.getMessage("iziToastMemberAddedSuccess"),
          message: chrome.i18n.getMessage("iziToastMemberAddedSuccessMsg"),
          displayMode: 0,
          position: "topRight",
        });
        $("#addingMember").hide();
        $("#memberName").val("");
        $("#memberPhone").val("");
        $("#noteamMember").hide();
        A.jumpToEnd();
      });
    });
    sa = function () {
      iziToast.info({
        timeout: 2e4,
        close: !1,
        overlay: !0,
        animateInside: !0,
        iconUrl: "https://izitoast.marcelodolza.com/img/star.svg",
        displayMode: "once",
        id: "question",
        zindex: 999,
        title: chrome.i18n.getMessage("iziToastUpgradeInfo"),
        message: chrome.i18n.getMessage("iziToastUpgradeInfoMsg", S),
        position: "center",
        buttons: [
          [
            "<button>Not now</button>",
            function (b, e) {
              b.hide({ transitionOut: "fadeOut" }, e, "button");
            },
          ],
          [
            "<button>Upgrade Now</button>",
            function (b, e) {
              return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
                b.hide({ transitionOut: "fadeOut" }, e, "button");
                window.open("https://wamessager.com/pricing", "_blank");
                f.jumpToEnd();
              });
            },
            !0,
          ],
        ],
        onClosing: function (b, e, f) {},
        onClosed: function (b, e, f) {},
      });
    };
    x = function (b) {
      return new Promise(function (e, f) {
        return chrome.storage.local.set(b, function (g) {
          chrome.runtime.lastError
            ? f(Error(chrome.runtime.lastError.message))
            : e();
        });
      });
    };
    C = function (b) {
      return new Promise(function (e, f) {
        return chrome.storage.local.get(b, function (g) {
          chrome.runtime.lastError
            ? f(Error(chrome.runtime.lastError.message))
            : e(void 0 == g ? null : g);
        });
      });
    };
    $("#onboardingSend").click(function (b) {
      var e;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
        e = $("#onboardingNumber").val().split(",");
        context = {
          command: "start messaging background",
          is_image: !1,
          arr: e,
          totalMessages: total_messages,
          timeDelay: timeDelay,
          googleSheet: !1,
          message: document.getElementById("onboardingMessage").value,
          premium: is_premium,
          is_unsubscribe: X,
        };
        chrome.runtime.sendMessage({ context: context });
        $("#onboarding,#unsynced").hide();
        $("#loadingScreen").show();
        x({ onBoarding: !0 });
        ra();
        $("#Enhancement").click();
        f.jumpToEnd();
      });
    });
    $("#reviewFooter").click(function (b) {
      var e;
      return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
        console.log("review clicked");
        x({ reviewAskLastDate: Date.now() });
        e = chrome.i18n.getMessage("iziToastReviewMessage");
        is_premium ||
          (e += chrome.i18n.getMessage("iziToastReviewMessageOffer"));
        iziToast.question({
          timeout: 2e4,
          close: !1,
          color: "green",
          overlay: !0,
          animateInside: !0,
          iconUrl: "https://izitoast.marcelodolza.com/img/star.svg",
          displayMode: "once",
          id: "question",
          zindex: 999,
          title: chrome.i18n.getMessage("iziToastReviewTitle"),
          message: e,
          position: "center",
          buttons: [
            [
              "<button>Not now</button>",
              function (g, h) {
                g.hide({ transitionOut: "fadeOut" }, h, "button");
              },
            ],
            [
              "<button>Rate Us 5 Stars</button>",
              function (g, h) {
                return $jscomp.asyncExecutePromiseGeneratorProgram(function (
                  p
                ) {
                  g.hide({ transitionOut: "fadeOut" }, h, "button");
                  window.open(
                    "https://chrome.google.com/webstore/detail/best-wa-sender-free-softw/afgbckekjlfkfhklldgdndiagddhbohm/reviews",
                    "_blank"
                  );
                  x({ reviewUs: !0 });
                  p.jumpToEnd();
                });
              },
              !0,
            ],
          ],
          onClosing: function (g, h, p) {},
          onClosed: function (g, h, p) {},
        });
        f.jumpToEnd();
      });
    });
    l.jumpToEnd();
  });
});
