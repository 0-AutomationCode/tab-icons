/*
 jQuery v3.3.1 | (c) JS Foundation and other contributors | jquery.org/license */
var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.createTemplateTagFirstArg = function (a) {
  return (a.raw = a);
};
$jscomp.createTemplateTagFirstArgWithRaw = function (a, b) {
  a.raw = b;
  return a;
};
$jscomp.arrayIteratorImpl = function (a) {
  var b = 0;
  return function () {
    return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
  };
};
$jscomp.arrayIterator = function (a) {
  return { next: $jscomp.arrayIteratorImpl(a) };
};
$jscomp.makeIterator = function (a) {
  var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
  if (b) return b.call(a);
  if ("number" == typeof a.length) return $jscomp.arrayIterator(a);
  throw Error(String(a) + " is not an iterable or ArrayLike");
};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.SIMPLE_FROUND_POLYFILL = !1;
$jscomp.ISOLATE_POLYFILLS = !1;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
$jscomp.defineProperty =
  $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
    ? Object.defineProperty
    : function (a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a;
      };
$jscomp.getGlobal = function (a) {
  a = [
    "object" == typeof globalThis && globalThis,
    a,
    "object" == typeof window && window,
    "object" == typeof self && self,
    "object" == typeof global && global,
  ];
  for (var b = 0; b < a.length; ++b) {
    var c = a[b];
    if (c && c.Math == Math) return c;
  }
  throw Error("Cannot find global object");
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.IS_SYMBOL_NATIVE =
  "function" === typeof Symbol && "symbol" === typeof Symbol("x");
$jscomp.TRUST_ES6_POLYFILLS =
  !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
$jscomp.polyfills = {};
$jscomp.propertyToPolyfillSymbol = {};
$jscomp.POLYFILL_PREFIX = "$jscp$";
var $jscomp$lookupPolyfilledValue = function (a, b, c) {
  if (!c || null != a) {
    c = $jscomp.propertyToPolyfillSymbol[b];
    if (null == c) return a[b];
    c = a[c];
    return void 0 !== c ? c : a[b];
  }
};
$jscomp.polyfill = function (a, b, c, d) {
  b &&
    ($jscomp.ISOLATE_POLYFILLS
      ? $jscomp.polyfillIsolated(a, b, c, d)
      : $jscomp.polyfillUnisolated(a, b, c, d));
};
$jscomp.polyfillUnisolated = function (a, b, c, d) {
  c = $jscomp.global;
  a = a.split(".");
  for (d = 0; d < a.length - 1; d++) {
    var e = a[d];
    if (!(e in c)) return;
    c = c[e];
  }
  a = a[a.length - 1];
  d = c[a];
  b = b(d);
  b != d &&
    null != b &&
    $jscomp.defineProperty(c, a, { configurable: !0, writable: !0, value: b });
};
$jscomp.polyfillIsolated = function (a, b, c, d) {
  var e = a.split(".");
  a = 1 === e.length;
  d = e[0];
  d = !a && d in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
  for (var k = 0; k < e.length - 1; k++) {
    var g = e[k];
    if (!(g in d)) return;
    d = d[g];
  }
  e = e[e.length - 1];
  c = $jscomp.IS_SYMBOL_NATIVE && "es6" === c ? d[e] : null;
  b = b(c);
  null != b &&
    (a
      ? $jscomp.defineProperty($jscomp.polyfills, e, {
          configurable: !0,
          writable: !0,
          value: b,
        })
      : b !== c &&
        (void 0 === $jscomp.propertyToPolyfillSymbol[e] &&
          ((c = (1e9 * Math.random()) >>> 0),
          ($jscomp.propertyToPolyfillSymbol[e] = $jscomp.IS_SYMBOL_NATIVE
            ? $jscomp.global.Symbol(e)
            : $jscomp.POLYFILL_PREFIX + c + "$" + e)),
        $jscomp.defineProperty(d, $jscomp.propertyToPolyfillSymbol[e], {
          configurable: !0,
          writable: !0,
          value: b,
        })));
};
$jscomp.underscoreProtoCanBeSet = function () {
  var a = { a: !0 },
    b = {};
  try {
    return (b.__proto__ = a), b.a;
  } catch (c) {}
  return !1;
};
$jscomp.setPrototypeOf =
  $jscomp.TRUST_ES6_POLYFILLS && "function" == typeof Object.setPrototypeOf
    ? Object.setPrototypeOf
    : $jscomp.underscoreProtoCanBeSet()
    ? function (a, b) {
        a.__proto__ = b;
        if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
        return a;
      }
    : null;
$jscomp.generator = {};
$jscomp.generator.ensureIteratorResultIsObject_ = function (a) {
  if (!(a instanceof Object))
    throw new TypeError("Iterator result " + a + " is not an object");
};
$jscomp.generator.Context = function () {
  this.isRunning_ = !1;
  this.yieldAllIterator_ = null;
  this.yieldResult = void 0;
  this.nextAddress = 1;
  this.finallyAddress_ = this.catchAddress_ = 0;
  this.finallyContexts_ = this.abruptCompletion_ = null;
};
$jscomp.generator.Context.prototype.start_ = function () {
  if (this.isRunning_) throw new TypeError("Generator is already running");
  this.isRunning_ = !0;
};
$jscomp.generator.Context.prototype.stop_ = function () {
  this.isRunning_ = !1;
};
$jscomp.generator.Context.prototype.jumpToErrorHandler_ = function () {
  this.nextAddress = this.catchAddress_ || this.finallyAddress_;
};
$jscomp.generator.Context.prototype.next_ = function (a) {
  this.yieldResult = a;
};
$jscomp.generator.Context.prototype.throw_ = function (a) {
  this.abruptCompletion_ = { exception: a, isException: !0 };
  this.jumpToErrorHandler_();
};
$jscomp.generator.Context.prototype["return"] = function (a) {
  this.abruptCompletion_ = { return: a };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks = function (a) {
  this.abruptCompletion_ = { jumpTo: a };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.yield = function (a, b) {
  this.nextAddress = b;
  return { value: a };
};
$jscomp.generator.Context.prototype.yieldAll = function (a, b) {
  var c = $jscomp.makeIterator(a),
    d = c.next();
  $jscomp.generator.ensureIteratorResultIsObject_(d);
  if (d.done) (this.yieldResult = d.value), (this.nextAddress = b);
  else return (this.yieldAllIterator_ = c), this.yield(d.value, b);
};
$jscomp.generator.Context.prototype.jumpTo = function (a) {
  this.nextAddress = a;
};
$jscomp.generator.Context.prototype.jumpToEnd = function () {
  this.nextAddress = 0;
};
$jscomp.generator.Context.prototype.setCatchFinallyBlocks = function (a, b) {
  this.catchAddress_ = a;
  void 0 != b && (this.finallyAddress_ = b);
};
$jscomp.generator.Context.prototype.setFinallyBlock = function (a) {
  this.catchAddress_ = 0;
  this.finallyAddress_ = a || 0;
};
$jscomp.generator.Context.prototype.leaveTryBlock = function (a, b) {
  this.nextAddress = a;
  this.catchAddress_ = b || 0;
};
$jscomp.generator.Context.prototype.enterCatchBlock = function (a) {
  this.catchAddress_ = a || 0;
  a = this.abruptCompletion_.exception;
  this.abruptCompletion_ = null;
  return a;
};
$jscomp.generator.Context.prototype.enterFinallyBlock = function (a, b, c) {
  c
    ? (this.finallyContexts_[c] = this.abruptCompletion_)
    : (this.finallyContexts_ = [this.abruptCompletion_]);
  this.catchAddress_ = a || 0;
  this.finallyAddress_ = b || 0;
};
$jscomp.generator.Context.prototype.leaveFinallyBlock = function (a, b) {
  var c = this.finallyContexts_.splice(b || 0)[0];
  if ((c = this.abruptCompletion_ = this.abruptCompletion_ || c)) {
    if (c.isException) return this.jumpToErrorHandler_();
    void 0 != c.jumpTo && this.finallyAddress_ < c.jumpTo
      ? ((this.nextAddress = c.jumpTo), (this.abruptCompletion_ = null))
      : (this.nextAddress = this.finallyAddress_);
  } else this.nextAddress = a;
};
$jscomp.generator.Context.prototype.forIn = function (a) {
  return new $jscomp.generator.Context.PropertyIterator(a);
};
$jscomp.generator.Context.PropertyIterator = function (a) {
  this.object_ = a;
  this.properties_ = [];
  for (var b in a) this.properties_.push(b);
  this.properties_.reverse();
};
$jscomp.generator.Context.PropertyIterator.prototype.getNext = function () {
  for (; 0 < this.properties_.length; ) {
    var a = this.properties_.pop();
    if (a in this.object_) return a;
  }
  return null;
};
$jscomp.generator.Engine_ = function (a) {
  this.context_ = new $jscomp.generator.Context();
  this.program_ = a;
};
$jscomp.generator.Engine_.prototype.next_ = function (a) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_.next,
      a,
      this.context_.next_
    );
  this.context_.next_(a);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.return_ = function (a) {
  this.context_.start_();
  var b = this.context_.yieldAllIterator_;
  if (b)
    return this.yieldAllStep_(
      "return" in b
        ? b["return"]
        : function (c) {
            return { value: c, done: !0 };
          },
      a,
      this.context_["return"]
    );
  this.context_["return"](a);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.throw_ = function (a) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_["throw"],
      a,
      this.context_.next_
    );
  this.context_.throw_(a);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.yieldAllStep_ = function (a, b, c) {
  try {
    var d = a.call(this.context_.yieldAllIterator_, b);
    $jscomp.generator.ensureIteratorResultIsObject_(d);
    if (!d.done) return this.context_.stop_(), d;
    var e = d.value;
  } catch (k) {
    return (
      (this.context_.yieldAllIterator_ = null),
      this.context_.throw_(k),
      this.nextStep_()
    );
  }
  this.context_.yieldAllIterator_ = null;
  c.call(this.context_, e);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.nextStep_ = function () {
  for (; this.context_.nextAddress; )
    try {
      var a = this.program_(this.context_);
      if (a) return this.context_.stop_(), { value: a.value, done: !1 };
    } catch (b) {
      (this.context_.yieldResult = void 0), this.context_.throw_(b);
    }
  this.context_.stop_();
  if (this.context_.abruptCompletion_) {
    a = this.context_.abruptCompletion_;
    this.context_.abruptCompletion_ = null;
    if (a.isException) throw a.exception;
    return { value: a["return"], done: !0 };
  }
  return { value: void 0, done: !0 };
};
$jscomp.generator.Generator_ = function (a) {
  this.next = function (b) {
    return a.next_(b);
  };
  this["throw"] = function (b) {
    return a.throw_(b);
  };
  this["return"] = function (b) {
    return a.return_(b);
  };
  this[Symbol.iterator] = function () {
    return this;
  };
};
$jscomp.generator.createGenerator = function (a, b) {
  var c = new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(b));
  $jscomp.setPrototypeOf &&
    a.prototype &&
    $jscomp.setPrototypeOf(c, a.prototype);
  return c;
};
$jscomp.asyncExecutePromiseGenerator = function (a) {
  function b(d) {
    return a.next(d);
  }
  function c(d) {
    return a["throw"](d);
  }
  return new Promise(function (d, e) {
    function k(g) {
      g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(k, e);
    }
    k(a.next());
  });
};
$jscomp.asyncExecutePromiseGeneratorFunction = function (a) {
  return $jscomp.asyncExecutePromiseGenerator(a());
};
$jscomp.asyncExecutePromiseGeneratorProgram = function (a) {
  return $jscomp.asyncExecutePromiseGenerator(
    new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(a))
  );
};
(function () {
  var a = document.createElement("script");
  a.setAttribute("type", "text/javascript");
  a.setAttribute("id", "inject");
  a.src = chrome.runtime.getURL("js/inject.js");
  a.onload = function () {
    this.parentNode.removeChild(this);
  };
  document.head.appendChild(a);
})();
var myNumber = null,
  url = "https://wamessager-backend.onrender.com";
window.onload = function () {
  try {
    if (window.localStorage.getItem("last-wid")) {
      var a = window.localStorage.getItem("last-wid");
      myNumber = a.split("@")[0].substring(1);
    } else
      (a = window.localStorage.getItem("last-wid-md")),
        (myNumber = a.split(":")[0].substring(1));
  } catch (b) {}
};
if (!document.getElementById("wamessager")) {
  var wam = document.createElement("a");
  wam.id = "wamessager";
  document.body.append(wam);
}
var stopSending = !1,
  pauseSending = !1,
  rows = [["Phone Number", "Result"]],
  replace_pattern = /{{(.*?)}}/g,
  coloumn_pattern = /[^{\{]+(?=}\})/g,
  stop = !1,
  total_count = 0,
  continueFunction = null;
function pauser() {
  return new Promise(function (a) {
    continueFunction = function () {
      pauseSending = !1;
      a("resolved");
      continueFunction = null;
    };
  });
}
chrome.runtime.onMessage.addListener(function (a, b, c) {
  receiver(a, b, c);
  return !0;
});
function receiver(a, b, c) {
  var d, e, k, g, l, h, n, b, p, v, y, r, w, t, f, z, x, A, q;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (m) {
    switch (m.nextAddress) {
      case 1:
        if (["pv", "cn", "doc"].includes(a.mediaType)) {
          sendMultimedia(a.mediaType);
          c();
          m.jumpTo(0);
          break;
        }
        if ("hello" == a.greeting) {
          c({ number: myNumber, date: new Date().toDateString() });
          m.jumpTo(0);
          break;
        }
        if ("continue" === a.context.process_state) {
          d = a.context.message;
          e = [];
          if (a.context.is_custom_message)
            if ((result = a.context.execl_coloumn)) {
              k = $jscomp.makeIterator(Object.entries(result[0]));
              for (g = k.next(); !g.done; g = k.next())
                (l = g.value),
                  (h = $jscomp.makeIterator(l)),
                  (n = h.next().value),
                  (b = h.next().value),
                  (p = "{{" + b + "}}"),
                  (v = "{{" + n + "}}"),
                  (d = y = d.replaceAll(p, v));
              r = d.match(coloumn_pattern);
              w = d.match(replace_pattern);
              for (t = 1; t < result.length; t++) {
                f = d;
                if (null != r && null != w)
                  for (u = 0; u < r.length; u++)
                    f = z = f.replace(w[u], result[t][r[u]] || "");
                e.push(f);
              }
            } else for (x = 0; x < a.context.numbers.length; x++) e.push(d);
          else
            for (
              a.context.numbers = a.context.numbers.filter(function (B) {
                return B;
              }),
                A = 0;
              A < a.context.numbers.length;
              A++
            )
              e.push(d);
          sendAny(
            a.context.numbers,
            e,
            a.context.is_image,
            a.context.timeDelay,
            a.context.totalMessages,
            a.context.is_time_stamp
          );
          c();
          m.jumpTo(0);
          break;
        }
        if ("true" === a.context.export_results) {
          export_results();
          c();
          m.jumpTo(0);
          break;
        }
        if ("true" === a.context.filter_numbers) {
          rows = [["Phone Number", "Result"]];
          filter_numbers(a.arr);
          c();
          m.jumpTo(0);
          break;
        }
        if (!a.context.process_state) {
          a.context.get_contacts
            ? (window.addEventListener("wam:get-contacts-ready", function C(D) {
                removeEventListener("wam:get-contacts-ready", C);
                c(D.detail);
              }),
              window.dispatchEvent(new CustomEvent("wam:get-contacts"), {}))
            : a.context.contactSupport
            ? ((q = document.getElementById("wamessager")),
              q ||
                ((q = document.createElement("a")),
                (q.id = "wamessager"),
                document.body.append(q)),
              q.setAttribute(
                "href",
                "https://api.whatsapp.com/send?phone=" +
                  a.context.supportNumber +
                  "&text=Hello%2C%20I%20need%20some%20help%20with%20WAMessager"
              ),
              q.click(),
              q.remove(),
              c())
            : a.context.download_group
            ? (downloadContacts(
                a.context.exportType,
                a.context.groupIds,
                a.context.isAllGroupSelected,
                a.context.listOption,
                a.context.groupList,
                a.context.chatList
              ),
              c())
            : a.context.installed
            ? c()
            : a.context.downloadExcelTemplate && (downloadExcelTemplate(), c());
          m.jumpTo(0);
          break;
        }
        switch (a.context.process_state) {
          case "PAUSE":
            return m.jumpTo(8);
          case "CONTINUE":
            continueFunction();
            break;
          case "STOP":
            (stopSending = !0), pauseSending && continueFunction();
        }
        m.jumpTo(9);
        break;
      case 8:
        return (pauseSending = !0), m.yield(pauser(), 10);
      case 10:
        m.jumpTo(9);
        break;
      case 9:
        c(), m.jumpToEnd();
    }
  });
}
function filter_numbers(a) {
  var b, c;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
    switch (d.nextAddress) {
      case 1:
        (tempNumbers = a),
          (a = a.map(function (e) {
            return e.toString().replace(/\D/g, "").replace(/^0+/, "");
          })),
          (b = 0);
      case 2:
        if (!(b < a.length)) {
          d.jumpTo(4);
          break;
        }
        if (!pauseSending) {
          d.jumpTo(5);
          break;
        }
        return d.yield(pauser(), 5);
      case 5:
        if (stopSending) {
          stopSending = !1;
          chrome.runtime.sendMessage({
            subject: "progress-bar-filter",
            from: "content",
            count: a.length,
            total: a.length,
          });
          d.jumpTo(4);
          break;
        }
        if ("" == a[b]) {
          rows.push([tempNumbers[b], "Invalid"]);
          d.jumpTo(7);
          break;
        }
        return d.yield(openChat(a[b]), 8);
      case 8:
        (c = d.yieldResult),
          rows.push([tempNumbers[b], c ? "Valid" : "Invalid"]);
      case 7:
        chrome.runtime.sendMessage({
          subject: "progress-bar-filter",
          from: "content",
          count: b + 1,
          total: a.length,
        });
        b++;
        d.jumpTo(2);
        break;
      case 4:
        export_results(), d.jumpToEnd();
    }
  });
}
function clickOnElements(a) {
  var b, c;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
    return 1 == d.nextAddress
      ? ((b = document.createEvent("MouseEvents")),
        b.initEvent("mouseover", !0, !0),
        (c = document.querySelector(a).dispatchEvent(b)),
        b.initEvent("mousedown", !0, !0),
        document.querySelector(a).dispatchEvent(b),
        b.initEvent("mouseup", !0, !0),
        document.querySelector(a).dispatchEvent(b),
        b.initEvent("click", !0, !0),
        document.querySelector(a).dispatchEvent(b),
        c
          ? d["return"](
              new Promise(function (e) {
                e();
              })
            )
          : d.yield(clickOnElements(a), 3))
      : d["return"](d.yieldResult);
  });
}
function clickMediaIcon(a) {
  var b;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
    b = null;
    "pv" === a
      ? (b = '[data-icon="attach-image"]')
      : "doc" === a
      ? (b = '[data-icon="attach-document"]')
      : "cn" === a && (b = '[data-icon="attach-contact"]');
    return b ? c.yield(clickOnElements(b), 0) : c.jumpTo(0);
  });
}
function sendMultimedia(a) {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
    switch (b.nextAddress) {
      case 1:
        return b.setCatchFinallyBlocks(2), b.yield(openChat(myNumber), 4);
      case 4:
        return (
          (hasOpenedSelf = b.yieldResult),
          b.yield(clickOnElements('[data-testid="clip"] svg'), 5)
        );
      case 5:
        return b.yield(clickMediaIcon(a), 6);
      case 6:
        b.leaveTryBlock(0);
        break;
      case 2:
        b.enterCatchBlock(), b.jumpToEnd();
    }
  });
}
function chunk(a, b) {
  if (0 >= b) throw "Invalid chunk size";
  for (var c = [], d = 0, e = a.length; d < e; d += b)
    c.push(a.slice(d, d + b));
  return c;
}
function sendAny(a, b, c, d, e, k) {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (g) {
    0 !== b.length && core_sending(a, b, c, d, e, k);
    g.jumpToEnd();
  });
}
function core_sending(a, b, c, d, e, k) {
  var g, l, h, n, p, v, y, r, w, t;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (f) {
    switch (f.nextAddress) {
      case 1:
        (g = 0), (l = {}), (h = 0);
      case 2:
        if (!(h < a.length)) {
          f.jumpTo(4);
          break;
        }
        a[h] = a[h].toString().replace(/\D/g, "").replace(/^0+/, "");
        if (!pauseSending) {
          f.jumpTo(5);
          break;
        }
        return f.yield(pauser(), 5);
      case 5:
        if (stopSending || h == a.length - 1)
          if (
            (setTimeout(function () {
              chrome.runtime.sendMessage({
                subject: "progress-bar-sent",
                from: "content",
                count: a.length,
                sent: g,
                total: a.length,
              });
            }, 2e3),
            stopSending)
          ) {
            stopSending = !1;
            f.jumpTo(4);
            break;
          }
        if ("" == a[h]) {
          f.jumpTo(3);
          break;
        }
        n = null;
        if (0 == h) {
          f.jumpTo(7);
          break;
        }
        n =
          "random" === d
            ? Math.floor(30 * Math.random())
            : parseInt(d) + Math.floor(5 * Math.random());
        return f.yield(sleep(1e3 * n), 7);
      case 7:
        if (0 == h || 0 != h % 10) {
          f.jumpTo(9);
          break;
        }
        return f.yield(sleep(1e4), 9);
      case 9:
        p = null;
        f.setCatchFinallyBlocks(11);
        if (!(4 < a[h].length)) {
          f.jumpTo(13);
          break;
        }
        return f.yield(openChat(a[h]), 14);
      case 14:
        p = f.yieldResult;
      case 13:
        f.leaveTryBlock(12);
        break;
      case 11:
        f.enterCatchBlock();
        f.jumpTo(3);
        break;
      case 12:
        v = isUnsubscribed();
        b[h] = b[h].trim();
        if (
          !p ||
          v ||
          "" == b[h] ||
          !document.querySelectorAll("[contenteditable='true']")[1]
        ) {
          f.jumpTo(15);
          break;
        }
        f.setCatchFinallyBlocks(16);
        k && (b[h] += "\n\nSent at: " + new Date().toISOString());
        return f.yield(sendText(b[h], a[h], 0), 18);
      case 18:
        rows.push([a[h], "Message sent"]);
        g++;
        f.leaveTryBlock(15);
        break;
      case 16:
        f.enterCatchBlock();
        rows.push([a[h], "Some Error Please Try This Number Again"]);
        f.jumpTo(3);
        break;
      case 15:
        if (!p) {
          rows.push([a[h], "Invalid number"]);
          f.jumpTo(3);
          break;
        }
        if (v) {
          rows.push([a[h], "User has unsubscribed"]);
          f.jumpTo(3);
          break;
        }
        if (!c) {
          f.jumpTo(19);
          break;
        }
        f.setCatchFinallyBlocks(20);
        y = l;
        return f.yield(chrome.storage.local.get("attachment_data"), 22);
      case 22:
        return (
          (y.attachment_data = f.yieldResult),
          (l.foundNumber = document
            .getElementsByClassName("CzM4m")[0]
            .getAttribute("data-id")
            .split("@")[0]
            .split("_")[1]),
          f.yield(
            new Promise(
              (function (z) {
                return function (x) {
                  window.addEventListener(
                    "wam:attachments-sent",
                    function m(q) {
                      removeEventListener("wam:attachments-sent", m);
                      x();
                    }
                  );
                  window.dispatchEvent(
                    new CustomEvent("wam::send-attachments", {
                      detail: {
                        attachments: z.attachment_data.attachment_data,
                        number: z.foundNumber,
                      },
                    })
                  );
                };
              })(l)
            ),
            23
          )
        );
      case 23:
        (r = rows[rows.length - 1]) && r[0] == a[h]
          ? (rows[rows.length - 1][1] = r[1] + " & Media Sent")
          : rows.push([a[h], "Media sent"]);
        f.leaveTryBlock(19);
        break;
      case 20:
        f.enterCatchBlock();
        f.jumpTo(3);
        break;
      case 19:
        chrome.runtime.sendMessage({
          subject: "progress-bar-sent",
          from: "content",
          count: h + 1,
          sent: g,
          total: a.length,
        });
      case 3:
        l = { attachment_data: l.attachment_data, foundNumber: l.foundNumber };
        h++;
        f.jumpTo(2);
        break;
      case 4:
        if (!(0 < g)) {
          f.jumpTo(0);
          break;
        }
        w = {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phoneNumber: myNumber, messagesSent: g }),
        };
        chrome.runtime.sendMessage({
          subject: "messageCount",
          from: "content",
          messagesSent: g,
        });
        fetch(url + "/api/user/updateUsedMessages", w)
          .then()
          ["catch"]();
        return f.yield(chrome.storage.local.get("DAILY_MSG_LEFT"), 25);
      case 25:
        (t = f.yieldResult.DAILY_MSG_LEFT),
          (t -= g),
          chrome.storage.local.set({ DAILY_MSG_LEFT: t }),
          f.jumpToEnd();
    }
  });
}
function sendMedia(a) {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
    if (1 == b.nextAddress) return b.yield(sleep(500), 2);
    a.click();
    b.jumpToEnd();
  });
}
function openChat(a) {
  var b;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
    switch (c.nextAddress) {
      case 1:
        return (b = !1), c.yield(openChatUrl(a), 2);
      case 2:
        return c.yield(sleep(1e3), 3);
      case 3:
        return c.yield(hasOpened(), 4);
      case 4:
        if ((b = c.yieldResult)) {
          c.jumpTo(5);
          break;
        }
        return c.yield(openChatUrl(a), 6);
      case 6:
        return c.yield(sleep(1e3), 7);
      case 7:
        return c.yield(hasOpened(), 8);
      case 8:
        b = c.yieldResult;
      case 5:
        return c["return"](b);
    }
  });
}
function openChatUrl(a) {
  var b;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
    if (1 == c.nextAddress)
      return (
        (b = document.getElementById("wamessager")),
        b ||
          ((b = document.createElement("a")),
          (b.id = "wamessager"),
          document.body.append(b)),
        b.setAttribute("href", "https://api.whatsapp.com/send?phone=" + a),
        c.yield(sleep(500), 2)
      );
    b.click();
    c.jumpToEnd();
  });
}
function hasOpened() {
  var a;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
    return 1 == b.nextAddress
      ? b.yield(waitTillWindow(), 2)
      : 3 != b.nextAddress
      ? ((a = document.querySelector('[data-animate-modal-popup="true"]')),
        b.yield(sleep(1e3), 3))
      : a
      ? (a.querySelector("button").click(), b["return"](!1))
      : b["return"](!0);
  });
}
function waitTillWindow() {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (a) {
    return 1 == a.nextAddress
      ? document.querySelector('[data-animate-modal-popup="true"]') &&
        document.querySelector('[data-testid="popup-title"]')
        ? a.yield(sleep(500), 3)
        : a.jumpTo(0)
      : a.yield(waitTillWindow(), 0);
  });
}
var numbers = [];
function download_group() {
  var a, b, c, d, e, k;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (g) {
    a = document.querySelector('div[title="Search\u2026"]').parentElement
      .parentElement.parentElement.parentElement.children[1].lastElementChild
      .textContent;
    b = document.querySelector('div[title="Search\u2026"]').parentElement
      .parentElement.parentElement.parentElement.children[1].firstElementChild
      .textContent;
    "online" === a ||
      "typing..." === a ||
      "check here for contact info" === a ||
      "" === a ||
      a.includes("last seen") ||
      ((c = [["Numbers"]]),
      a.split(",").forEach(function (l) {
        l = l.toString().replace(/\D/g, "");
        "" != l && ((arr = []), arr.push(l), c.push(arr));
      }),
      (d =
        "data:text/csv;charset=utf-8," +
        c
          .map(function (l) {
            return l.join(",");
          })
          .join("\n")),
      (e = encodeURI(d)),
      (k = document.createElement("a")),
      k.setAttribute("href", e),
      k.setAttribute("download", b + ".csv"),
      document.body.appendChild(k),
      k.click());
    g.jumpToEnd();
  });
}
function downloadExcelTemplate() {
  var a = [];
  data = {
    whatsappNumber: "+919999988888",
    name: "WAM",
    anyField: "Best WA Message Bulk Sender",
  };
  a.push(data);
  data = { whatsappNumber: "+8613119140503", name: "Name 1", anyField: "WAM" };
  a.push(data);
  data = { whatsappNumber: "+8613119140503", name: "Name 2", anyField: "WAM" };
  a.push(data);
  data = {
    whatsappNumber: "+8615829292527",
    name: "Name 3",
    anyField: "WAMessager",
  };
  a.push(data);
  var b = XLSX.utils.json_to_sheet(a);
  a = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(a, b, "excel template");
  XLSX.utils.sheet_add_aoa(
    b,
    [
      [
        "WhatsApp Number( with country code)",
        "Name (Optional)",
        "Custome Field (Optional)",
      ],
    ],
    { origin: "A1" }
  );
  b = Math.round(new Date().getTime());
  XLSX.writeFile(a, "excelTemplate" + b + ".xlsx");
}
function downloadContacts(a, b, c, d, e, k) {
  var g = [];
  "group" == a
    ? ((a = e),
      c ||
        (a = a.filter(function (l) {
          return b.includes(l.groupId);
        })),
      a.forEach(function (l) {
        l.members.forEach(function (h, n) {
          data = {};
          if (!(5 > h.phoneNumber.length)) {
            var p = $jscomp.makeIterator(findCountryDetail(h.phoneNumber, n));
            data.CountryCode = p.next().value;
            data.Country = p.next().value;
            data.CountryCode = "+" + data.CountryCode;
            data.displayName = h.displayName;
            data.phoneNumber = h.phoneNumber;
            data.savedName = h.savedName;
            data.groupName = l.groupName;
            g.push(data);
          }
        });
      }))
    : "list" == a &&
      k.forEach(function (l, h) {
        data = {};
        if (!(5 > l.members[0].phoneNumber.length)) {
          var n = $jscomp.makeIterator(
            findCountryDetail(l.members[0].phoneNumber, h)
          );
          data.CountryCode = n.next().value;
          data.Country = n.next().value;
          data.CountryCode = "+" + data.CountryCode;
          data.displayName = l.members[0].displayName;
          data.phoneNumber = l.members[0].phoneNumber;
          data.savedName = l.members[0].savedName;
          data.groupName = l.groupName;
          "unsavedChats" == d ? data.isMyContact || g.push(data) : g.push(data);
        }
      });
  a = XLSX.utils.json_to_sheet(g);
  a["!cols"] = [
    { wch: 15 },
    { wch: 15 },
    { wch: 25 },
    { wch: 20 },
    { wch: 20 },
    { wch: 20 },
  ];
  c = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(c, a, "myWorkSheet");
  XLSX.utils.sheet_add_aoa(
    a,
    [
      "Country Code;Country;Contact's Public Display Name;Phone Number;Saved Name;Group Name".split(
        ";"
      ),
    ],
    { origin: "A1" }
  );
  a = Math.round(new Date().getTime());
  XLSX.writeFile(c, "MyContacts" + a + ".xlsx");
}
function findCountryDetail(a, b) {
  try {
    var c = libphonenumber.parsePhoneNumber("+" + a);
    return [c.countryCallingCode, c.country];
  } catch (d) {
    throw d;
  }
}
function open_chat_details() {
  var a = document.evaluate(
    '//*[@id="main"]/header/div[2]',
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;
  document.evaluate(
    '//*[@id="app"]//div[contains(text(), "Group info")]',
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue || a.click();
}
function eventFire(a, b) {
  var c;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
    c = document.createEvent("MouseEvents");
    c.initMouseEvent(b, !0, !0, window, 0, 0, 0, 0, 0, !1, !1, !1, !1, 0, null);
    return d["return"](
      new Promise(function (e) {
        var k = setInterval(function () {
          document.querySelector('span[data-icon="send"]') &&
            (a.dispatchEvent(c), e((clearInterval(k), "BUTTON CLICKED")));
        }, 500);
      })
    );
  });
}
function isUnsubscribed() {
  try {
    var a = document.querySelector('div[data-tab="8"]');
    return null === a || null === a.lastElementChild
      ? !1
      : -1 !==
          a.lastElementChild.textContent
            .toLowerCase()
            .substring(0, 5)
            .indexOf("unsub");
  } catch (b) {
    return !1;
  }
}
function export_results() {
  var a =
    "data:text/csv;charset=utf-8," +
    rows
      .map(function (c) {
        return c.join(",");
      })
      .join("\n");
  a = encodeURI(a);
  var b = document.createElement("a");
  b.setAttribute("href", a);
  b.setAttribute("download", "Report.csv");
  document.body.appendChild(b);
  b.click();
  b.remove();
  rows = [["Phone Number", "Result"]];
}
function clickElements(a) {
  var b, c;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
    return 1 == d.nextAddress
      ? ((b = document.createEvent("MouseEvents")),
        b.initEvent("mouseover", !0, !0),
        (c = a.dispatchEvent(b)),
        b.initEvent("mousedown", !0, !0),
        a.dispatchEvent(b),
        b.initEvent("mouseup", !0, !0),
        a.dispatchEvent(b),
        b.initEvent("click", !0, !0),
        a.dispatchEvent(b),
        c
          ? d["return"](
              new Promise(function (e) {
                e();
              })
            )
          : d.yield(clickOnElements(a), 3))
      : d["return"](d.yieldResult);
  });
}
function sendText(a, b, c) {
  var d, e, k;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (g) {
    switch (g.nextAddress) {
      case 1:
        return (
          g.setCatchFinallyBlocks(2),
          (a = a.replace(/ /gm, " ")),
          (d = document.getElementById("wamessager"))
            ? d.setAttribute(
                "href",
                "https://wa.me/" + b + "?text=" + encodeURIComponent(a)
              )
            : ((e =
                '<a href="https://wa.me/' +
                b +
                "?text=" +
                a +
                '" id= "wamessager"></a>'),
              document.body.append(e)),
          document.getElementById("wamessager").click(),
          g.yield(sleep(500), 4)
        );
      case 4:
        return g.yield(
          clickElements(document.querySelector('span[data-icon="send"]')),
          5
        );
      case 5:
        g.leaveTryBlock(0);
        break;
      case 2:
        return (k = g.enterCatchBlock()), g.yield(sleep(5e3), 6);
      case 6:
        if (2 == c) throw k;
        return g.yield(sendText(a, b, c + 1), 0);
    }
  });
}
function send_both(a, b) {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
    send_image();
    "complete" === document.readyState && sendText(a, b);
    c.jumpToEnd();
  });
}
function sleep(a) {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (b) {
    return b.yield(
      chrome.runtime.sendMessage({ context: "sleep", time: a }),
      0
    );
  });
}
