var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.createTemplateTagFirstArg = function (e) {
  return (e.raw = e);
};
$jscomp.createTemplateTagFirstArgWithRaw = function (e, h) {
  e.raw = h;
  return e;
};
$jscomp.arrayIteratorImpl = function (e) {
  var h = 0;
  return function () {
    return h < e.length ? { done: !1, value: e[h++] } : { done: !0 };
  };
};
$jscomp.arrayIterator = function (e) {
  return { next: $jscomp.arrayIteratorImpl(e) };
};
$jscomp.makeIterator = function (e) {
  var h = "undefined" != typeof Symbol && Symbol.iterator && e[Symbol.iterator];
  if (h) return h.call(e);
  if ("number" == typeof e.length) return $jscomp.arrayIterator(e);
  throw Error(String(e) + " is not an iterable or ArrayLike");
};
$jscomp.arrayFromIterator = function (e) {
  for (var h, a = []; !(h = e.next()).done; ) a.push(h.value);
  return a;
};
$jscomp.arrayFromIterable = function (e) {
  return e instanceof Array
    ? e
    : $jscomp.arrayFromIterator($jscomp.makeIterator(e));
};
$jscomp.owns = function (e, h) {
  return Object.prototype.hasOwnProperty.call(e, h);
};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.SIMPLE_FROUND_POLYFILL = !1;
$jscomp.ISOLATE_POLYFILLS = !1;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
$jscomp.defineProperty =
  $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
    ? Object.defineProperty
    : function (e, h, a) {
        if (e == Array.prototype || e == Object.prototype) return e;
        e[h] = a.value;
        return e;
      };
$jscomp.getGlobal = function (e) {
  e = [
    "object" == typeof globalThis && globalThis,
    e,
    "object" == typeof window && window,
    "object" == typeof self && self,
    "object" == typeof global && global,
  ];
  for (var h = 0; h < e.length; ++h) {
    var a = e[h];
    if (a && a.Math == Math) return a;
  }
  throw Error("Cannot find global object");
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.IS_SYMBOL_NATIVE =
  "function" === typeof Symbol && "symbol" === typeof Symbol("x");
$jscomp.TRUST_ES6_POLYFILLS =
  !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
$jscomp.polyfills = {};
$jscomp.propertyToPolyfillSymbol = {};
$jscomp.POLYFILL_PREFIX = "$jscp$";
var $jscomp$lookupPolyfilledValue = function (e, h, a) {
  if (!a || null != e) {
    a = $jscomp.propertyToPolyfillSymbol[h];
    if (null == a) return e[h];
    a = e[a];
    return void 0 !== a ? a : e[h];
  }
};
$jscomp.polyfill = function (e, h, a, b) {
  h &&
    ($jscomp.ISOLATE_POLYFILLS
      ? $jscomp.polyfillIsolated(e, h, a, b)
      : $jscomp.polyfillUnisolated(e, h, a, b));
};
$jscomp.polyfillUnisolated = function (e, h, a, b) {
  a = $jscomp.global;
  e = e.split(".");
  for (b = 0; b < e.length - 1; b++) {
    var c = e[b];
    if (!(c in a)) return;
    a = a[c];
  }
  e = e[e.length - 1];
  b = a[e];
  h = h(b);
  h != b &&
    null != h &&
    $jscomp.defineProperty(a, e, { configurable: !0, writable: !0, value: h });
};
$jscomp.polyfillIsolated = function (e, h, a, b) {
  var c = e.split(".");
  e = 1 === c.length;
  b = c[0];
  b = !e && b in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
  for (var d = 0; d < c.length - 1; d++) {
    var g = c[d];
    if (!(g in b)) return;
    b = b[g];
  }
  c = c[c.length - 1];
  a = $jscomp.IS_SYMBOL_NATIVE && "es6" === a ? b[c] : null;
  h = h(a);
  null != h &&
    (e
      ? $jscomp.defineProperty($jscomp.polyfills, c, {
          configurable: !0,
          writable: !0,
          value: h,
        })
      : h !== a &&
        (void 0 === $jscomp.propertyToPolyfillSymbol[c] &&
          ((a = (1e9 * Math.random()) >>> 0),
          ($jscomp.propertyToPolyfillSymbol[c] = $jscomp.IS_SYMBOL_NATIVE
            ? $jscomp.global.Symbol(c)
            : $jscomp.POLYFILL_PREFIX + a + "$" + c)),
        $jscomp.defineProperty(b, $jscomp.propertyToPolyfillSymbol[c], {
          configurable: !0,
          writable: !0,
          value: h,
        })));
};
$jscomp.assign =
  $jscomp.TRUST_ES6_POLYFILLS && "function" == typeof Object.assign
    ? Object.assign
    : function (e, h) {
        for (var a = 1; a < arguments.length; a++) {
          var b = arguments[a];
          if (b) for (var c in b) $jscomp.owns(b, c) && (e[c] = b[c]);
        }
        return e;
      };
$jscomp.polyfill(
  "Object.assign",
  function (e) {
    return e || $jscomp.assign;
  },
  "es6",
  "es3"
);
$jscomp.underscoreProtoCanBeSet = function () {
  var e = { a: !0 },
    h = {};
  try {
    return (h.__proto__ = e), h.a;
  } catch (a) {}
  return !1;
};
$jscomp.setPrototypeOf =
  $jscomp.TRUST_ES6_POLYFILLS && "function" == typeof Object.setPrototypeOf
    ? Object.setPrototypeOf
    : $jscomp.underscoreProtoCanBeSet()
    ? function (e, h) {
        e.__proto__ = h;
        if (e.__proto__ !== h) throw new TypeError(e + " is not extensible");
        return e;
      }
    : null;
$jscomp.generator = {};
$jscomp.generator.ensureIteratorResultIsObject_ = function (e) {
  if (!(e instanceof Object))
    throw new TypeError("Iterator result " + e + " is not an object");
};
$jscomp.generator.Context = function () {
  this.isRunning_ = !1;
  this.yieldAllIterator_ = null;
  this.yieldResult = void 0;
  this.nextAddress = 1;
  this.finallyAddress_ = this.catchAddress_ = 0;
  this.finallyContexts_ = this.abruptCompletion_ = null;
};
$jscomp.generator.Context.prototype.start_ = function () {
  if (this.isRunning_) throw new TypeError("Generator is already running");
  this.isRunning_ = !0;
};
$jscomp.generator.Context.prototype.stop_ = function () {
  this.isRunning_ = !1;
};
$jscomp.generator.Context.prototype.jumpToErrorHandler_ = function () {
  this.nextAddress = this.catchAddress_ || this.finallyAddress_;
};
$jscomp.generator.Context.prototype.next_ = function (e) {
  this.yieldResult = e;
};
$jscomp.generator.Context.prototype.throw_ = function (e) {
  this.abruptCompletion_ = { exception: e, isException: !0 };
  this.jumpToErrorHandler_();
};
$jscomp.generator.Context.prototype["return"] = function (e) {
  this.abruptCompletion_ = { return: e };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks = function (e) {
  this.abruptCompletion_ = { jumpTo: e };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.yield = function (e, h) {
  this.nextAddress = h;
  return { value: e };
};
$jscomp.generator.Context.prototype.yieldAll = function (e, h) {
  var a = $jscomp.makeIterator(e),
    b = a.next();
  $jscomp.generator.ensureIteratorResultIsObject_(b);
  if (b.done) (this.yieldResult = b.value), (this.nextAddress = h);
  else return (this.yieldAllIterator_ = a), this.yield(b.value, h);
};
$jscomp.generator.Context.prototype.jumpTo = function (e) {
  this.nextAddress = e;
};
$jscomp.generator.Context.prototype.jumpToEnd = function () {
  this.nextAddress = 0;
};
$jscomp.generator.Context.prototype.setCatchFinallyBlocks = function (e, h) {
  this.catchAddress_ = e;
  void 0 != h && (this.finallyAddress_ = h);
};
$jscomp.generator.Context.prototype.setFinallyBlock = function (e) {
  this.catchAddress_ = 0;
  this.finallyAddress_ = e || 0;
};
$jscomp.generator.Context.prototype.leaveTryBlock = function (e, h) {
  this.nextAddress = e;
  this.catchAddress_ = h || 0;
};
$jscomp.generator.Context.prototype.enterCatchBlock = function (e) {
  this.catchAddress_ = e || 0;
  e = this.abruptCompletion_.exception;
  this.abruptCompletion_ = null;
  return e;
};
$jscomp.generator.Context.prototype.enterFinallyBlock = function (e, h, a) {
  a
    ? (this.finallyContexts_[a] = this.abruptCompletion_)
    : (this.finallyContexts_ = [this.abruptCompletion_]);
  this.catchAddress_ = e || 0;
  this.finallyAddress_ = h || 0;
};
$jscomp.generator.Context.prototype.leaveFinallyBlock = function (e, h) {
  var a = this.finallyContexts_.splice(h || 0)[0];
  if ((a = this.abruptCompletion_ = this.abruptCompletion_ || a)) {
    if (a.isException) return this.jumpToErrorHandler_();
    void 0 != a.jumpTo && this.finallyAddress_ < a.jumpTo
      ? ((this.nextAddress = a.jumpTo), (this.abruptCompletion_ = null))
      : (this.nextAddress = this.finallyAddress_);
  } else this.nextAddress = e;
};
$jscomp.generator.Context.prototype.forIn = function (e) {
  return new $jscomp.generator.Context.PropertyIterator(e);
};
$jscomp.generator.Context.PropertyIterator = function (e) {
  this.object_ = e;
  this.properties_ = [];
  for (var h in e) this.properties_.push(h);
  this.properties_.reverse();
};
$jscomp.generator.Context.PropertyIterator.prototype.getNext = function () {
  for (; 0 < this.properties_.length; ) {
    var e = this.properties_.pop();
    if (e in this.object_) return e;
  }
  return null;
};
$jscomp.generator.Engine_ = function (e) {
  this.context_ = new $jscomp.generator.Context();
  this.program_ = e;
};
$jscomp.generator.Engine_.prototype.next_ = function (e) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_.next,
      e,
      this.context_.next_
    );
  this.context_.next_(e);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.return_ = function (e) {
  this.context_.start_();
  var h = this.context_.yieldAllIterator_;
  if (h)
    return this.yieldAllStep_(
      "return" in h
        ? h["return"]
        : function (a) {
            return { value: a, done: !0 };
          },
      e,
      this.context_["return"]
    );
  this.context_["return"](e);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.throw_ = function (e) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_["throw"],
      e,
      this.context_.next_
    );
  this.context_.throw_(e);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.yieldAllStep_ = function (e, h, a) {
  try {
    var b = e.call(this.context_.yieldAllIterator_, h);
    $jscomp.generator.ensureIteratorResultIsObject_(b);
    if (!b.done) return this.context_.stop_(), b;
    var c = b.value;
  } catch (d) {
    return (
      (this.context_.yieldAllIterator_ = null),
      this.context_.throw_(d),
      this.nextStep_()
    );
  }
  this.context_.yieldAllIterator_ = null;
  a.call(this.context_, c);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.nextStep_ = function () {
  for (; this.context_.nextAddress; )
    try {
      var e = this.program_(this.context_);
      if (e) return this.context_.stop_(), { value: e.value, done: !1 };
    } catch (h) {
      (this.context_.yieldResult = void 0), this.context_.throw_(h);
    }
  this.context_.stop_();
  if (this.context_.abruptCompletion_) {
    e = this.context_.abruptCompletion_;
    this.context_.abruptCompletion_ = null;
    if (e.isException) throw e.exception;
    return { value: e["return"], done: !0 };
  }
  return { value: void 0, done: !0 };
};
$jscomp.generator.Generator_ = function (e) {
  this.next = function (h) {
    return e.next_(h);
  };
  this["throw"] = function (h) {
    return e.throw_(h);
  };
  this["return"] = function (h) {
    return e.return_(h);
  };
  this[Symbol.iterator] = function () {
    return this;
  };
};
$jscomp.generator.createGenerator = function (e, h) {
  var a = new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(h));
  $jscomp.setPrototypeOf &&
    e.prototype &&
    $jscomp.setPrototypeOf(a, e.prototype);
  return a;
};
$jscomp.asyncExecutePromiseGenerator = function (e) {
  function h(b) {
    return e.next(b);
  }
  function a(b) {
    return e["throw"](b);
  }
  return new Promise(function (b, c) {
    function d(g) {
      g.done ? b(g.value) : Promise.resolve(g.value).then(h, a).then(d, c);
    }
    d(e.next());
  });
};
$jscomp.asyncExecutePromiseGeneratorFunction = function (e) {
  return $jscomp.asyncExecutePromiseGenerator(e());
};
$jscomp.asyncExecutePromiseGeneratorProgram = function (e) {
  return $jscomp.asyncExecutePromiseGenerator(
    new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(e))
  );
};
(function () {
  function e() {
    function a(b) {
      var c = 0,
        d = [
          {
            id: "WAMStore",
            conditions: function (f) {
              return f["default"] && f["default"].Chat && f["default"].Msg
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMMediaCollection",
            conditions: function (f) {
              return f["default"] &&
                f["default"].prototype &&
                f["default"].prototype.processAttachments
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMMediaProcess",
            conditions: function (f) {
              return f.BLOB ? f : null;
            },
          },
          {
            id: "WAMWap",
            conditions: function (f) {
              return f.createGroup ? f : null;
            },
          },
          {
            id: "WAMServiceWorker",
            conditions: function (f) {
              return f["default"] && f["default"].killServiceWorker ? f : null;
            },
          },
          {
            id: "WAMState",
            conditions: function (f) {
              return f.WAMState && f.STREAM ? f : null;
            },
          },
          {
            id: "WAMWapDelete",
            conditions: function (f) {
              return f.sendConversationDelete &&
                2 == f.sendConversationDelete.length
                ? f
                : null;
            },
          },
          {
            id: "WAMConn",
            conditions: function (f) {
              return f["default"] && f["default"].ref && f["default"].refTTL
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMWapQuery",
            conditions: function (f) {
              return f["default"] && f["default"].queryExist
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMCryptoLib",
            conditions: function (f) {
              return f.decryptE2EMedia ? f : null;
            },
          },
          {
            id: "WAMOpenChat",
            conditions: function (f) {
              return f["default"] &&
                f["default"].prototype &&
                f["default"].prototype.WAMOpenChat
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMUserConstructor",
            conditions: function (f) {
              return f["default"] &&
                f["default"].prototype &&
                f["default"].prototype.isServer &&
                f["default"].prototype.isUser
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMSendTextMsgToChat",
            conditions: function (f) {
              return f.WAMSendTextMsgToChat ? f.WAMSendTextMsgToChat : null;
            },
          },
          {
            id: "WAMWidFactory",
            conditions: function (f) {
              return f.createUserWid ? f : null;
            },
          },
          {
            id: "WAMSendSeen",
            conditions: function (f) {
              return f.WAMSendSeen ? f.WAMSendSeen : null;
            },
          },
          {
            id: "WAMsendDelete",
            conditions: function (f) {
              return f.WAMsendDelete ? f.WAMsendDelete : null;
            },
          },
          {
            id: "WAMCmd",
            conditions: function (f) {
              return f["default"] && f["default"].openModalMedia
                ? f["default"]
                : null;
            },
          },
          {
            id: "WAMMe",
            conditions: function (f) {
              return f.PLATFORMS && f.WAMConn ? f["default"] : null;
            },
          },
        ],
        g = {},
        k;
      for (k in b) {
        g.$jscomp$loop$prop$idx$5 = k;
        if (
          "object" === typeof b[g.$jscomp$loop$prop$idx$5] &&
          null !== b[g.$jscomp$loop$prop$idx$5] &&
          (d.forEach(
            (function (f) {
              return function (l) {
                if (l.conditions && !l.foundedModule) {
                  var m = l.conditions(b[f.$jscomp$loop$prop$idx$5]);
                  null !== m && (c++, (l.foundedModule = m));
                }
              };
            })(g)
          ),
          c == d.length)
        )
          break;
        g = { $jscomp$loop$prop$idx$5: g.$jscomp$loop$prop$idx$5 };
      }
      g = d.find(function (f) {
        return "WAMStore" === f.id;
      });
      window.WAMStore = g.foundedModule ? g.foundedModule : {};
      d.splice(d.indexOf(g), 1);
      d.forEach(function (f) {
        f.foundedModule && (window.WAMStore[f.id] = f.foundedModule);
      });
      window.WAMStore.Chat.modelClass.prototype.sendMessage = function (f) {
        window.WAMStore.WAMSendTextMsgToChat.apply(
          window.WAMStore,
          [this].concat($jscomp.arrayFromIterable(arguments))
        );
      };
      return window.WAMStore;
    }
    return new Promise(function (b, c) {
      if (
        null === document.querySelector("#pane-side") ||
        ("function" !== typeof webpackJsonp && !webpackChunkwhatsapp_web_client)
      )
        c("Page not loaded yet");
      else if ("function" === typeof webpackJsonp)
        webpackJsonp(
          [],
          {
            parasite: function (g, k, f) {
              try {
                a(f), b();
              } catch (l) {
                c(l);
              }
            },
          },
          ["parasite"]
        );
      else {
        var d = new Date().getTime();
        webpackChunkwhatsapp_web_client.push([
          ["parasite" + d],
          {},
          function (g, k, f) {
            k = [];
            for (var l in g.m) (f = g(l)), k.push(f);
            try {
              a(k), b();
            } catch (m) {
              c(m);
            }
          },
        ]);
      }
    });
  }
  var h = setInterval(function () {
    e()
      .then(function () {
        window.WAMStore.Chat._find ||
          ((window.WAMStore.Chat._findAndParse =
            window.WAMStore.BusinessProfile._findAndParse),
          (window.WAMStore.Chat._find = window.WAMStore.BusinessProfile._find));
        window.WAM = { lastRead: {} };
        window.WAM._serializeRawObj = function (a) {
          if (a) {
            var b = {};
            a = a.toJSON ? a.toJSON() : Object.assign({}, a);
            for (var c in a)
              "id" === c
                ? (b[c] = Object.assign({}, a[c]))
                : "object" !== typeof a[c] || Array.isArray(a[c])
                ? (b[c] = a[c])
                : (b[c] = window.WAM._serializeRawObj(a[c]));
            return b;
          }
          return {};
        };
        window.WAM._serializeChatObj = function (a) {
          return void 0 == a
            ? null
            : Object.assign(window.WAM._serializeRawObj(a), {
                kind: a.kind,
                isGroup: a.isGroup,
                contact: a.contact
                  ? window.WAM._serializeContactObj(a.contact)
                  : null,
                groupMetadata: a.groupMetadata
                  ? window.WAM._serializeRawObj(a.groupMetadata)
                  : null,
                presence: a.presence
                  ? window.WAM._serializeRawObj(a.presence)
                  : null,
                msgs: null,
              });
        };
        window.WAM._serializeContactObj = function (a) {
          return void 0 == a
            ? null
            : Object.assign(window.WAM._serializeRawObj(a), {
                formattedName: a.formattedName,
                displayName: a.displayName,
                isHighLevelVerified: a.isHighLevelVerified,
                isMe: a.isMe,
                isMyContact: a.isMyContact,
                isPSA: a.isPSA,
                isUser: a.isUser,
                isVerified: a.isVerified,
                isWAContact: a.isWAContact,
                profilePicThumbObj: a.profilePicThumb
                  ? WAM._serializeProfilePicThumb(a.profilePicThumb)
                  : {},
                statusMute: a.statusMute,
                msgs: null,
              });
        };
        window.WAM._serializeMessageObj = function (a) {
          return void 0 == a
            ? null
            : Object.assign(
                window.WAM._serializeRawObj(a),
                window.WAM._serializeRawObj({
                  id: a.id._serialized,
                  sender: a.senderObj
                    ? WAM._serializeContactObj(a.senderObj)
                    : null,
                  timestamp: a.t,
                  content: a.body,
                  isGroupMsg: a.isGroupMsg,
                  isLink: a.isLink,
                  isMMS: a.isMMS,
                  isMedia: a.isMedia,
                  isNotification: a.isNotification,
                  isPSA: a.isPSA,
                  type: a.type,
                  chat: WAM._serializeChatObj(a.chat),
                  chatId: a.id.remote,
                  quotedMsgObj: WAM._serializeMessageObj(a._quotedMsgObj),
                  mediaData: window.WAM._serializeRawObj(a.mediaData),
                })
              );
        };
        window.WAM._serializeNumberStatusObj = function (a) {
          return void 0 == a
            ? null
            : Object.assign(
                {},
                window.WAM._serializeRawObj({
                  id: a.jid,
                  status: a.status,
                  isBusiness: !0 === a.biz,
                  canReceiveMessage: 200 === a.status,
                })
              );
        };
        window.WAM._serializeProfilePicThumb = function (a) {
          return void 0 == a
            ? null
            : Object.assign(
                {},
                window.WAM._serializeRawObj({
                  eurl: a.eurl,
                  id: a.id,
                  img: a.img,
                  imgFull: a.imgFull,
                  raw: a.raw,
                  tag: a.tag,
                })
              );
        };
        window.WAM.createGroup = function (a, b) {
          Array.isArray(b) || (b = [b]);
          return window.WAMStore.WAMWap.createGroup(a, b);
        };
        window.WAM.leaveGroup = function (a) {
          a = "string" == typeof a ? a : a._serialized;
          return WAM.getChat(a).sendExit();
        };
        window.WAM.getAllContacts = function (a) {
          var b = window.WAMStore.Contact.map(function (c) {
            return WAM._serializeContactObj(c);
          });
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.getMyContacts = function (a) {
          var b = window.WAMStore.Contact.filter(function (c) {
            return !0 === c.isMyContact;
          }).map(function (c) {
            return WAM._serializeContactObj(c);
          });
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.getContact = function (a, b) {
          var c = window.WAMStore.Contact.get(a);
          void 0 !== b && b(window.WAM._serializeContactObj(c));
          return window.WAM._serializeContactObj(c);
        };
        window.WAM.getAllChats = function (a) {
          var b = window.WAMStore.Chat.map(function (c) {
            return WAM._serializeChatObj(c);
          });
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.haveNewMsg = function (a) {
          return 0 < a.unreadCount;
        };
        window.WAM.getAllChatsWithNewMsg = function (a) {
          var b = window.WAMStore.Chat.filter(window.WAM.haveNewMsg).map(
            function (c) {
              return WAM._serializeChatObj(c);
            }
          );
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.getAllChatIds = function (a) {
          var b = window.WAMStore.Chat.map(function (c) {
            return c.id._serialized || c.id;
          });
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.getAllGroups = function (a) {
          var b;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
            if (1 == c.nextAddress)
              return c.yield(
                Promise.all(
                  window.WAMStore.Chat.filter(function (d) {
                    return d.isGroup;
                  }).map(function (d) {
                    return window.WAMStore.GroupMetadata.update(d.id).then(
                      function () {
                        var g = d.groupMetadata.participants;
                        g = g
                          .map(function (k) {
                            return k.contact;
                          })
                          .filter(function (k) {
                            return !k.isMe;
                          })
                          .map(function (k) {
                            return window.WAM._serializeContactObj(k);
                          });
                        return Object.assign(window.WAM._serializeChatObj(d), {
                          participants: g,
                        });
                      }
                    );
                  })
                ),
                2
              );
            b = c.yieldResult;
            void 0 !== a && a(b);
            return c["return"](b);
          });
        };
        window.WAM.getAllBroadcasts = function (a) {
          var b;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
            if (1 == c.nextAddress)
              return c.yield(
                Promise.all(
                  window.WAMStore.Chat.filter(function (d) {
                    return d.isBroadcast;
                  }).map(function (d) {
                    return window.WAMStore.GroupMetadata.update(d.id).then(
                      function () {
                        var g = d.groupMetadata.participants;
                        g = g
                          .map(function (k) {
                            return k.contact;
                          })
                          .filter(function (k) {
                            return !k.isMe;
                          })
                          .map(function (k) {
                            return window.WAM._serializeContactObj(k);
                          });
                        return Object.assign(window.WAM._serializeChatObj(d), {
                          participants: g,
                        });
                      }
                    );
                  })
                ),
                2
              );
            b = c.yieldResult;
            void 0 !== a && a(b);
            return c["return"](b);
          });
        };
        window.WAM.getChat = function (a, b) {
          a = "string" == typeof a ? a : a._serialized;
          var c = window.WAMStore.Chat.get(a);
          c.sendMessage = c.sendMessage
            ? c.sendMessage
            : function () {
                return window.WAMStore.sendMessage.apply(this, arguments);
              };
          void 0 !== b && b(c);
          return c;
        };
        window.WAM.getChatByName = function (a, b) {
          var c = window.WAM.getAllChats().find(function (d) {
            return d.name.includes(a);
          });
          void 0 !== b && b(c);
          return c;
        };
        window.WAM.sendImageFromDatabasePicBot = function (a, b, c) {
          var d = window.WAM.getChatByName("DATABASEPICBOT").msgs.find(
            function (k) {
              return k.caption == a;
            }
          );
          if (void 0 === d || void 0 === WAM.getChat(b)) return !1;
          var g = d.caption;
          d.id.id = window.WAM.getNewId();
          d.id.remote = b;
          d.t = Math.ceil(new Date().getTime() / 1e3);
          d.to = b;
          d.caption = void 0 !== c && "" !== c ? c : "";
          d.collection.send(d).then(function (k) {
            d.caption = g;
          });
          return !0;
        };
        window.WAM.sendMessageWithThumb = function (a, b, c, d, g, k, f) {
          k = WAM.getChat(k);
          if (void 0 === k) return void 0 !== f && f(!1), !1;
          k.sendMessage(g, {
            linkPreview: {
              canonicalUrl: b,
              description: d,
              matchedText: b,
              title: c,
              thumbnail: a,
              compose: !0,
            },
            mentionedJidList: [],
            quotedMsg: null,
            quotedMsgAdminGroupJid: null,
          });
          void 0 !== f && f(!0);
          return !0;
        };
        window.WAM.getNewId = function () {
          for (var a = "", b = 0; 20 > b; b++)
            a +=
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(
                Math.floor(62 * Math.random())
              );
          return a;
        };
        window.WAM.getChatById = function (a, b) {
          var c = WAM.getChat(a);
          c = c ? WAM._serializeChatObj(c) : !1;
          void 0 !== b && b(c);
          return c;
        };
        window.WAM.getUnreadMessagesInChat = function (a, b, c, d) {
          a = WAM.getChat(a).msgs._models;
          for (var g = [], k = a.length - 1; 0 <= k; k--)
            if ("remove" !== k) {
              var f = a[k];
              "boolean" === typeof f.isNewMsg &&
                !1 !== f.isNewMsg &&
                ((f.isNewMsg = !1),
                (f = WAM.processMessageObj(f, b, c)) && g.push(f));
            }
          void 0 !== d && d(g);
          return g;
        };
        window.WAM.loadEarlierMessages = function (a, b) {
          var c = WAM.getChat(a);
          void 0 !== b
            ? c.loadEarlierMsgs().then(function () {
                b();
              })
            : c.loadEarlierMsgs();
        };
        window.WAM.loadAllEarlierMessages = function (a, b) {
          var c = WAM.getChat(a),
            d = function () {
              c.msgs.msgLoadState.noEarlierMsgs
                ? b && b()
                : c.loadEarlierMsgs().then(d);
            };
          d();
        };
        window.WAM.asyncLoadAllEarlierMessages = function (a, b) {
          b();
          window.WAM.loadAllEarlierMessages(a);
        };
        window.WAM.areAllMessagesLoaded = function (a, b) {
          if (!WAM.getChat(a).msgs.msgLoadState.noEarlierMsgs)
            return b && b(!1), !1;
          b && b(!0);
          return !0;
        };
        window.WAM.loadEarlierMessagesTillDate = function (a, b, c) {
          var d = WAM.getChat(a),
            g = function () {
              d.msgs.models[0].t > b && !d.msgs.msgLoadState.noEarlierMsgs
                ? d.loadEarlierMsgs().then(g)
                : c();
            };
          g();
        };
        window.WAM.getAllGroupMetadata = function (a) {
          var b = window.WAMStore.GroupMetadata.map(function (c) {
            return c.all;
          });
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.getGroupMetadata = function (a, b) {
          var c;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
            if (1 == d.nextAddress)
              return (
                (c = window.WAMStore.GroupMetadata.get(a)),
                void 0 !== c && c.stale
                  ? d.yield(window.WAMStore.GroupMetadata.update(a), 2)
                  : d.jumpTo(2)
              );
            void 0 !== b && b(c);
            return d["return"](c);
          });
        };
        window.WAM._getGroupParticipants = function (a) {
          var b;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (c) {
            if (1 == c.nextAddress) return c.yield(WAM.getGroupMetadata(a), 2);
            b = c.yieldResult;
            return c["return"](b.participants);
          });
        };
        window.WAM.getGroupParticipantIDs = function (a, b) {
          var c;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
            if (1 == d.nextAddress)
              return d.yield(WAM._getGroupParticipants(a), 2);
            c = d.yieldResult.map(function (g) {
              return g.id;
            });
            void 0 !== b && b(c);
            return d["return"](c);
          });
        };
        window.WAM.getGroupAdmins = function (a, b) {
          var c;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
            if (1 == d.nextAddress)
              return d.yield(WAM._getGroupParticipants(a), 2);
            c = d.yieldResult
              .filter(function (g) {
                return g.isAdmin;
              })
              .map(function (g) {
                return g.id;
              });
            void 0 !== b && b(c);
            return d["return"](c);
          });
        };
        window.WAM.getMe = function (a) {
          var b = window.WAMStore.Contact.filter(function (c) {
            return !0 === c.isMe;
          }).map(function (c) {
            return WAM._serializeContactObj(c);
          });
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.isLoggedIn = function (a) {
          var b =
            window.WAMStore.Contact &&
            void 0 !== window.WAMStore.Contact.checksum;
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.isConnected = function (a) {
          var b =
            null !== document.querySelector('*[data-icon="alert-phone"]') ||
            null !== document.querySelector('*[data-icon="alert-computer"]')
              ? !1
              : !0;
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.processMessageObj = function (a, b, c) {
          if (a.isNotification) {
            if (c) return WAM._serializeMessageObj(a);
          } else if (!1 === a.id.fromMe || b)
            return WAM._serializeMessageObj(a);
        };
        window.WAM.getAllMessagesInChat = function (a, b, c, d) {
          var g = [];
          a = WAM.getChat(a).msgs._models;
          for (var k in a)
            if ("remove" !== k) {
              var f = WAM.processMessageObj(a[k], b, c);
              f && g.push(f);
            }
          void 0 !== d && d(g);
          return g;
        };
        window.WAM.getAllMessageIdsInChat = function (a, b, c, d) {
          var g = [];
          a = WAM.getChat(a).msgs._models;
          for (var k in a)
            "remove" === k ||
              (!b && a[k].isMe) ||
              (!c && a[k].isNotification) ||
              g.push(a[k].id._serialized);
          void 0 !== d && d(g);
          return g;
        };
        window.WAM.getMessageById = function (a, b) {
          var c = !1;
          try {
            var d = window.WAMStore.Msg.get(a);
            d && (c = WAM.processMessageObj(d, !0, !0));
          } catch (g) {}
          if (void 0 !== b) b(c);
          else return c;
        };
        window.WAM.ReplyMessage = function (a, b, c) {
          a = window.WAMStore.Msg.get(a);
          if (void 0 === a) return void 0 !== c && c(!1), !1;
          var d = WAM.getChat(a.chat.id);
          if (void 0 !== d)
            return (
              void 0 !== c
                ? d.sendMessage(b, { quotedMsg: a }, a).then(function () {
                    function g(l) {
                      return new Promise(function (m) {
                        return setTimeout(m, l);
                      });
                    }
                    function k() {
                      for (var l = d.msgs.models.length - 1; 0 <= l; l--) {
                        var m = d.msgs.models[l];
                        if (m.senderObj.isMe && m.body == b)
                          return c(WAM._serializeMessageObj(m)), True;
                      }
                      f += 1;
                      30 < f ? c(!0) : g(500).then(k);
                    }
                    var f = 0;
                    k();
                  })
                : d.sendMessage(b, { quotedMsg: a }, a),
              !0
            );
          void 0 !== c && c(!1);
          return !1;
        };
        window.WAM.sendMessageToID = function (a, b, c) {
          try {
            (window.getContact = function (k) {
              return WAMStore.WAMWapQuery.queryExist(k);
            }),
              window.getContact(a).then(function (k) {
                404 === k.status
                  ? c(!0)
                  : WAMStore.Chat.find(k.jid)
                      .then(function (f) {
                        f.sendMessage(b);
                        return !0;
                      })
                      ["catch"](function (f) {
                        if (WAM.sendMessage(a, b)) return c(!0), !0;
                        c(!1);
                        return !1;
                      });
              });
          } catch (k) {
            if (0 === window.WAMStore.Chat.length) return !1;
            var d = WAMStore.Chat.models[0],
              g = d.id;
            d.id =
              "string" === typeof g
                ? a
                : new window.WAMStore.WAMUserConstructor(a, {
                    intentionallyUsePrivateConstructor: !0,
                  });
            void 0 !== c
              ? d.sendMessage(b).then(function () {
                  d.id = g;
                  c(!0);
                })
              : (d.sendMessage(b), (d.id = g));
            return !0;
          }
          void 0 !== c && c(!1);
          return !1;
        };
        window.WAM.sendMessage = function (a, b, c) {
          var d = WAM.getChat(a);
          if (void 0 !== d)
            return (
              void 0 !== c
                ? d.sendMessage(b).then(function () {
                    function g(l) {
                      return new Promise(function (m) {
                        return setTimeout(m, l);
                      });
                    }
                    function k() {
                      for (var l = d.msgs.models.length - 1; 0 <= l; l--) {
                        var m = d.msgs.models[l];
                        if (m.senderObj.isMe && m.body == b)
                          return c(WAM._serializeMessageObj(m)), True;
                      }
                      f += 1;
                      30 < f ? c(!0) : g(500).then(k);
                    }
                    var f = 0;
                    k();
                  })
                : d.sendMessage(b),
              !0
            );
          void 0 !== c && c(!1);
          return !1;
        };
        window.WAM.sendMessage2 = function (a, b, c) {
          a = WAM.getChat(a);
          if (void 0 !== a)
            try {
              return (
                void 0 !== c
                  ? a.sendMessage(b).then(function () {
                      c(!0);
                    })
                  : a.sendMessage(b),
                !0
              );
            } catch (d) {
              return void 0 !== c && c(!1), !1;
            }
          void 0 !== c && c(!1);
          return !1;
        };
        window.WAM.WAMSendSeen = function (a, b) {
          var c = window.WAM.getChat(a);
          if (void 0 !== c)
            return (
              void 0 !== b
                ? (void 0 === c.getLastMsgKeyForAction &&
                    (c.getLastMsgKeyForAction = function () {}),
                  WAMStore.WAMSendSeen(c, !1).then(function () {
                    b(!0);
                  }))
                : WAMStore.WAMSendSeen(c, !1),
              !0
            );
          void 0 !== b && b();
          return !1;
        };
        window.WAM.getUnreadMessages = function (a, b, c, d) {
          var g = window.WAMStore.Chat.models,
            k = [],
            f;
          for (f in g)
            if (!isNaN(f)) {
              var l = g[f],
                m = WAM._serializeChatObj(l);
              m.messages = [];
              for (var q = l.msgs._models, p = q.length - 1; 0 <= p; p--) {
                var n = q[p];
                "boolean" == typeof n.isNewMsg &&
                  !1 !== n.isNewMsg &&
                  ((n.isNewMsg = !1),
                  (n = WAM.processMessageObj(n, a, b)) && m.messages.push(n));
              }
              if (0 < m.messages.length) k.push(m);
              else if (c) {
                p = l.unreadCount;
                for (n = q.length - 1; 0 <= n; n--) {
                  var r = q[n];
                  if (0 < p)
                    r.isSentByMe ||
                      ((r = WAM.processMessageObj(r, a, b)),
                      m.messages.unshift(r),
                      --p);
                  else if (-1 === p) {
                    if (!r.isSentByMe) {
                      q = WAM.processMessageObj(r, a, b);
                      m.messages.unshift(q);
                      break;
                    }
                  } else break;
                }
                0 < m.messages.length && ((l.unreadCount = 0), k.push(m));
              }
            }
          void 0 !== d && d(k);
          return k;
        };
        window.WAM.getGroupOwnerID = function (a, b) {
          var c;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
            if (1 == d.nextAddress) return d.yield(WAM.getGroupMetadata(a), 2);
            c = d.yieldResult.owner.id;
            void 0 !== b && b(c);
            return d["return"](c);
          });
        };
        window.WAM.getCommonGroups = function (a, b) {
          var c, d, g, k, f;
          return $jscomp.asyncExecutePromiseGeneratorProgram(function (l) {
            switch (l.nextAddress) {
              case 1:
                return (c = []), l.yield(window.WAM.getAllGroups(), 2);
              case 2:
                (d = l.yieldResult), (k = l.forIn(d));
              case 3:
                if (null == (g = k.getNext())) {
                  l.jumpTo(5);
                  break;
                }
                l.setCatchFinallyBlocks(6);
                return l.yield(window.WAM.getGroupParticipantIDs(d[g].id), 8);
              case 8:
                f = l.yieldResult;
                f.filter(function (m) {
                  return m == a;
                }).length && c.push(d[g]);
                l.leaveTryBlock(3);
                break;
              case 6:
                l.enterCatchBlock();
                l.jumpTo(3);
                break;
              case 5:
                return void 0 !== b && b(c), l["return"](c);
            }
          });
        };
        window.WAM.getProfilePicSmallFromId = function (a, b) {
          window.WAMStore.ProfilePicThumb.find(a).then(
            function (c) {
              void 0 !== c.img
                ? window.WAM.downloadFileWithCredentials(c.img, b)
                : b(!1);
            },
            function (c) {
              b(!1);
            }
          );
        };
        window.WAM.getProfilePicFromId = function (a, b) {
          window.WAMStore.ProfilePicThumb.find(a).then(
            function (c) {
              void 0 !== c.imgFull
                ? window.WAM.downloadFileWithCredentials(c.imgFull, b)
                : b(!1);
            },
            function (c) {
              b(!1);
            }
          );
        };
        window.WAM.downloadFileWithCredentials = function (a, b) {
          var c = new XMLHttpRequest();
          c.onload = function () {
            if (4 == c.readyState)
              if (200 == c.status) {
                var d = new FileReader();
                d.readAsDataURL(c.response);
                d.onload = function (g) {
                  b(d.result.substr(d.result.indexOf(",") + 1));
                };
              } else console.error(c.statusText);
            else b(!1);
          };
          c.open("GET", a, !0);
          c.withCredentials = !0;
          c.responseType = "blob";
          c.send(null);
        };
        window.WAM.downloadFile = function (a, b) {
          var c = new XMLHttpRequest();
          c.onload = function () {
            if (4 == c.readyState)
              if (200 == c.status) {
                var d = new FileReader();
                d.readAsDataURL(c.response);
                d.onload = function (g) {
                  b(d.result.substr(d.result.indexOf(",") + 1));
                };
              } else console.error(c.statusText);
            else b(!1);
          };
          c.open("GET", a, !0);
          c.responseType = "blob";
          c.send(null);
        };
        window.WAM.getBatteryLevel = function (a) {
          if (window.WAMStore.WAMConn.plugged)
            return void 0 !== a && a(100), 100;
          var b = window.WAMStore.WAMConn.battery;
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.deleteConversation = function (a, b) {
          var c = new window.WAMStore.WAMUserConstructor(a, {
            intentionallyUsePrivateConstructor: !0,
          });
          c = WAM.getChat(c);
          if (!c) return void 0 !== b && b(!1), !1;
          window.WAMStore.WAMsendDelete(c, !1)
            .then(function () {
              void 0 !== b && b(!0);
            })
            ["catch"](function () {
              void 0 !== b && b(!1);
            });
          return !0;
        };
        window.WAM.deleteMessage = function (a, b, c, d) {
          c = void 0 === c ? !1 : c;
          a = new window.WAMStore.WAMUserConstructor(a, {
            intentionallyUsePrivateConstructor: !0,
          });
          a = WAM.getChat(a);
          if (!a) return void 0 !== d && d(!1), !1;
          Array.isArray(b) || (b = [b]);
          b = b.map(function (g) {
            return window.WAMStore.Msg.get(g);
          });
          c ? a.sendRevokeMsgs(b, a) : a.sendDeleteMsgs(b, a);
          void 0 !== d && d(!0);
          return !0;
        };
        window.WAM.checkNumberStatus = function (a, b) {
          window.WAMStore.WAMWapQuery.queryExist(a)
            .then(function (c) {
              if (void 0 !== b) {
                if (void 0 === c.jid) throw 404;
                b(window.WAM._serializeNumberStatusObj(c));
              }
            })
            ["catch"](function (c) {
              void 0 !== b &&
                b(window.WAM._serializeNumberStatusObj({ status: c, jid: a }));
            });
          return !0;
        };
        window.WAM._newMessagesQueue = [];
        window.WAM._newMessagesBuffer =
          null != sessionStorage.getItem("saved_msgs")
            ? JSON.parse(sessionStorage.getItem("saved_msgs"))
            : [];
        window.WAM._newMessagesDebouncer = null;
        window.WAM._newMessagesCallbacks = [];
        window.WAMStore.Msg.off("add");
        sessionStorage.removeItem("saved_msgs");
        window.WAM._newMessagesListener = window.WAMStore.Msg.on(
          "add",
          function (a) {
            if (a && a.isNewMsg && !a.isSentByMe) {
              if ((a = window.WAM.processMessageObj(a, !1, !1)))
                window.WAM._newMessagesQueue.push(a),
                  window.WAM._newMessagesBuffer.push(a);
              !window.WAM._newMessagesDebouncer &&
                0 < window.WAM._newMessagesQueue.length &&
                (window.WAM._newMessagesDebouncer = setTimeout(function () {
                  var b = window.WAM._newMessagesQueue;
                  window.WAM._newMessagesDebouncer = null;
                  window.WAM._newMessagesQueue = [];
                  var c = [];
                  window.WAM._newMessagesCallbacks.forEach(function (d) {
                    void 0 !== d.callback && d.callback(b);
                    !0 === d.rmAfterUse && c.push(d);
                  });
                  c.forEach(function (d) {
                    d = window.WAM._newMessagesCallbacks.indexOf(d);
                    window.WAM._newMessagesCallbacks.splice(d, 1);
                  });
                }, 1e3));
            }
          }
        );
        window.WAM._unloadInform = function (a) {
          window.WAM._newMessagesBuffer.forEach(function (b) {
            Object.keys(b).forEach(function (c) {
              return void 0 === b[c] ? delete b[c] : "";
            });
          });
          sessionStorage.setItem(
            "saved_msgs",
            JSON.stringify(window.WAM._newMessagesBuffer)
          );
          window.WAM._newMessagesCallbacks.forEach(function (b) {
            void 0 !== b.callback &&
              b.callback({
                status: -1,
                message:
                  "page will be reloaded, wait and register callback again.",
              });
          });
        };
        window.addEventListener("unload", window.WAM._unloadInform, !1);
        window.addEventListener("beforeunload", window.WAM._unloadInform, !1);
        window.addEventListener("pageunload", window.WAM._unloadInform, !1);
        window.WAM.waitNewMessages = function (a, b) {
          window.WAM._newMessagesCallbacks.push({
            callback: b,
            rmAfterUse: void 0 === a ? !0 : a,
          });
          return !0;
        };
        window.WAM.getBufferedNewMessages = function (a) {
          var b = window.WAM._newMessagesBuffer;
          window.WAM._newMessagesBuffer = [];
          void 0 !== a && a(b);
          return b;
        };
        window.WAM.sendImage = function (a, b, c, d, g) {
          b = new window.WAMStore.WAMUserConstructor(b, {
            intentionallyUsePrivateConstructor: !0,
          });
          return WAMStore.Chat.find(b).then(function (k) {
            var f = window.WAM.base64ImageToFile(a, c),
              l = new WAMStore.WAMMediaCollection(k);
            l.processAttachments([{ file: f }, 1], k, 1).then(function () {
              l.models[0].sendToChat(k, { caption: d });
              void 0 !== g && g(!0);
            });
          });
        };
        window.WAM.base64ImageToFile = function (a, b) {
          var c = a.split(","),
            d = c[0].match(/:(.*?);/)[1];
          c = atob(c[1]);
          for (var g = c.length, k = new Uint8Array(g); g--; )
            k[g] = c.charCodeAt(g);
          return new File([k], b, { type: d });
        };
        window.WAM.sendContact = function (a, b) {
          Array.isArray(b) || (b = [b]);
          b = b.map(function (c) {
            return WAM.getChat(c).__x_contact;
          });
          1 < b.length
            ? window.WAM.getChat(a).sendContactList(b)
            : 1 === b.length && window.WAM.getChat(a).sendContact(b[0]);
        };
        window.WAM.getNewMessageId = function (a) {
          var b = WAMStore.Msg.models[0].__x_id.clone();
          b.fromMe = !0;
          b.id = WAM.getNewId().toUpperCase();
          b.remote = a;
          b._serialized = b.fromMe + "_" + b.remote + "_" + b.id;
          return b;
        };
        window.WAM.sendVCard = function (a, b) {
          var c = WAMStore.Chat.get(a),
            d = Object.create(
              WAMStore.Msg.models.filter(function (k) {
                return k.__x_isSentByMe;
              })[0]
            ),
            g = {
              ack: 0,
              id: window.WAM.getNewMessageId(a),
              local: !0,
              self: "out",
              t: parseInt(new Date().getTime() / 1e3),
              to: a,
              isNewMsg: !0,
            };
          Array.isArray(b)
            ? (Object.assign(g, { type: "multi_vcard", vcardList: b }),
              delete g.body)
            : (Object.assign(g, {
                type: "vcard",
                subtype: b.displayName,
                body: b.vcard,
              }),
              delete g.vcardList);
          Object.assign(d, g);
          c.addAndSendMsg(d);
        };
        window.WAM.contactBlock = function (a, b) {
          var c = window.WAMStore.Contact.get(a);
          if (void 0 !== c) return c.setBlock(!0), b(!0), !0;
          b(!1);
          return !1;
        };
        window.WAM.contactUnblock = function (a, b) {
          var c = window.WAMStore.Contact.get(a);
          if (void 0 !== c) return c.setBlock(!1), b(!0), !0;
          b(!1);
          return !1;
        };
        window.WAM.removeParticipantGroup = function (a, b, c) {
          window.WAMStore.WAMWapQuery.removeParticipants(a, [b]).then(
            function () {
              if (
                void 0 ===
                window.WAMStore.GroupMetadata.get(id).participants._index[b]
              )
                return c(!0), !0;
            }
          );
        };
        window.WAM.promoteParticipantAdminGroup = function (a, b, c) {
          window.WAMStore.WAMWapQuery.promoteParticipants(a, [b]).then(
            function () {
              var d =
                window.WAMStore.GroupMetadata.get(id).participants._index[b];
              if (void 0 !== d && d.isAdmin) return c(!0), !0;
              c(!1);
              return !1;
            }
          );
        };
        window.WAM.sendAttachment = function (a, b, c, d) {
          b = new window.WAMStore.WAMUserConstructor(b, {
            intentionallyUsePrivateConstructor: !0,
          });
          return WAMStore.Chat.find(b).then(function (g) {
            var k = new WAMStore.WAMMediaCollection(g);
            k.processAttachments([{ file: a }, 1], g, 1).then(function () {
              k._models[0].sendToChat(g, { caption: c });
            });
          });
        };
        window.WAM.demoteParticipantAdminGroup = function (a, b, c) {
          window.WAMStore.WAMWapQuery.demoteParticipants(a, [b]).then(
            function () {
              var d = window.WAMStore.GroupMetadata.get(id);
              if (void 0 === d) return c(!1), !1;
              d = d.participants._index[b];
              if (void 0 !== d && d.isAdmin) return c(!1), !1;
              c(!0);
              return !0;
            }
          );
        };
      })
      .then(function (a) {
        WAMinit();
        clearInterval(h);
      })
      ["catch"](function (a) {});
  }, 1e3);
})();
function WAMbase64toFile(e, h) {
  var a, b, c, d, g;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (k) {
    a = e.split(",");
    b = a[0].match(/:(.*?);/)[1];
    c = atob(a[1]);
    d = c.length;
    for (g = new Uint8Array(d); d--; ) g[d] = c.charCodeAt(d);
    return k["return"](new File([g], h, { type: b }));
  });
}
function WAMinit() {
  window.addEventListener("wam:get-contacts", function () {
    var e, h, a, b, c;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (d) {
      if (1 == d.nextAddress)
        return (
          (e = $jscomp), (h = e.makeIterator), d.yield(WAMgetContacts(), 2)
        );
      a = h.call(e, d.yieldResult);
      b = a.next().value;
      c = a.next().value;
      window.dispatchEvent(
        new CustomEvent("wam:get-contacts-ready", {
          detail: { groupList: b, chatList: c },
        })
      );
      d.jumpToEnd();
    });
  });
  window.addEventListener("wam::send-attachments", function (e) {
    var h, a, b, c, d, g, k, f, l;
    return $jscomp.asyncExecutePromiseGeneratorProgram(function (m) {
      switch (m.nextAddress) {
        case 1:
          m.setCatchFinallyBlocks(2),
            (h = e.detail.attachments),
            (a = e.detail.number),
            (b = a + "@c.us"),
            (d = 0);
        case 4:
          if (!(d < h.length)) {
            window.dispatchEvent(new CustomEvent("wam:attachments-sent"));
            m.leaveTryBlock(0);
            break;
          }
          c = h[d];
          return m.yield(JSON.parse(c.fileData), 7);
        case 7:
          return (
            (g = m.yieldResult), m.yield(WAMbase64toFile(g, c.fileName), 8)
          );
        case 8:
          return (
            (k = m.yieldResult),
            (f = c.fileCaption),
            m.yield(window.WAM.sendAttachment(k, b, f), 9)
          );
        case 9:
          return m.yield(WAMsleep(1e3), 5);
        case 5:
          d++;
          m.jumpTo(4);
          break;
        case 2:
          (l = m.enterCatchBlock()), console.log(l), m.jumpToEnd();
      }
    });
  });
}
function WAMgetContacts() {
  var e, h;
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (a) {
    return 1 == a.nextAddress
      ? ((e = []),
        (h = []),
        a.yield(
          window.WAM.getAllGroups().then(function (b) {
            e = b.map(function (c) {
              var d = {};
              d.groupName = c.contact.name;
              d.groupId = c.id.user;
              d.members = c.participants.map(function (g) {
                var k = {};
                k.displayName = g.verifiedName || g.pushname;
                k.phoneNumber = g.id.user;
                k.isMyContact = g.isMyContact;
                k.savedName = g.name || g.displayName;
                return k;
              });
              d.metadata = c.groupMetadata.participants.map(function (g) {
                var k = {};
                k.id = g.id.user;
                k.isAdmin = g.isAdmin;
                return k;
              });
              return d;
            });
            h = window.WAM.getAllChats()
              .filter(function (c) {
                return !c.isGroup;
              })
              .map(function (c) {
                var d = {},
                  g = {};
                d.groupName = "All Users";
                d.groupId = "";
                g.displayName = c.contact.verifiedName || c.contact.pushname;
                g.phoneNumber = c.id.user;
                g.isMyContact = c.contact.isMyContact;
                g.savedName = c.contact.name || c.contact.displayName;
                d.members = [g];
                return d;
              });
          }),
          2
        ))
      : a["return"]([e, h]);
  });
}
function WAMsleep(e) {
  return $jscomp.asyncExecutePromiseGeneratorProgram(function (h) {
    return h["return"](
      new Promise(function (a) {
        return setTimeout(a, e);
      })
    );
  });
}
