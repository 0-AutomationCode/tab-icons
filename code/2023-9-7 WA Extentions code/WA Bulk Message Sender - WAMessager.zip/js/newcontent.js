const EVENT_NAME = "GOT_WAPI";
const MESSAGE_EVENT_NAME = "GOT_WAPI_SEND_MESSAGE";
const CAPTURE_PHONE_NUMBER_EVENT_NAME = "GOT_CAPTURE_PHONE_NUMBER";
const VALID_STATUS_PHONE_NUMBER_EVENT_NAME = "GOT_VALID_STATUS_PHONE_NUMBER";
const VALID_BEFORE_SENDING = "GOT_VALID_BEFORE_SENDING";
const VALID_AFTER_SENDING = "GOT_VALID_AFTER_SENDING";

let myNumber = null;
window.onload = function () {
  capturePhone();
  addScriptToPage(chrome.extension.getURL("wamessages.js"));
};
function capturePhone() {
  try {
    var data;
    if (window.localStorage.getItem("last-wid")) {
      data = window.localStorage.getItem("last-wid");
      myNumber = data.split("@")[0].substring(1);
    } else {
      data = window.localStorage.getItem("last-wid-md");
      myNumber = data.split(":")[0].substring(1);
    }
    console.log(myNumber);
  } catch (e) {
    console.log(e);
  }
}

function addScriptToPage(e) {
  try {
    const t = document.createElement("script");
    t.type = "text/javascript";
    t.src = e;
    (document.head || document.body || document.documentElement).appendChild(t);
  } catch (e) {}
}

// adding the url
if (!document.getElementById("wamessages")) {
  const wam = document.createElement("a");
  wam.id = "wamessages";
  document.body.append(wam);
}

// Send messages, images, documents to users.
let messagesSent = 0;
let stopSending = false;

var rows = [["Phone Number", "Result"]];
replace_pattern = /{{(.*?)}}/g;
coloumn_pattern = /[^{\{]+(?=}\})/g;
stop = !1;
total_count = 0;

chrome.runtime.onMessage.addListener(receiver);

// function to convert data blob url
function dataURLtoBlob(dataUrl, caption, callback) {
  var req = new XMLHttpRequest();
  req.open("GET", dataUrl);
  req.responseType = "arraybuffer"; // Can't use blob directly because of https://crbug.com/412752
  req.onload = function fileLoaded(e) {
    // If you require the blob to have correct mime type
    var mime = this.getResponseHeader("content-type");
    callback(new Blob([this.response], { type: mime }), caption);
  };
  req.send();
}

function base64ImageToFile(b64Data, filename) {
  console.log(" Base 64 Image File ",b64Data);
  var arr = b64Data.split(",");
  var mime = arr[0].match(/:(.*?);/)[1];
  var bstr = atob(arr[1]);
  var n = bstr.length;
  var u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
}

function captureParagraphFocus(index) {
  console.log("Welcome Start");
  let p = document.querySelectorAll('[contenteditable="true"]')[index];
  p.focus();
}

var multipleFirePrevnt = true;
function receiver(e, t, n) {
  console.log("works");
  console.log(e);
  // if only documentis sent
  if (["pv", "cn", "doc"].includes(e.mediaType)) {
    openAndSendMultimedia(e.mediaType, "");
  } else if ("hello" == e.greeting) {
    // send the number and date to popup js
    capturePhone();
    n({
      number: myNumber,
      date: new Date().toDateString(),
    });
  } else if (e.context.process_state === "continue" && multipleFirePrevnt) {
    multipleFirePrevnt = false;
    console.log(" Me Called !!!! ");
    prepareTotalMessagesAndWaitingTime(e);
    setTimeout(()=>{
      multipleFirePrevnt = true;
    },2000)
    return true;
  } else if (e.context.export_results  && e.context.export_results === "true") {
    export_results();
  } else if (e.context.filter_numbers && e.context.filter_numbers === "true") {
    console.log(e.context, e);
    rows = [["Phone Number", "Result"]];
    // filter_numbers(e.arr);
    console.log(e.arr);
    new_filter_numbers(e.arr);
  } else if (e.context.process_state) {
    console.log("STOPPED");
    stopSending = true;
  } else if (e.context.download_group) {
    console.log("STARTING download");
    download_group();
  } else if (e.context.installed) {
    console.log("hiiiii");
  }
}

function processTheBlobData(e) {
  all_blob_data = [];
  if (e.context.attachment_status) {
    chrome.storage.local.get(["all_canvas"], function (result) {
      if (result.all_canvas && result.all_canvas.length > 0) {
        let all_canvas = JSON.parse(result.all_canvas);
        console.log(" All Canvas: ",all_canvas);
        for (let index = 0; index < all_canvas.length; index++) {
          /* Older Logic
          if (e.context.mediaType === "img") {
            dataURLtoBlob(
              all_canvas[index].file_canvas_2,
              all_canvas[index].file_caption,
              function (blobFile, caption) {
                all_blob_data.push({ blob: blobFile, caption: caption });
              }
            );
          } else {
            let fileData = base64ImageToFile(
              all_canvas[index].file_canvas,
              all_canvas[index].file_name
            );
            all_blob_data.push({
              blob: fileData,
              caption: all_canvas[index].file_caption,
            });
          }
          */
          let fileData = base64ImageToFile(
            all_canvas[index].file_canvas,
            all_canvas[index].file_name
          );
          all_blob_data.push({
            blob: fileData,
            caption: all_canvas[index].file_caption,
          });
          console.log(" Length of All BLOB Data: ",all_blob_data);
        }
      }
    });
  }
}

async function sendingVideoAndDocument(contactno) {
  await sleep(1000);
  contactno = contactno + "";
  contactno = contactno.replaceAll(" ","");
  contactno = contactno.replaceAll("+","");
  let data = {
    contactno: `${contactno}@c.us`,
    caption: all_blob_data[0]["caption"],
    file: all_blob_data[0]["blob"],
  };
  document.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: data }));
}

async function sendMessageText(contactno,messageText){
  await sleep(500);
  contactno = contactno + "";
  contactno = contactno.replaceAll(" ","");  
  contactno = contactno.replaceAll("+","");
  let data = {
    contactno: `${contactno}@c.us`,
    message: messageText,
  };
  document.dispatchEvent(new CustomEvent(MESSAGE_EVENT_NAME, { detail: data }));
}

async function sendingMultipleImages(contactno, caption, total_attachment) {
  await sleep(1000);
  // captureParagraphFocus(1);
  let count = 0;
  let first_time = true;
  contactno = contactno + "";
  contactno = contactno.replaceAll(" ","");
  contactno = contactno.replaceAll("+","");
  console.log(" All BLOB Items: ", all_blob_data.length);
  for (let index = 0; index < total_attachment; index++) {
    /* Older Code
    if (first_time) {
      await navigator.clipboard
        .writeText(all_blob_data[index]["caption"])
        .then(() => {
          console.log(" Text Copied!!!!");
          document.execCommand("paste", null, null);
        });
      // await setOnlyText(caption);
      await sleep(1000);
      await navigator.clipboard
        .write([
          new ClipboardItem({
            [all_blob_data[index]["blob"].type]: all_blob_data[index]["blob"],
          }),
        ])
        .then(() => {
          count++;
          console.log(" File Copied!!!!", index, count);
          document.execCommand("paste", null, null);
        });
      await sleep(3000);
      first_time = false;
    } else {
      await navigator.clipboard
        .write([
          new ClipboardItem({
            [all_blob_data[index]["blob"].type]: all_blob_data[index]["blob"],
          }),
        ])
        .then(() => {
          count++;
          console.log(" File Copied!!!!", index, count);
          document.execCommand("paste", null, null);
        });
      await sleep(2000);
      await navigator.clipboard
        .writeText(all_blob_data[index]["caption"])
        .then(() => {
          console.log(" Text Copied!!!!");
          document.execCommand("paste", null, null);
        });
      await sleep(1000);
    }
    */
    let data = {
      contactno: `${contactno}@c.us`,
      caption: all_blob_data[index]["caption"],
      file: all_blob_data[index]["blob"],
    };
    document.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: data }));
  }
  await sleep(1000);
  if (count == all_blob_data.length) {
    clickSendButton();
  }
}

function clickSendButton() {
  const observer = new MutationObserver((mutations, obs) => {
    const elem = document.querySelector('[title="Add file"]');
    if (elem) {
      try {
        elem.parentElement.parentElement
          .querySelector('span[data-icon="send"]')
          .click();
        console.log(" Send Button PS Clicked ");
        obs.disconnect();
        return;
      } catch (ex) {
        console.log(ex);
      }
    }
  });

  observer.observe(document, {
    childList: true,
    subtree: true,
  });
}

// variable for managing sending messages
var all_message_data;
var all_blob_data = [];
var messages_array = [];
var waiting_time = [];
var progress_width = 0;
var progress_end_width = 539;
var total_messages_sent = 0;
var all_message_count = 0;
var current_message_index;
var reports = {};
var excel_report = [];
var char_status_code = "";
var excel_column_key = "";
var final_stop = false;
var resume_status;
var current_batch;
var running_batch;
// function to display popup as well as total messages
async function prepareTotalMessagesAndWaitingTime(e) {
  all_blob_data = [];
  console.log("messaging");
  all_message_data = e;
  var message = e.context.message;
  messages_array = [];
  waiting_time = [];
  messagesSent = 0;
  all_message_count = 0;
  resume_status = false;
  current_batch = running_batch = 0;
  console.log();
  if (e.context.is_custom_message) {
    // if custom message replace each entry and generate sepearete messages
    result = e.context.execl_coloumn;
    for (const [e, t] of Object.entries(result[0])) {
      var s = "{{" + t + "}}";
      r = "{{" + e + "}}";
      // replacing the colomn text with coloumn number like A,B,C... instead of email,name,grade
      a = message.replaceAll(s, r);
      message = a;
    }
    // console.log(message);
    // from_coloumn = parseInt(e.context.from_coloumn);
    // to_coloumn = parseInt(e.context.to_coloumn);
    var columns = message.match(coloumn_pattern);
    var replace = message.match(replace_pattern);
    // console.log("result length",result)
    if (columns != null && replace != null) {
      // repeating till end of total rows
      for (var o = 1; o < result.length; o++) {
        // console.log("from column",o)
        // getting all the values from a particular coloumn
        for (var c = message, u = 0; u < columns.length; u++) {
          var l = c.replace(replace[u], result[o][columns[u]]);
          c = l;
        }
        // pushing the generated message
        messages_array.push(c);
        // Generating the time Delay
        waiting_time.push(
          generateTime(
            e.context.timeDelay,
            e.context.timer_checked_status,
            e.context.minTimeDelay,
            e.context.maxTimeDelay,
            e.context.random_timer,
            e.context.attachment_status,
            e.context.attachment_with_message_status
          )
        );
      }

      console.log(e.context.totalMessages);

      console.log(e.context.numbers);
    } else {
      for (let k = 0; k < e.context.numbers.length; k++) {
        messages_array.push(message);
        // Generating the time Delay
        waiting_time.push(
          generateTime(
            e.context.timeDelay,
            e.context.timer_checked_status,
            e.context.minTimeDelay,
            e.context.maxTimeDelay,
            e.context.random_timer,
            e.context.attachment_status,
            e.context.attachment_with_message_status
          )
        );
      }
      console.log("simple message", []);
      console.log(e.context.totalMessages);
    }
  } else {
    // messagesSent = 0;
    for (let k = 0; k < e.context.numbers.length; k++) {
      messages_array.push(message);
      // Generating the time Delay
      waiting_time.push(
        generateTime(
          e.context.timeDelay,
          e.context.timer_checked_status,
          e.context.minTimeDelay,
          e.context.maxTimeDelay,
          e.context.random_timer
        )
      );
    }
  }
  console.log("simple message", messages_array);
  console.log(e.context.totalMessages);

  let total_message = e.context.numbers.length;
  if (e.context.attachment_with_message_status) {
    total_message += e.context.total_attachment * total_message;
  } else if (e.context.sending_option === "sao") {
    total_message = total_message * e.context.total_attachment;
  }else if(e.context.attachment_type === 'cn'){
    total_message *= 2;
  }
  all_message_count = total_message;
  console.log(all_message_count, total_message, e.context.total_attachment);
  // Open popup as well as display codes.
  open_popup(false);
  let total_time = 0;
  let general_delay = 3;
  if (e.context.attachment_status) {
    general_delay = 5;
  }
  if(e.context.attachment_type === "cn"){
    general_delay = 10;
  }

  for (let i = 0; i < waiting_time.length; i++) {
    total_time += waiting_time[i] + general_delay;
  }
  if (e.context.batched) {
    total_time += Math.ceil(
      (total_message * e.context.batch_delay) / e.context.batch_size
    );
  }
  console.log(" Total Time in Seconds: " + total_time);
  total_time = Math.ceil(total_time / 60);
  console.log(" Total Time in Minutes: " + total_time);
  let time_message = "";
  if (total_time == 0) {
    time_message = "less than a minute.";
  } else if (total_time == 1) {
    time_message = `approximately ${total_time} minute.`;
  } else {
    time_message = `approximately ${total_time} minutes.`;
  }
  let html_content = `You are about to send ${total_message} messages.<br>`;
  html_content += `This is going to take ${time_message}`;
  document.getElementById("wamessages_popup_heading_1").innerHTML =
    html_content;

  // Prepare Report for Excel List
  if (e.context.excel_sheet_data) {
    excel_report = e.context.excel_sheet_data;
    let char_code = 65 + Object.keys(excel_report[0]).length;
    char_status_code = String.fromCharCode(char_code);
    excel_report[0][char_status_code] = "Status";
    excel_column_key = e.context.excel_column_key;
    for (let index = 1; index < excel_report.length; index++) {
      for (let ccode = 65; ccode <= char_code; ccode++) {
        let code_string = String.fromCharCode(ccode);
        if (!excel_report[index].hasOwnProperty(code_string)) {
          excel_report[index][code_string] = "";
        }
      }
    }
    console.log("Excel Report", excel_report, excel_column_key);
  } else {
    excel_report = [];
    char_status_code = "";
    excel_column_key = "";
  }

  processTheBlobData(e);
  //   checkTheCurrentBlobStatus();
}

let intervalRef;
function checkTheCurrentBlobStatus() {
  intervalRef = setInterval(() => {
    console.log(all_blob_data, all_message_data.context.total_attachment);
    let num = parseInt(all_message_data.context.total_attachment);
    if (all_blob_data.length >= num) {
      document.querySelector("#wamessages_popup_heading_2").innerHTML =
        "Are you sure want to continue?";
      document.querySelector("#wamessages_button_1").style.cursor = "pointer";
      clearInterval(intervalRef);
      return;
    } else {
      document.querySelector("#wamessages_popup_heading_2").innerHTML =
        "Loading attachments...";
      document.querySelector("#wamessages_button_1").style.cursor =
        "not-allowed";
    }
  }, 100);
}

async function resumeSendingProcess() {
  if (all_message_data) {
    let e = all_message_data;
    await sendAny(
      e.context.numbers,
      messages_array,
      e.context.is_image,
      e.context.timeDelay,
      e.context.totalMessages,
      e.context.batch_size,
      e.context.batch_delay,
      e.context.batched,
      waiting_time,
      e.context.attachment_status,
      e.context.caption_message,
      e.context.total_attachment,
      e.context.attachment_type
    );
  }
}

// function to continue sending process messages
async function continueSendingProcess(firstTime = true) {
  if (all_message_data) {
    current_message_index = 0;
    stopSending = false;
    change_the_visibility_of_popup_component("none", "block");
    total_messages_sent = progress_width = 0;
    update_progress_status_and_bar(true);
    document.getElementById("wamessages_popup_heading").innerHTML =
      "Your messages are being sent";
    document.getElementById("wamessages_popup_heading_2").innerHTML =
      "Sending...";
    let e = all_message_data;
    await sendAny(
      e.context.numbers,
      messages_array,
      e.context.is_image,
      e.context.timeDelay,
      e.context.totalMessages,
      e.context.batch_size,
      e.context.batch_delay,
      e.context.batched,
      waiting_time,
      e.context.attachment_status,
      e.context.caption_message,
      e.context.total_attachment,
      e.context.attachment_type
    );
  }
}

function generateTime(
  timeDelay,
  timer_checked_status,
  minTimeDelay,
  maxTimeDelay,
  random_timer,
  attachment_status,
  attachment_with_message_status
) {
  let time = 3;
  let min = parseInt(minTimeDelay);
  let max = parseInt(maxTimeDelay);
  if (timer_checked_status) {
    if (random_timer) {
      time += randomIntFromInterval(min, max);
    } else {
      let time_value = time;
      time += parseInt(timeDelay);
      if (isNaN(time)) {
        time = time_value;
      }
    }
  }
  return time;
}

// comment

// Function to generate random number between range
function randomIntFromInterval(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

async function filter_numbers(numbers) {
  for (let i = 0; i < numbers.length; i++) {
    let isValid = await openChat(numbers[i]);
    rows.push([numbers[i], isValid ? "Valid" : "Invalid number"]);

    chrome.runtime.sendMessage({
      subject: "progress-bar",
      from: "content",
      count: i + 1,
      total: numbers.length,
    });
  }
  export_results();
}


async function new_filter_numbers(numbers) {
  for (let i = 0; i < numbers.length; i++) {
    await newOpenChat(numbers[i]);       
    let contactNo = numbers[i] + "";
    contactNo = contactNo.replaceAll(" ","");
    contactNo = contactNo.replaceAll("+","");
    rows.push([numbers[i],""]);
    let data = {
      contactno: `${contactNo}@c.us`,
      index:i+1
    };
    document.dispatchEvent(new CustomEvent(CAPTURE_PHONE_NUMBER_EVENT_NAME, { detail: data }));
  }
  await sleep(500);
  export_results();
}

document.addEventListener(VALID_STATUS_PHONE_NUMBER_EVENT_NAME, function (e) {
  try{
      rows[e.detail.index][1] =  e.detail.isValid ? "Valid" : "Invalid number";
  }
  catch(ex){
      console.log(ex);
  }
});

// click function used to click on various buttons

async function clickOnElements(element) {
  console.log(element);
  let MouseEvent = document.createEvent("MouseEvents");
  MouseEvent.initEvent("mouseover", true, true);
  const over = document.querySelector(element).dispatchEvent(MouseEvent);
  await sleep(50);
  MouseEvent.initEvent("mousedown", true, true);
  const down = document.querySelector(element).dispatchEvent(MouseEvent);
  MouseEvent.initEvent("mouseup", true, true);
  const up = document.querySelector(element).dispatchEvent(MouseEvent);
  MouseEvent.initEvent("click", true, true);
  const click = document.querySelector(element).dispatchEvent(MouseEvent);
  console.log(over, down, up, click);

  if (over) {
    return new Promise((resolve) => {
      resolve();
    });
  } else {
    return await clickOnElements(element);
  }
}

/**
 * Possible argument values:
 *
 * pv = Photos and Videos
 * cn = contact
 * doc = any other type of media/document
 */
async function clickMediaIcon(mediaType) {
  let mediaButtonQuery = null;
  if (mediaType === "pv") {
    mediaButtonQuery = '[data-icon="attach-image"]';
  } else if (mediaType === "doc") {
    mediaButtonQuery = '[data-icon="attach-document"]';
  } else if (mediaType === "cn") {
    mediaButtonQuery = '[data-icon="attach-contact"]';
  }
  console.log("clickMediaIcon IF");
  if (mediaButtonQuery) {
    await clickOnElements(mediaButtonQuery);
    console.log("clickMediaIcon timeout");
  }
}

/* New Function for working with New Flow of Selecting Image */
async function openAndSendMultimedia(mediaType, message) {
  try {
    console.log("forwaing msg........................");
    hasOpenedSelf = await openChat(myNumber);
    await sleep(1500);
    if (document.querySelector('span[data-icon="send"]')) {
      document.querySelector('span[data-icon="send"]').className =
        "wamessages-btn";
    }
    if (mediaType === "pv") {
      await setOnlyText(message);
    }
    await clickOnElements('[data-testid="clip"] svg');
    await clickMediaIcon(mediaType);
    await sleep(5000);
    // console.log($('span[data-icon="send"]:not(.wamessages-btn)').length);
    // console.log($('span[data-icon="send"]').length);
    eventFireAfterMediaSelection(
      document.querySelector('span[data-icon="send"]:not(.wamessages-btn)'),
      "click"
    ).then((result) => {
      open_media_popup();
    });
  } catch (error) {
    console.log(error, "ERROR");
  }
}

async function sendMultimedia(mediaType) {
  try {
    console.log("forwaing msg........................");
    hasOpenedSelf = await openChat(myNumber);
    // await openMediaPopup();
    await clickOnElements('[data-testid="clip"] svg');
    await clickMediaIcon(mediaType);

    // New Addition for clicking
    if (document.querySelector('span[data-icon="send"]')) {
      document.querySelector('span[data-icon="send"]').className =
        "wamessages-btn";
      await sleep(5000);
      // console.log($('span[data-icon="send"]:not(.wamessages-btn)').length);
      // console.log($('span[data-icon="send"]').length);
      eventFireAfterMediaSelection(
        document.querySelector('span[data-icon="send"]:not(.wamessages-btn)'),
        "click"
      );
    }
  } catch (error) {
    console.log(error, "ERROR");
  }
}

// used for diving into batches
function chunk(arr, chunkSize) {
  if (chunkSize <= 0) throw "Invalid chunk size";
  var R = [];
  for (var i = 0, len = arr.length; i < len; i += chunkSize)
    R.push(arr.slice(i, i + chunkSize));
  return R;
}

// checks if the messages are to be sent in  batches or not
async function sendAny(
  contactsArray,
  messagesArray,
  isMediaMessage,
  timeDelay,
  totalMessages,
  batch_size,
  batch_delay,
  batched,
  waitingTimeArray,
  attachment_status,
  caption,
  total_attachment,
  attachment_type
) {
  console.log("god function", contactsArray, messagesArray, isMediaMessage);
  console.log(waitingTimeArray);
  // Send text messages to possible numbers in the list.
  if (messagesArray.length !== 0) {
    console.log("Sending Messages", " batch size" + batch_size, batched);
    // Send messages to all the contacts.
    if (batched) {
      console.log(typeof batch_delay);
      new_contactsArray = chunk(contactsArray, parseInt(batch_size));
      new_messagesArray = chunk(messagesArray, parseInt(batch_size));
      new_waitingTimeArray = chunk(waitingTimeArray, parseInt(batch_size));      
      index = current_batch;
      console.log(new_contactsArray.length,"Current Batch ",current_batch);
      while (index < new_contactsArray.length) {        
        await core_sending(
          new_contactsArray[index],
          new_messagesArray[index],
          isMediaMessage,
          timeDelay,
          totalMessages,
          batch_delay,
          new_waitingTimeArray[index],
          attachment_status,
          caption,
          total_attachment,
          attachment_type,
          batched
        );
        index++;
      }
    } else {
      console.log("core sending without batvh");
      core_sending(
        contactsArray,
        messagesArray,
        isMediaMessage,
        timeDelay,
        totalMessages,
        0,
        waitingTimeArray,
        attachment_status,
        caption,
        total_attachment,
        attachment_type
      );
    }
  }
}

async function core_sending(
  contactsArray,
  messagesArray,
  isMediaMessage,
  timeDelay,
  totalMessages,
  batch_delay,
  waitingTimeArray,
  attachment_status,
  caption,
  total_attachment,
  attachment_type,
  batched = false
) {
  let core_index = current_message_index;
  if(resume_status){
    resume_status = false;
    if(batched && current_message_index >= contactsArray.length){
      core_index = current_message_index = 0;
    }
  }else if(batched){
    core_index = 0;
  }
  console.log(" Test Phase Batch Issue ");
  console.log(contactsArray.length," Current Message Index ",current_message_index, " Core Message Index ",core_index);
  let i;
  for (i = core_index; i < contactsArray.length; i++) {
    
    console.log(" Core Sending Process: ",i);

    if (stopSending) {
      // stopSending = false;
      document
        .getElementById("wamessages_progress_button_2")
        .classList.remove("wamessages_not_active_rule");
      document
        .getElementById("wamessages_progress_button_2")
        .classList.add("wamessages_active_rule");
      document.getElementById("wamessages_progress_button_2").disabled = false;
      document.getElementById("wamessages_progress_button_1").innerHTML =
        "Stop process";
      document.getElementById("wamessages_popup_heading_2").innerHTML =
        "You have stopped the process.<br>Messages are not being sent at the moment.";
      update_progress_status_and_bar(false, all_message_data);
      break;
    }

    await newOpenChat(contactsArray[i]);
    console.log("Delay For this message: ", waitingTimeArray[i]);
    if(i!=core_index){
      await sleep(waitingTimeArray[i] * 1000);
    }

    await sendNewWayToSendMessage(contactsArray[i],messagesArray[i],isMediaMessage,
      attachment_status,
      caption,
      total_attachment,
      attachment_type);

    
    
    if (i == contactsArray.length - 1) {
      console.log("sleeping now for", batch_delay, "seconds");
      await sleep(parseInt(batch_delay) * 1000);
    }
  }
  if(batched && i == contactsArray.length){
    current_batch++;
  }
  console.log("total messages sent" + totalMessages, messagesSent);  
}

async function sendNewWayToSendMessage(contactNo,
  messageText,
  isMediaMessage,
  attachment_status,
  caption,
  total_attachment,
  attachment_type
  ){
    
  // Generate a Sending Event
  let chatid = contactNo + "";
  chatid = chatid.replaceAll(" ","");
  chatid = chatid.replaceAll("+","");
  let data = {
    chatid: `${chatid}@c.us`,
    contactNo:contactNo,
    messageText:messageText,
    isMediaMessage:isMediaMessage,
    attachment_status:attachment_status,
    caption:caption,
    total_attachment:total_attachment,
    attachment_type:attachment_type
  };
  document.dispatchEvent(new CustomEvent(VALID_BEFORE_SENDING, { detail: data }));
  await sleep(500);
}

document.addEventListener(VALID_AFTER_SENDING, async function (e) {
  try{
      let isValidNo = e.detail.isValid;
      let contactNo = e.detail.contactNo;
      let messageText= e.detail.messageText;
      let isMediaMessage= e.detail.isMediaMessage;
      let attachment_status= e.detail.attachment_status;
      let caption= e.detail.caption;
      let total_attachment= e.detail.total_attachment;
      let attachment_type= e.detail.attachment_type;
      let execution_status = true;
      // Old Flow of Sending Message (Begin)
      // Send message if the number is valid.
      if (!document.querySelectorAll("[contenteditable='true']")[1]) {
        // chekcing for message box if not number is blocked
        rows.push(contactNo, "Blocked number");
        reports[contactNo] = "Blocked number";
        execution_status = false;
      } else if (!isUnsubscribed()) {
        if (isValidNo) {
          if(isMediaMessage && attachment_type === "cn"){
            console.log(" Reached Here.... ");
            // await sendText(messageText);
            await sendMessageText(contactNo,messageText);
            await sleep(1000);
            rows.push([contactNo, "Message sent"]);
            let contactName = null,
              imageURL = document.querySelector("[aria-selected='true'] img")
                ? document
                    .querySelector("[aria-selected='true'] img")
                    .getAttribute("src")
                : null;
            //we get the image of user ater sending text message
            console.log(
              contactName,
              imageURL,
              document.querySelector("[aria-selected='true'] [title]")
            );
    
            if (document.querySelector("[aria-selected='true'] [title]")) {
              // getting the username frm the window after sedning text message
              contactName = document
                .querySelector("[aria-selected='true'] [title]")
                .getAttribute("title")
                .trim();
            } else if (document.querySelector("header span[title]")) {
              contactName = document
                .querySelector("header span[title]")
                .getAttribute("title")
                .replace(/[^A-Z0-9]/gi, "")
                .trim();
            }
    
            let hasOpenedSelf = false;
            try {
              // again pening our chat window
              hasOpenedSelf = await openChat(myNumber);
              if (hasOpenedSelf) {
                //click on forward button
                let forwardButtons = document.querySelectorAll(
                  "[data-testid='forward-chat']"
                );
                forwardButton = forwardButtons[forwardButtons.length - 1];
                await forwardButton.click();
                await sleep(1000);
                console.log(forwardButton);
                // getting all the contacts from forward windows
                let contactsList = document.querySelectorAll(
                  "[data-animate-modal-body='true'] div[class=''] > div div div[tabindex='-1']"
                );
                console.log(contactsList);
                // contactsList.querySelectorAll("img[src^='https']").forEach
                // Filter the contact card.
                console.log(" contact Name: ", contactName);
                for (let index = 0; index < contactsList.length; index++) {
                  if (contactsList[index].querySelector("span[dir='auto']")) {
                    console.log("indexxx", index);
                    let nameElement =
                      contactsList[index].querySelector("span[dir='auto']");
                    let name = contactsList[index]
                      .querySelector("span[dir='auto']")
                      .title.trim();
                    console.log(
                      "CONTACT",
                      index,
                      name,
                      nameElement,
                      name === contactName
                    );
                    if (
                      name === contactName ||
                      name.replace(/[^A-Z0-9]/gi, "").trim() === contactName
                    ) {
                      let imageCondition = true;
                      let profileImages =
                        contactsList[index].querySelectorAll("img");
                      if (profileImages.length > 0) {
                        imageCondition =
                          imageURL && contactsList[index].querySelector("img")
                            ? contactsList[index].querySelector("img").src ===
                              imageURL
                            : true;
                      }
                      console.log(
                        index,
                        imageCondition,
                        contactsList[index].querySelectorAll("img")
                      );
                      console.log(contactsList[index]);
                      if (!imageCondition) {
                        continue;
                      }
                      console.log("TRUE");
                      // now send the media to correct user
                      await sendMedia(nameElement);
                      // console.log(document.querySelector("[data-icon='send']"));
                      document.querySelector("[data-icon='send']").click();
                      break;
                    }
                  }
                }
              }
            } catch (error) {
              console.log(error, "ERROR");
            }            
          }
          else if (attachment_status) {
            console.log(all_message_data.context.mediaType);
            if (all_message_data.context.mediaType === "img") {
              if (all_message_data.context.attachment_with_message_status) {
                console.log(" Message Attachment Working...");
                await sendMessageText(contactNo,messageText);
              }
              await sendingMultipleImages(
                contactNo,
                caption,
                total_attachment
              );
            } else {
              if (all_message_data.context.attachment_with_message_status) {
                console.log(" Message Attachment Working...");                
                await sendMessageText(contactNo,messageText);
              }
              await sendingVideoAndDocument(contactNo);
            }
            rows.push([contactNo, "Message sent"]);
            reports[contactNo] = "Message sent";
            execution_status = false;
          } else {
            await sendMessageText(contactNo,messageText);
            rows.push([contactNo, "Message sent"]);
            reports[contactNo] = "Message sent";
            execution_status =
              all_message_data.context.other_attachment_with_message_status;
          }
        } else {
          rows.push([contactNo, "Invalid number"]);
          reports[contactNo] = "Invalid number";
          execution_status = false;
        }
      } else {
        if(isValidNo){
          rows.push([contactNo, "User has unsubscribed"]);
          reports[contactNo] = "User has unsubscribed";
        }else{
          rows.push([contactNo, "Invalid number"]);
          reports[contactNo] = "Invalid number";
        }        
        // continue;
      }
      console.log(" Media Message ", isMediaMessage, "Attachment Type",attachment_type);
        
      // Message Count.
      messagesSent++;
      total_messages_sent++;
      if (all_message_data.context.attachment_with_message_status) {
        messagesSent += all_message_data.context.total_attachment;
        total_messages_sent += all_message_data.context.total_attachment;
        // Save Data
        update_total_message_sent_in_storage(
          all_message_data.context.total_attachment + 1
        );
      } else if (all_message_data.context.sending_option === "sao") {
        messagesSent += all_message_data.context.total_attachment - 1;
        total_messages_sent += all_message_data.context.total_attachment - 1;
        update_total_message_sent_in_storage(
          all_message_data.context.total_attachment
        );
      } else if(attachment_type === "cn") {
        // Save Data
        messagesSent++;
        total_messages_sent++;
        update_total_message_sent_in_storage(2);
      }else {
        // Save Data
        update_total_message_sent_in_storage(1);
      }
      update_progress_status_and_bar(true);
      console.log("number of messages sent", messagesSent);    
      current_message_index++;
      // Old Flow of Sending Message (Ends)
  }
  catch(ex){
      console.log(ex);
  }
});


// function to update total message sent
function update_total_message_sent_in_storage(total_sent) {
  console.log(
    " update_total_message_sent_in_storage: ",
    all_message_data.context.premium,
    total_sent
  );
  if (all_message_data.context.premium) {
    chrome.storage.sync.get(["total_message_sent"], function (result) {
      let message_count = total_sent + result.total_message_sent;
      console.log("Message Count: ", message_count);
      chrome.storage.sync.set(
        { total_message_sent: message_count },
        function () {}
      );
    });
  } else {
    chrome.storage.sync.get(["whatstacknumberofmessages"], function (result) {
      let message_count = total_sent + result.whatstacknumberofmessages;
      chrome.storage.sync.set(
        { whatstacknumberofmessages: message_count },
        function () {
          chrome.runtime.sendMessage({
            update_local_message: message_count,
            contact_no: myNumber,
          });
        }
      );
    });
  }
}

// send attachment function
function sendMedia(title) {
  return new Promise((resolve) => {
    setTimeout(function () {
      // Choose the contact card.
      console.log(title);
      title.click();
      resolve();
    }, 500);
  });
}

// caller function to open chat
async function openChat(contactNo) {
  // console.log("sending to..... "+ contactNo)
  return new Promise((resolve) => {
    openChatUrl(contactNo).then(() => {
      setTimeout(async function () {
        let condition = false;
        condition = await hasOpened();
        resolve(condition);
      }, 2000);
    });
  });
}

// function to open the chat window
function openChatUrl(contactNo) {
  return new Promise((resolve) => {
    let wam = document.getElementById("wamessages");
    if (!wam) {
      wam = document.createElement("a");
      wam.id = "wamessages";
      document.body.append(wam);
    }

    wam.setAttribute(
      "href",
      `https://api.whatsapp.com/send?phone=${contactNo}`
    );

    // Wait for DOM operation to complete.
    setTimeout(() => {
      wam.click();
      resolve();
    }, 500);
  });
}


// caller function to open chat
async function newOpenChat(contactNo) {
  // console.log("sending to..... "+ contactNo)
  return new Promise((resolve) => {
    newOpenChatUrl(contactNo).then(() => {
      setTimeout(async function () {
        let condition = false;
        condition = await hasNewOpened(contactNo);
        resolve(condition);
      }, 2000);
    });
  });
}

// New function to open the chat window
function newOpenChatUrl(contactNo) {
  return new Promise((resolve) => {
    let wam = document.getElementById("wamessages");
    if (!wam) {
      wam = document.createElement("a");
      wam.id = "wamessages";
      document.body.append(wam);
    }
    wam.setAttribute(
      "href",
      // `https://wa.me/${contactNo}`
      `https://api.whatsapp.com/send?phone=${contactNo}`
    );
    // Wait for DOM operation to complete.
    setTimeout(() => {
      wam.click();     
      resolve(); 
    }, 500);
  });
}

// chat windw has opened
async function hasNewOpened(contactNo) {
  let condition = true;
  
  return condition;
}

// chat windw has opened
async function hasOpened() {
  let condition = true;
  await waitTillWindow();
  if (document.querySelector('[data-animate-modal-popup="true"]')) {
    condition = false;
  }
  return condition;
}

// waiting till the chat window opens
async function waitTillWindow() {
  if (
    document.querySelector('[data-animate-modal-popup="true"]') &&
    !document
      .querySelector('[data-animate-modal-body="true"]')
      .innerText.toLowerCase().includes("invalid")
  ) {
    await sleep(500);
    await waitTillWindow();
  }
}

var numbers = [];

async function older_download_group() {
  if (document.querySelector('div[title="Search…"]')) {
    document.querySelector('header [data-testid="default-group"]').click();
    var e = document.querySelector('div[title="Search…"]').parentElement
      .parentElement.parentElement.parentElement.children[1].lastElementChild
      .textContent;
    var t = document.querySelector('div[title="Search…"]').parentElement
      .parentElement.parentElement.parentElement.children[1].firstElementChild
      .textContent;
    console.log(e);
    console.log(t);
    // if these are present it is not group
    if (
      "online" === e ||
      "typing..." === e ||
      "check here for contact info" === e ||
      "" === e ||
      e.includes("last seen")
    ) {
      // Nothing happens, it is not a group.
      chrome.runtime.sendMessage({ group_status: "no_group" }, function () {});
    } else {
      // console.log("group");
      var n = [["Numbers"]];
      e.split(",").forEach((e) => {
        let arr = [];
        arr.push(e);
        n.push(arr);
      });
      let a =
        "data:text/csv;charset=utf-8," + n.map((e) => e.join(",")).join("\n");
      var s = encodeURI(a);
      r = document.createElement("a");
      r.setAttribute("href", s);
      r.setAttribute("download", t + ".csv");
      document.body.appendChild(r);
      r.click();
    }
  }
}

async function download_group() {
  try {
    let notfound = true;
    if (document.querySelector('div[title="Search…"]')) {
      if (document.querySelector('header [data-testid="default-group"]')) {
        document.querySelector('header [data-testid="default-group"]').click();
        var e = document.querySelector('div[title="Search…"]').parentElement
          .parentElement.parentElement.parentElement.children[1]
          .lastElementChild.textContent;
        var t = document.querySelector('div[title="Search…"]').parentElement
          .parentElement.parentElement.parentElement.children[1]
          .firstElementChild.textContent;
        if (
          "online" === e ||
          "typing..." === e ||
          "check here for contact info" === e ||
          "" === e ||
          e.includes("last seen")
        ) {
          // Indicate we nothing selected
        } else {
          notfound = false;
          chrome.runtime.sendMessage({ group_status: "group" }, function () {});
          open_download_popup();
          await new_download_group();
        }
      }
    }
    if (notfound) {
      chrome.runtime.sendMessage({ group_status: "no_group" }, function () {});
    }
  } catch (err) {
    console.log(err);
  }
}

// variable for new download group
var SCROLL_INTERVAL = 600;
var SCROLL_INCREMENT = 450;
var AUTO_SCROLL = true;
var scrollInterval, scrollObserver, group_sidebar, header;
// New Flow of Download Group Contacts Number
async function new_download_group() {
  try {
    contacts = [["Phone", "Name"]];
    contact_hash = {};
    await document.querySelector("#main > header").firstChild.click();
    group_sidebar =
      document.querySelectorAll("span[title=You]")[0].parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode;
    header = document.getElementsByTagName("header")[0];
    var show_more = document.querySelector('[data-testid="down"]');
    if (show_more) {
      show_more.click();
    }
    if (!group_sidebar) {
      return;
    }
    scrollObserver = new MutationObserver(function (mutations, observer) {
      scrap_group();
    });
    scrollObserver.observe(group_sidebar, {
      childList: true,
      subtree: true,
    });
    if (document.querySelector("span[data-icon=down]")) {
      document.querySelector("span[data-icon=down]").click();
    }
    header.nextSibling.scrollTop = 100;
    if (AUTO_SCROLL) {
      scrollInterval = setInterval(auto_scroll, SCROLL_INTERVAL);
    }
  } catch (err) {
    chrome.runtime.sendMessage({ group_status: "no_group" }, function () {});
  }
}

function auto_scroll() {
  if (scroll_end_reached(header.nextSibling)) {
    stop_scroll();
  } else {
    header.nextSibling.scrollTop += SCROLL_INCREMENT;
  }
}

function scroll_end_reached(element) {
  return element.scrollHeight - (element.clientHeight + element.scrollTop) == 0;
}

async function stop_scroll() {
  window.clearInterval(scrollInterval);
  scrollObserver.disconnect();
  let list_contacts = [];
  list_contacts.push(["Phone", "Name"]);
  Object.keys(contact_hash).forEach(function (key) {
    list_contacts.push(contact_hash[key]);
  });

  var group_name = document.querySelector('div[title="Search…"]').parentElement
    .parentElement.parentElement.parentElement.children[1].firstElementChild
    .textContent;

  var close_element = document.querySelector('[data-icon="x"]');
  close_element.click();

  // Logic to assure collection of all contact names
  let firstTime = true;
  for (let index = 0; index < list_contacts.length; index++) {
    if (list_contacts[index][0] === "Not Available") {
      list_contacts[index][0] = await collectContactNumber(
        list_contacts[index][1],
        firstTime
      );
      firstTime = false;
    }
  }
  console.log(contact_hash);
  console.log(list_contacts);

  let unique_list_contacts = {};
  for (let index = 1; index < list_contacts.length; index++) {
    unique_list_contacts[list_contacts[index][0]] = list_contacts[index][1];
  }
  console.log(unique_list_contacts);

  let a = "data:text/csv;charset=utf-8,Phone,Name\n";
  Object.keys(unique_list_contacts).forEach(function (key) {
    a += key + "," + unique_list_contacts[key] + "\n";
  });
  var s = encodeURI(a);
  r = document.createElement("a");
  r.setAttribute("href", s);
  r.setAttribute("download", group_name + ".csv");
  document.body.appendChild(r);
  r.click();
  document.querySelector("#wamessages_popup_download").style.display = "none";
}

function scrap_group() {
  try {
    var contact_list = group_sidebar.querySelectorAll(":scope > div");
    for (let i = 0; i < contact_list.length; i++) {
      var contact = contact_list[i];
      var phone = "";
      var is_saved = true;
      if (
        contact.querySelector("img") &&
        contact.querySelector("img").src.match(/u=[0-9]*/)
      ) {
        phone = contact
          .querySelector("img")
          .src.match(/u=[0-9]*/)[0]
          .substring(2)
          .replace(/[+\s]/g, "");
      } else {
        var temp = contact
          .querySelector("span[title]")
          .getAttribute("title")
          .match(/(.?)*[0-9]{3}$/);
        if (temp) {
          phone = temp[0].replace(/\D/g, "");
          is_saved = false;
        } else {
          phone = "Not Available";
        }
      }
      var name =
        contact.firstChild.firstChild.childNodes[1].childNodes[0].querySelector(
          "span"
        ).innerText;
      if (phone != "") {
        contact_hash[i] = [phone, name];
      }
    }
  } catch (err) {
    console.log(err);
  }
}

async function collectContactNumber(contactName, firstTime) {
  let contactno = "";
  // await sleep(2000);
  console.log(" Contact Name: ", contactName);
  // let search_element = document.querySelector('[data-icon="search"]');
  // search_element.classList.add("wamessages_testing_click");
  // let search_element = document.querySelector('[aria-label="Search or start new chat"]');
  // search_element.click();
  if (firstTime) {
    await clickOnElements('button[aria-label="Search or start new chat"]');
    await sleep(1000);
  }
  navigator.clipboard.writeText(contactName).then(() => {
    console.log(" Text Copied!!!!");
    document.execCommand("paste", null, null);
  });
  await sleep(2000);
  let all_divs = document.querySelectorAll(
    'div[data-testid="cell-frame-container"]'
  );
  let element = undefined;
  for (let index = 0; index < all_divs.length; index++) {
    if (all_divs[index].innerText.indexOf(contactName) != -1) {
      element = all_divs[index];
      break;
    }
  }
  if (element) {
    await clickElements(element);
    await sleep(3000);
    await clickOnElements('span[data-icon="x-alt"]');
    await document.querySelector("#main > header").firstChild.click();
    try {
      // contactno = document.querySelector("h1").parentNode.parentNode.parentNode.parentNode.children[1].children[0].children[0].querySelectorAll(".selectable-text")[1].innerText;
      let h1_element = document.querySelector("h1");
      let parent = h1_element.closest("div > header").parentNode;
      contactno = parent
        .querySelectorAll(".selectable-text")[1]
        .innerText.replace(/[+\s]/g, "");
    } catch (ex) {
      console.log(ex);
    }
  }
  // await clickOnElements('button[aria-label="Chat List"]');
  return contactno;
}
// New Flow of Download Group Contacts Number is ended.

// this is used to send the image and docs message by opening the forward chat window
function open_chat_details() {
  var e = document.evaluate(
    '//*[@id="main"]/header/div[2]',
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;
  document.evaluate(
    '//*[@id="app"]//div[contains(text(), "Group info")]',
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue || e.click();
}

// used to click on button
async function eventFire(e, t) {
  var n = document.createEvent("MouseEvents");
  n.initMouseEvent(t, !0, !0, window, 0, 0, 0, 0, 0, !1, !1, !1, !1, 0, null);

  return new Promise(function (resolve) {
    var intervalLoop = setInterval(function () {
      if (document.querySelector('span[data-icon="send"]')) {
        e.dispatchEvent(n);
        resolve((clearInterval(intervalLoop), "BUTTON CLICKED"));
      } else {
        clearInterval(intervalLoop);
      }
    }, 500);
  });
}

// used to click on button
async function mClick(e) {
  // var n = document.createEvent("MouseEvents");
  // n.initMouseEvent(t, !0, !0, window, 0, 0, 0, 0, 0, !1, !1, !1, !1, 0, null);
  // e.dispatchEvent(n);
  console.log(e);
  // e.parentElement.parentElement.classList.add("testing");
  var click_event = document.createEvent("MouseEvents");
  click_event.initMouseEvent(
    "click",
    true,
    true,
    window,
    0,
    0,
    0,
    0,
    0,
    false,
    false,
    false,
    false,
    0,
    null
  );
  // e.parentElement.parentElement.dispatchEvent(click_event);
  e.click();
}

// used to click on button
async function eventFireAfterMediaSelection(e, t) {
  var n = document.createEvent("MouseEvents");
  n.initMouseEvent(t, !0, !0, window, 0, 0, 0, 0, 0, !1, !1, !1, !1, 0, null);
  console.log(" event Fired Here... ");
  return new Promise(function (resolve) {
    var intervalLoop = setInterval(function () {
      console.log(
        document.querySelector('span[data-icon="send"]:not(.wamessages-btn)')
      );
      if (
        document.querySelector('span[data-icon="send"]:not(.wamessages-btn)')
      ) {
        document
          .querySelector('span[data-icon="send"]:not(.wamessages-btn)')
          .dispatchEvent(n);
        resolve((clearInterval(intervalLoop), "BUTTON CLICKED"));
      }
    }, 500);
  });
}

function isUnsubscribed() {
  try {
    // Get an element which contains contact no of the reciever.
    var t = document.querySelector('div[data-tab="8"]');
    // Return unsubscription status.
    if (t === null || t.lastElementChild === null) {
      return false;
    } else {
      // checking the last message can be done for more messages
      // “UNSUB” or “UNSUBSCRIBE” or “unsub” or “unsubscribe” or “Unsub” or “Unsubscribe”
      var last_message = t.lastElementChild.textContent
        .toLowerCase()
        .substring(0, 5);
      console.log("Last Message: ", last_message);
      return last_message.indexOf("unsub") !== -1;
    }
  } catch (err) {
    return false;
  }
}

// exporting the results of sendt messages
function export_results() {
  let e =
    "data:text/csv;charset=utf-8," + rows.map((e) => e.join(",")).join("\n");
  var t = encodeURI(e);
  n = document.createElement("a");
  n.setAttribute("href", t);
  n.setAttribute("download", "Result.csv");
  document.body.appendChild(n);
  n.click();
  rows = [["Phone Number", "Result"]];
}

// New Download Report Code
function download_report() {
  let e = "data:text/csv;charset=utf-8,"; // + reports.map((e) => e.join(",")).join("\n");
  let char_end_code = char_status_code.charCodeAt();
  if (excel_report.length == 0) {
    e += "phone_number,status\n";
  } else {
    for (let index = 65; index <= char_end_code; index++) {
      e += excel_report[0][String.fromCharCode(index)];
      if (index < char_end_code) {
        e += ",";
      }
    }
    e += "\n";
  }
  Object.keys(reports).forEach(function (key) {
    if (excel_report.length == 0) {
      e += key + "," + reports[key] + "\n";
    } else {
      let current_index = -1;
      for (let index = 1; index < excel_report.length; index++) {
        console.log(excel_report[index][excel_column_key]);
        if (excel_report[index][excel_column_key] == key) {
          current_index = index;
          break;
        }
      }
      if (current_index != -1) {
        excel_report[current_index][char_status_code] = reports[key];
        for (let index = 65; index <= char_end_code; index++) {
          e += excel_report[current_index][String.fromCharCode(index)];
          if (index < char_end_code) {
            e += ",";
          }
        }
        e += "\n";
      }
    }
  });
  var t = encodeURI(e);
  n = document.createElement("a");
  n.setAttribute("href", t);
  n.setAttribute("download", "Report.csv");
  document.body.appendChild(n);
  n.click();
  reports = {};
  excel_report = {};
  char_status_code = "";
  excel_column_key = "";
}

// sending just the text message
async function setOnlyText(e) {
  // add message to textbox
  console.log(" Reached Here... " + e);
  console.log(document.querySelectorAll("[contenteditable='true']").length);
  messageBox = document.querySelectorAll("[contenteditable='true']")[1];
  event = document.createEvent("UIEvents");
  messageBox.innerHTML = e.replace(/ /gm, " ");
  event.initUIEvent("input", !0, !0, window, 1);
  messageBox.dispatchEvent(event);
  // click on send button
  // eventFire(document.querySelector('span[data-icon="send"]'), "click");
}

// sending just the text message
async function setImageOnlyText(e) {
  // add message to textbox
  console.log(" Reached Here... " + e);
  console.log(document.querySelectorAll("[contenteditable='true']").length);
  messageBox = document.querySelectorAll("[contenteditable='true']")[0];
  event = document.createEvent("UIEvents");
  messageBox.innerHTML = e.replace(/ /gm, " ");
  event.initUIEvent("input", !0, !0, window, 1);
  messageBox.dispatchEvent(event);
  // click on send button
  // eventFire(document.querySelector('span[data-icon="send"]'), "click");
}

// sending just the text message
async function sendText(e) {
  // add message to textbox
  // console.log(" Reached Here... " + e);
  messageBox = document.querySelectorAll("[contenteditable='true']")[1];
  event = document.createEvent("UIEvents");
  messageBox.innerHTML = e.replace(/ /gm, " ");
  event.initUIEvent("input", !0, !0, window, 1);
  messageBox.dispatchEvent(event);
  // click on send button
  eventFire(document.querySelector('span[data-icon="send"]'), "click");
}

async function newSendText(e) {
  console.log(" New Send Message ", e);
  messageBox = document.querySelector("[title='Type a message']");
  await clickElements(messageBox);
  event = document.createEvent("UIEvents");
  messageBox.innerHTML = e.replace(/ /gm, " ");
  event.initUIEvent("input", !0, !0, window, 1);
  messageBox.dispatchEvent(event);
  // click on send button
  eventFire(document.querySelector('span[data-icon="send"]'), "click");
}

// Update the progress status and bar
function update_progress_status_and_bar(sending_status = true, e = null) {
  if (sending_status) {
    let status_message = `${total_messages_sent} out of ${all_message_count} messages have been sent`;
    let message_step = Math.ceil(progress_end_width / all_message_count);
    progress_width = total_messages_sent * message_step;
    if (total_messages_sent == all_message_count) {
      progress_width = progress_end_width;
      document.getElementById("wamessages_popup_heading_2").innerHTML =
        "Congrats! All your messages have been sent!";
      // Disable All stop and resume button and activate download report button
      document
        .getElementById("wamessages_progress_button_1")
        .classList.remove("wamessages_stop_active_rule");
      document
        .getElementById("wamessages_progress_button_1")
        .classList.add("wamessages_stop_not_active_rule");
      document
        .getElementById("wamessages_progress_button_2")
        .classList.remove("wamessages_active_rule");
      document
        .getElementById("wamessages_progress_button_2")
        .classList.add("wamessages_not_active_rule");
      document
        .getElementById("wamessages_progress_button_3")
        .classList.remove("wamessages_not_active_rule");
      document
        .getElementById("wamessages_progress_button_3")
        .classList.add("wamessages_active_rule");
      document.getElementById("wamessages_progress_button_1").disabled = true;
      document.getElementById("wamessages_progress_button_2").disabled = true;
      document.getElementById("wamessages_progress_button_3").disabled = false;
    }
    document.getElementById("wamessages_progress_bar").style.width =
      progress_width + "px";
    document.getElementById("wamessages_progress_status").innerHTML =
      status_message;
  } else {
    let total_message = all_message_count;
    let total_time = 0;

    for (let i = current_message_index; i < waiting_time.length; i++) {
      total_time += waiting_time[i] + 3;
    }
    if (e.context.batched) {
      total_time += Math.ceil(
        ((total_message - current_message_index) * e.context.batch_delay) /
          e.context.batch_size
      );
    }
    console.log(" Total Time in Seconds: " + total_time);
    total_time = Math.ceil(total_time / 60);
    console.log(" Total Time in Minutes: " + total_time);
    let html_content = `${total_messages_sent} out of ${all_message_count} messages have been sent.<br>`;
    html_content += `Approx ${total_time} min remaining`;
    console.log(" HTML CONTENT: ", html_content);
    document.getElementById("wamessages_progress_status").innerHTML =
      html_content;
  }
}

function change_the_visibility_of_popup_component(
  first_screen_visibility,
  second_screen_visibility
) {
  // Hide First Popup
  document.getElementById("wamessages_popup_heading_1").style.display =
    first_screen_visibility;
  document.getElementById("wamessages_button_1").style.display =
    first_screen_visibility;
  document.getElementById("wamessages_button_2").style.display =
    first_screen_visibility;
  // Show Second Popup
  document.getElementById("wamessages_progress_background").style.display =
    second_screen_visibility;
  document.getElementById("wamessages_progress_bar").style.display =
    second_screen_visibility;
  document.getElementById("wamessages_progress_status").style.display =
    second_screen_visibility;
  document.getElementById("wamessages_progress_button_1").style.display =
    second_screen_visibility;
  document.getElementById("wamessages_progress_button_2").style.display =
    second_screen_visibility;
  document.getElementById("wamessages_progress_button_3").style.display =
    second_screen_visibility;
  document.getElementById("wamessages_progress_button_3").style.display =
    second_screen_visibility;
}

function open_popup(second) {
  var popup_div = document.getElementsByClassName("wamessages_popup")[0];
  if (!popup_div) {
    var popup = document.createElement("div");
    popup.className = "wamessages_popup";

    var modal_content = document.createElement("div");
    modal_content.className = "wamessages_popup_content";
    var html_content = "";

    html_content += '<div style="position:relative;">';
    html_content +=
      '<p class="wamessages_popup_heading" id="wamessages_popup_heading"></p>';
    html_content += '<p class="wamessages_line_1"></p>';
    // For Beginning Screen
    html_content +=
      '<p class="wamessages_popup_heading_1" id="wamessages_popup_heading_1">You are about to send 145 messages.<br>';
    html_content += "This is going to take approximately 21 minutes.</p>";
    // For Beginning Screen Ends

    // Second Popup Contents
    html_content +=
      '<p class="wamessages_progress_background" id="wamessages_progress_background"></p>';
    html_content +=
      '<p class="wamessages_progress_bar" id="wamessages_progress_bar"></p>';
    html_content +=
      '<p class="wamessages_progress_status" id="wamessages_progress_status">';
    html_content += "44 out of 145 messages have been sent<br>";
    html_content += "Approx. 14min remaining";
    html_content += "</p>";

    html_content += '<p class="wamessages_line_2"></p>';
    html_content +=
      '<p class="wamessages_popup_heading_2" id="wamessages_popup_heading_2"></p>';
    html_content += '<span id="wamessages_close_edit">&times;</span>';
    // For Beginning Screen Buttons
    html_content += '<button id="wamessages_button_1">Continue</button>';
    html_content += '<button id="wamessages_button_2">Cancel</button>';
    // For Beginning Screen Buttons
    // Progress Popup Buttons
    html_content +=
      '<button id="wamessages_progress_button_1" class="wamessages_progress_button_1">Stop process</button>';
    html_content +=
      '<button id="wamessages_progress_button_2" class="wamessages_progress_button_2">Resume<br>process</button>';
    html_content +=
      '<button id="wamessages_progress_button_3" class="wamessages_progress_button_3">Download<br>report</button>';
    html_content += "</div>";

    modal_content.innerHTML = html_content;
    popup.appendChild(modal_content);

    var body = document.querySelector("body");
    body.appendChild(popup);
    document
      .getElementById("wamessages_close_edit")
      .addEventListener("click", function (event) {
        document.getElementsByClassName("wamessages_popup")[0].style.display =
          "none";
      });
    document
      .getElementById("wamessages_button_1")
      .addEventListener("click", function (event) {
        continueSendingProcess();
      });
    document
      .getElementById("wamessages_button_2")
      .addEventListener("click", function (event) {
        document.getElementsByClassName("wamessages_popup")[0].style.display =
          "none";
      });

    document
      .getElementById("wamessages_progress_button_1")
      .addEventListener("click", function (event) {
        if (stopSending) {
          if (final_stop) {
            if (document.getElementsByClassName("wamessages_popup")[0]) {
              document.getElementsByClassName(
                "wamessages_popup"
              )[0].style.display = "none";
            }
            final_stop = false;
            stopSending = false;
          } else {
            document
              .getElementById("wamessages_progress_button_1")
              .classList.remove("wamessages_stop_not_active_rule");
            document
              .getElementById("wamessages_progress_button_1")
              .classList.add("wamessages_stop_active_rule");
            document
              .getElementById("wamessages_progress_button_2")
              .classList.remove("wamessages_not_active_rule");
            document
              .getElementById("wamessages_progress_button_2")
              .classList.add("wamessages_active_rule");
            document
              .getElementById("wamessages_progress_button_3")
              .classList.remove("wamessages_not_active_rule");
            document
              .getElementById("wamessages_progress_button_3")
              .classList.add("wamessages_active_rule");
            document.getElementById("wamessages_popup_heading").innerHTML =
              "Are you sure want to exit?";
            document.getElementById(
              "wamessages_popup_heading_1"
            ).innerHTML = `You have sent ${total_messages_sent} out of ${
              all_message_count
            } messages.<br>There are ${
              all_message_count - total_messages_sent
            } messages left to send.`;
            document.getElementById(
              "wamessages_progress_button_1"
            ).disabled = false;
            document.getElementById(
              "wamessages_progress_button_2"
            ).disabled = false;
            document.getElementById(
              "wamessages_progress_button_3"
            ).disabled = false;
            document.getElementById(
              "wamessages_progress_background"
            ).style.display = "none";
            document.getElementById("wamessages_progress_bar").style.display =
              "none";
            document.getElementById(
              "wamessages_progress_status"
            ).style.display = "none";
            document.getElementById(
              "wamessages_popup_heading_1"
            ).style.display = "block";
            document.getElementById(
              "wamessages_popup_heading_2"
            ).style.display = "none";
            final_stop = true;
          }
        } else {
          stopSending = true;
          document.getElementById("wamessages_progress_button_1").innerHTML =
            "Stopping...";
        }
      });
    document
      .getElementById("wamessages_progress_button_2")
      .addEventListener("click", function (event) {
        stopSending = false;
        final_stop = false;
        resume_status = true;
        resumeSendingProcess();
        document.getElementById(
          "wamessages_progress_background"
        ).style.display = "block";
        document.getElementById("wamessages_progress_bar").style.display =
          "block";
        document.getElementById("wamessages_progress_status").style.display =
          "block";
        document.getElementById("wamessages_popup_heading_1").style.display =
          "none";
        document
          .getElementById("wamessages_progress_button_2")
          .classList.remove("wamessages_active_rule");
        document
          .getElementById("wamessages_progress_button_2")
          .classList.add("wamessages_not_active_rule");
        document.getElementById("wamessages_progress_button_2").disabled = true;
        document.getElementById("wamessages_popup_heading_2").style.display =
          "block";
        document.getElementById("wamessages_popup_heading_2").innerHTML =
          "Sending...";
        update_progress_status_and_bar(true);
      });
    document
      .getElementById("wamessages_progress_button_3")
      .addEventListener("click", function (event) {
        download_report();
        if (final_stop) {
          final_stop = false;
          stopSending = false;
        }
        if (document.getElementsByClassName("wamessages_popup")[0]) {
          document.getElementsByClassName("wamessages_popup")[0].style.display =
            "none";
        }
      });
    document.getElementById("wamessages_progress_button_2").disabled = true;
    document.getElementById("wamessages_progress_button_3").disabled = true;
  } else {
    popup_div.style.display = "block";
  }
  if (second) {
    document.getElementById("wamessages_popup_heading").innerHTML =
      "Your messages are being sent";
    document.getElementById("wamessages_popup_heading_2").innerHTML =
      "Sending...";
    change_the_visibility_of_popup_component("none", "block");
    // Add Class Logic
    document
      .getElementById("wamessages_progress_button_3")
      .classList.remove("wamessages_not_active_rule");
    document
      .getElementById("wamessages_progress_button_3")
      .classList.add("wamessages_active_rule");
    document
      .getElementById("wamessages_progress_button_1")
      .classList.remove("wamessages_stop_active_rule");
    document
      .getElementById("wamessages_progress_button_1")
      .classList.add("wamessages_stop_not_active_rule");
  } else {
    document.getElementById("wamessages_popup_heading").innerHTML =
      "You are about to start";
    document.getElementById("wamessages_popup_heading_2").innerHTML =
      "Are you sure you want to continue?";
    change_the_visibility_of_popup_component("block", "none");
    document
      .getElementById("wamessages_progress_button_2")
      .classList.remove("wamessages_active_rule");
    document
      .getElementById("wamessages_progress_button_2")
      .classList.add("wamessages_not_active_rule");
    document
      .getElementById("wamessages_progress_button_3")
      .classList.remove("wamessages_active_rule");
    document
      .getElementById("wamessages_progress_button_3")
      .classList.add("wamessages_not_active_rule");
    document
      .getElementById("wamessages_progress_button_1")
      .classList.remove("wamessages_stop_not_active_rule");
    document
      .getElementById("wamessages_progress_button_1")
      .classList.add("wamessages_stop_active_rule");
      document.getElementById("wamessages_progress_button_1").innerText = "Stop process";
    document.getElementById("wamessages_progress_button_1").disabled = false;
    document.getElementById("wamessages_progress_button_2").disabled = false;
    document.getElementById("wamessages_progress_button_3").disabled = true;
  }
}

function open_download_popup() {
  var popup = document.createElement("div");
  popup.className = "wamessages_popup_download";
  popup.id = "wamessages_popup_download";

  var modal_content = document.createElement("div");
  modal_content.className = "wamessages_popup_download_content";
  var html_content = "";

  html_content += '<div style="position:relative;">';
  html_content +=
    '<p class="wamessages_popup_download_heading">We are downloading the group numbers. Please wait.</p>';

  html_content += "</div>";

  modal_content.innerHTML = html_content;
  popup.appendChild(modal_content);

  var body = document.querySelector("body");
  body.appendChild(popup);
}

// Popup For Media Operations
function open_media_popup() {
  var popup = document.createElement("div");
  popup.className = "wamessages_popup_media_selection";
  popup.id = "wamessages_popup_media_selection";

  var modal_content = document.createElement("div");
  modal_content.className = "wamessages_popup_media_selection_content";
  var html_content = "";

  html_content += '<div style="position:relative;">';
  html_content +=
    '<p class="wamessages_popup_media_selection_heading">Now you have to go back to WAMessages popup to proceed.</p>';

  html_content += "</div>";

  modal_content.innerHTML = html_content;
  popup.appendChild(modal_content);

  var body = document.querySelector("body");
  body.appendChild(popup);

  setTimeout(() => {
    var element = document.getElementById("wamessages_popup_media_selection");
    element.parentNode.removeChild(element);
  }, 5000);
}

// New Messenger Popup Ends
// used to sleeping functions
function sleep(e) {
  return new Promise((t) => setTimeout(t, e));
}

//
async function clickElements(element) {
  let MouseEvent = document.createEvent("MouseEvents");
  MouseEvent.initEvent("mouseover", true, true);
  const over = element.dispatchEvent(MouseEvent);
  await sleep(50);
  MouseEvent.initEvent("mousedown", true, true);
  const down = element.dispatchEvent(MouseEvent);
  MouseEvent.initEvent("mouseup", true, true);
  const up = element.dispatchEvent(MouseEvent);
  MouseEvent.initEvent("click", true, true);
  const click = element.dispatchEvent(MouseEvent);
  console.log(over, down, up, click);

  if (over) {
    return new Promise((resolve) => {
      resolve();
    });
  } else {
    return await clickOnElements(element);
  }
}


function displayErrorMessage(){

}
